<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
          parent::__construct();
          $this->load->model('Agivest_model');
          $this->load->model('Email_model');
          $this->load->helper('cookie');
          $this->load->library('session');
          $this->load->helper('form');
          $this->load->helper('url');
          $this->load->helper('html');
          $this->load->library('form_validation');
     }

	public function index(){   
    if($this->session->userdata('adminSession')){      
      $data['errormsg'] = "";    
      redirect('Managements/index', 'refresh');
    }elseif($this->session->userdata('userSession')){          
      $data['errormsg'] = "";
      redirect('User/index', 'refresh');
    }else{
      $data['errormsg'] = "";
      $this->load->view('loginregister/login',$data); 
    }
  }
  
  public function selectLogin(){
    
    $this->form_validation->set_rules('username', 'Email', 'trim|required|valid_email');

      $username = $this->input->post('username');
      $password = $this->input->post('password');
      
      //Check berdasarkan username
      $result = $this->Agivest_model->getData($username,md5($password));
      if($result){
        //Status
        $statusUser = '';
        $sess_array = array();      
        foreach($result as $row){
          $sess_array = array(          
            'idUser'  => $row->idUser,
            'username'  => $row->username,
            'password' => $row->password,
            'namaLengkap' =>$row->namaLengkap,
            'levelUser' =>$row->statusLevelUser
            
            
          );
          $statusUser = $row->statusLevelUser;
          
        }


            if ($statusUser == '2') {
              //SET SESSION
              $this->session->set_userdata('userSession', $sess_array);
              redirect('User/index', 'refresh');
            
            }else if ($statusUser == '10') {
              //SET SESSION
              $this->session->set_userdata('adminSession', $sess_array);
              redirect('Managements/index', 'refresh');
            
            }else{
              //SET SESSION
              $this->session->set_userdata('noSession', $sess_array);
              $this->load->view('loginregister/login');
            }
              
            

      }else{
        if (!empty($modalInvestasi)) {
          $this->session->set_flashdata('gagalmasuk','Username atau Password anda salah');
          $this->load->view('loginregister/login');
        }else{
          $this->session->set_flashdata('gagalmasuk','Username atau Password yang dimasukkan salah');
          redirect(base_url().'Login', 'refresh');
        }
      }
    
  }


  public function LoginMunguMobileAppsMaya(){   
      $username = $this->input->post('username');
      $password = $this->input->post('pass');
      

    if( $username == '' || $password == '' ){
      echo json_encode(array( "status" => "false","message" => "Parameter missing!") );
    }else{
      $result = $this->Agivest_model->getData($username,md5($password));

      if($result){  
        $result2 = $this->Agivest_model->getData($username,md5($password));
       
         $emparray = array();
         if($result2){  
           foreach($result2 as $row){
              $emparray = array(          
                'idUser'  => $row->idUser,
                'username' => $row->username,
                'namaLengkap' =>$row->namaLengkap,
                'alamat' =>$row->alamatUser,
                'levelUser' =>$row->levelUser,
                'jenisKelamin' =>$row->jenisKelamin


              );
              
            }
            echo json_encode(array( "status" => "true","message" => "Login successfully!", "datalol" => $emparray) );
         }
         
     }else{ 
      echo json_encode(array( "status" => "false","message" => "Invalid username or password!") );
    }
  }
   
}

  function logout(){
    $this->session->unset_userdata('userSession');    
    session_destroy();
    redirect('Welcome/index', 'refresh');
  }

  function logoutUser(){
    $this->session->unset_userdata('adminSession');    
    $this->session->unset_userdata('userSession');    
    $this->session->unset_userdata('loginedShoppers');    
    $this->session->unset_userdata('loginedDistributor');    
    $this->session->unset_userdata('loginedHQ');    
    session_destroy();
    redirect('Login/index', 'refresh');
  }

  function logoutEmployee(){
    
    $this->session->unset_userdata('loginedShoppers');    
    
    redirect('Welcome/homepage', 'refresh');
  }

  function logoutDistributor(){
    
    $this->session->unset_userdata('loginedDistributor');    
    
    redirect('Welcome/homepage', 'refresh');
  }

  function logoutHQ(){
    
    $this->session->unset_userdata('loginedDistributor');    
    
    redirect('Welcome/homepage', 'refresh');
  }

  function logoutPenambak(){
    $this->session->unset_userdata('siswaSession');    
    session_destroy();
    redirect('Welcome/index', 'refresh');
  }

  function logoutAdmin(){
    $this->session->unset_userdata('adminSession');    
    session_destroy();
    redirect('Welcome/index', 'refresh');
  }
  
  function verify($verificationText=NULL){
      $noRecords = $this->Email_model->verifyEmailAddress($verificationText);
      if ($noRecords > 0){
        $data['errormsg'] = "ok"; 
        $this->load->view('loginregister/login', $data);
      }else{
        $data['errormsg'] = "failed"; 
        $this->load->view('loginregister/login', $data);
      }
  }

}
