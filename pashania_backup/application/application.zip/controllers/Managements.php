<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managements extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Agivest_model');
        $this->load->model('Home_model');
        $this->load->model('Email_model');
        $this->load->model('OnlineCashierEmailLibrary');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('string');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('upload');
        $this->load->library('Pdf');

    }

    protected $statsSent = 0;

    public function index()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");
            $data['dataPaketConnected'] = $this->Home_model->getSelectData("*,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai,DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %M %Y') tglSelesai,TIMESTAMPDIFF(day,NOW(),pakettourtravel.tglMulaiTour)+1 as rentangWaktu","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif' AND pakettourtravel.tglMulaiTour > NOW() ORDER BY rentangWaktu ASC limit 1");
            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;

            //data dashboard
            $data['dataUserAktif'] = $this->Home_model->getSelectData("*","user", "WHERE user.activeUser='A' and user.statusLevelUser='2'");
            $data['dataPaketAktif'] = $this->Home_model->getSelectData("*","pakettourtravel", "WHERE statusTour='aktif'");
            $data['dataArtikel'] = $this->Home_model->getSelectData("*","artikel", "WHERE statusArtikel='aktif'");
            $data['dataTestimoni'] = $this->Home_model->getSelectData("*","testimoni", "WHERE statusTestimoni='aktif'");
            $data['dataFavoritPaket'] = $this->Home_model->getSelectData("*,(maxMember-currentMember) sisaSeat ","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif' ORDER BY sisaSeat ASC LIMIT 1");
            $data['dataArtikelFavorit'] = $this->Home_model->getSelectData("*","artikel", "WHERE artikel.statusArtikel='aktif' ORDER BY readCount DESC LIMIT 1");
            $data['dataTotalArtikelTerbaca'] = $this->Home_model->getSelectData("*,sum(readCount) terbaca","artikel", "WHERE artikel.statusArtikel='aktif' ORDER BY readCount");
            $data['dataPemberiTestiTerbanyak'] = $this->Home_model->getSelectData("*,count(idTestimoni) jmlTesti","user,testimoni", "WHERE user.idUser=testimoni.idUser and testimoni.statusTestimoni='aktif' GROUP BY testimoni.idUser ORDER BY jmlTesti DESC LIMIT 1");
            $data['dataPembawaJemaahTerbanyak'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired, (tagihanpembayaran.hargaTotalPaket/hargaSatuanPaket)-1 jmlJemaahBersamanya","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Lunas' AND pakettourtravel.tglMulaiTour > NOW() ORDER BY jmlJemaahBersamanya DESC LIMIT 1");
            $data['dataPaketProgress'] = $this->Home_model->getSelectData("*,(currentMember/ maxMember)*100 progressNow,DATE_FORMAT(tglMulaiTour, '%d %M %Y') berangkatPada","pakettourtravel", "WHERE statusTour='aktif' and pakettourtravel.tglMulaiTour > NOW() ORDER BY progressNow ASC");
            
            
            $this->load->view('adminPage/index' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function testimoniPage()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah,TIMESTAMPDIFF(year,birthday,NOW()) as ages","user, testimoni", "WHERE user.idUser=testimoni.idUser ORDER BY tglTestimoni DESC");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/testimoni_page' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function CommentsOnArticle()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah,TIMESTAMPDIFF(year,birthday,NOW()) as ages","user, testimoni", "WHERE user.idUser=testimoni.idUser ORDER BY tglTestimoni DESC");
            $data['listCommentar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(komentarartikel.tglKomentar, '%d %M %Y') tglKomentar","komentarartikel, artikel", "WHERE komentarartikel.idArtikel=artikel.idArtikel ORDER BY komentarartikel.tglKomentar DESC");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/commentar_article_page' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function galeriPage()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah,TIMESTAMPDIFF(year,birthday,NOW()) as ages","user, testimoni", "WHERE user.idUser=testimoni.idUser ORDER BY tglTestimoni DESC");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataGaleri'] = $this->Home_model->getSelectData("*, DATE_FORMAT(galeri.tglCreated, '%d %b %Y') tglCreated","galeri", "WHERE galeri.statusGaleri='aktif'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/galeri_page' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function manifest()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah,TIMESTAMPDIFF(year,birthday,NOW()) as ages","user, testimoni", "WHERE user.idUser=testimoni.idUser ORDER BY tglTestimoni DESC");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataAllUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE activeUser='A' AND statusLevelUser NOT IN (10)");
            $data['dataGaleri'] = $this->Home_model->getSelectData("*, DATE_FORMAT(galeri.tglCreated, '%d %b %Y') tglCreated","galeri", "WHERE galeri.statusGaleri='aktif'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/manifest_page' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function ManajemenPaket()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['daftarPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,pakettourtravel.tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","user, pakettourtravel", "WHERE user.idUser=pakettourtravel.idUserResponsible AND pakettourtravel.statusTour='aktif'");
            $data['countHajiorUmrohPaket'] = $this->Home_model->getSelectData("COUNT(pakettourtravel.idPaket) jmltotal, (SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='haji') jmlHaji,(SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='umroh') jmlUmroh","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/pakettravel' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function BuatPaketTravel()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/create_paket_travel_page' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function EditPaketTravel()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            //LINK PARSING USING STRING REPLACE & EXPLODE
            $dataID = $this->uri->segment(3);
            $linkGet = str_replace('[%20,+]', ' ', $dataID);
            $linkSplitted = explode("_", $linkGet);
            //-------------------------------------------|

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['selectPacketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,pakettourtravel.tglMulaiTour,tglSelesaiTour) as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","user, pakettourtravel", "WHERE user.idUser=pakettourtravel.idUserResponsible AND pakettourtravel.statusTour='aktif' AND pakettourtravel.idPaket=$linkSplitted[1]");

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/edit_paket_travel_page' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function EditArticle()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            //LINK PARSING USING STRING REPLACE & EXPLODE
            $dataID = $this->uri->segment(3);
            $linkGet = str_replace('[%20,+]', ' ', $dataID);
            $linkSplitted = explode("_", $linkGet);
            //-------------------------------------------|

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['getArticle'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y (%H:%i') tglPublish","artikel", "WHERE artikel.idArtikel=$dataID");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/edit_new_article' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function prosAddNewPaketTour()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            
         
            $jenisPaket = $this->input->post('jenisPaket');
            $namapaket = $this->input->post('namapaket');
            $tujuanPaket = $this->input->post('tujuanPaket');
            $tanggalPaketDouble = $this->input->post('tanggalPaketDouble');
            $jmlHariPaket = $this->input->post('jmlHariPaket');
            $rencanaPerjalananText = $this->input->post('rencanaPerjalananText');
            $syaratKetentuanPaket = $this->input->post('syaratKetentuanPaket');
            $hargaPaket = $this->input->post('hargaPaket');
            $kuotaPaket = $this->input->post('kuotaPaket');

            $tglMulaiTour = "";
            $tglSelesaiTour = "";

            $tglParsedSplitted = explode(" sampai ", $tanggalPaketDouble);

            $tglMulaiTour = $tglParsedSplitted[0];
            $tglSelesaiTour = $tglParsedSplitted[1];
            $hargaPaketParsed = str_replace(',', '', $hargaPaket);

           
           
            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/gambarpakettour/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('picturePaket')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        } 
                      

                    
                        $dataInput = array(
                              'jenisPaket' => $jenisPaket,
                              'namaPaket' => $namapaket,
                              'tujuanPaket' => $tujuanPaket,
                              'tglMulaiTour' => $tglMulaiTour,
                              'tglSelesaiTour' => $tglSelesaiTour,
                              'hargaTour' => $hargaPaketParsed,
                              'itineraryTour' => $rencanaPerjalananText,
                              'syaratKetentuanTour' => $syaratKetentuanPaket,
                              'idUserResponsible' => $idUser,
                              'maxMember' => $kuotaPaket,
                              'picturePaket' => 'assets/img/gambarpakettour/'.$imagename
                              

                                
                            );
                        
                        $simpan = $this->Home_model->insertData('pakettourtravel' , $dataInput);


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan paket tour ".$namapaket);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/BuatPaketTravel?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosesAddGaleri()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            
         
            $caption = $this->input->post('caption');
            $kategori = $this->input->post('kategori');
           
            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/gambargaleri/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('gambarUpload')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        } 
                      

                    
                        $dataInput = array(
                              'kategori' => $kategori,
                              'keterangan' => $caption,
                              'statusGaleri' => 'aktif',
                              'item' => 'assets/img/gambargaleri/'.$imagename
                              

                                
                            );
                        
                        $simpan = $this->Home_model->insertData('galeri' , $dataInput);


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan sebuah foto galeri ");
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/galeriPage?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosEditPaketTour()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            
         
            $idPaket = $this->input->post('idpakethide');
            $jenisPaket = $this->input->post('jenisPaket');
            $namapaket = $this->input->post('namapaket');
            $tujuanPaket = $this->input->post('tujuanPaket');
            $tanggalPaketDouble = $this->input->post('tanggalPaketDouble');
            $jmlHariPaket = $this->input->post('jmlHariPaket');
            $rencanaPerjalananText = $this->input->post('rencanaPerjalananText');
            $syaratKetentuanPaket = $this->input->post('syaratKetentuanPaket');
            $hargaPaket = $this->input->post('hargaPaket');

            $tglMulaiTour = "";
            $tglSelesaiTour = "";

            $tglParsedSplitted = explode(" sampai ", $tanggalPaketDouble);

            $tglMulaiTour = $tglParsedSplitted[0];
            $tglSelesaiTour = $tglParsedSplitted[1];
            $hargaPaketParsed = str_replace(',', '', $hargaPaket);


            $imagename = "";

            if (!$this->input->post('picturePaket')) {
                    
                        $dataInput = array(
                              'jenisPaket' => $jenisPaket,
                              'namaPaket' => $namapaket,
                              'tujuanPaket' => $tujuanPaket,
                              'tglMulaiTour' => $tglMulaiTour,
                              'tglSelesaiTour' => $tglSelesaiTour,
                              'hargaTour' => $hargaPaketParsed,
                              'itineraryTour' => $rencanaPerjalananText,
                              'syaratKetentuanTour' => $syaratKetentuanPaket,
                              'idUserResponsible' => $idUser
                            );
            }else {
                
                //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/gambarpakettour/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));
                        if (!$this->upload->do_upload('picturePaket')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                        } 
                        $dataInput = array(
                              'jenisPaket' => $jenisPaket,
                              'namaPaket' => $namapaket,
                              'tujuanPaket' => $tujuanPaket,
                              'tglMulaiTour' => $tglMulaiTour,
                              'tglSelesaiTour' => $tglSelesaiTour,
                              'hargaTour' => $hargaPaketParsed,
                              'itineraryTour' => $rencanaPerjalananText,
                              'syaratKetentuanTour' => $syaratKetentuanPaket,
                              'idUserResponsible' => $idUser,
                              'picturePaket' => 'assets/img/gambarpakettour/'.$imagename
                            );
            }

            
                    
                        
                        $update = $this->Home_model->updateData('pakettourtravel' , $dataInput," idPaket=$idPaket");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "mengedit paket tour ".$namapaket);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/ManajemenPaket?stats=success_update', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function CreateNewArticle()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/create_new_article' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    
    public function prosAddNewArtikel()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            
         
            $judulartikel = $this->input->post('judulartikel');
            $kontenartikel = $this->input->post('kontenartikel');
            $kategoriartikel = $this->input->post('kategoriartikel');
            
           
            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/gambarartikel/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureArtikel')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        } 
                      

                    
                        $dataInput = array(
                              'idUser' => $idUser,
                              'judulArtikel' => $judulartikel,
                              'konten' => $kontenartikel,
                              'kategoriArtikel' => $kategoriartikel,
                              'statusArtikel' => 'aktif',
                              'pictureArtikel' => 'assets/img/gambarartikel/'.$imagename
                            );
                        
                        $simpan = $this->Home_model->insertData('artikel' , $dataInput);


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan artikel dengan judul ".$judulartikel);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/CreateNewArticle?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosAddHeadline()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            
         
            $headline = $this->input->post('headline');
            $subheadline = $this->input->post('subheadline');

                        $dataInput = array(
                              'headline' => $headline,
                              'subheadline' => $subheadline
                            );
                        
                        $simpan = $this->Home_model->insertData('headline' , $dataInput);

                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan headline ".$headline);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/HeadlinePage?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosEditArtikel()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            
         
            $idArtikel = $this->input->post('idArtikel');
            $judulartikel = $this->input->post('judulartikel');
            $kontenartikel = $this->input->post('kontenartikel');
            $kategoriartikel = $this->input->post('kategoriartikel');
            
           
            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/gambarartikel/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureArtikel')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        } 
                      

                    
                        $dataInput = array(
                              'idUser' => $idUser,
                              'judulArtikel' => $judulartikel,
                              'konten' => $kontenartikel,
                              'kategoriArtikel' => $kategoriartikel,
                              'statusArtikel' => 'aktif',
                              'pictureArtikel' => 'assets/img/gambarartikel/'.$imagename
                            );
                        
                        $update = $this->Home_model->updateData('artikel' , $dataInput," idArtikel='$idArtikel'");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "memperbaharui artikel dengan judul ".$judulartikel);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/EditArticle/'.$idArtikel.'/'.$judulartikel.'?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function ArticlePage()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['daftarArtikel'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y (%H:%i') tglPublish","artikel", "WHERE statusArtikel='aktif' ORDER BY artikel.tglPublish DESC");
            $data['daftarArtikelOrdered'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y (%H:%i') tglPublish","artikel", "WHERE statusArtikel='aktif' ORDER BY artikel.readCount DESC LIMIT 5");
            $data['daftarArtikelEachMonth'] = $this->Home_model->getSelectData("DATE_FORMAT(artikel.tglPublish, '%M %Y') tgl, COUNT(artikel.idArtikel) jmlArtikel","artikel", "GROUP BY MONTH(artikel.tglPublish), YEAR(artikel.tglPublish)");
            $data['daftarArtikelKategori'] = $this->Home_model->getSelectData("*","artikel", "ORDER BY kategoriArtikel ASC");
            $data['countHajiorUmrohPaket'] = $this->Home_model->getSelectData("COUNT(pakettourtravel.idPaket) jmltotal, (SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='haji') jmlHaji,(SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='umroh') jmlUmroh","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/artikelpage' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function prosesDeletePaketTour()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];
            //deletedata!

            $judulartikel = $this->input->post('idPaket');
            $this->Home_model->deleteData('pakettourtravel' , "idPaket='$judulartikel'");
            
               
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                $historystats = array('idUser' => $idUser,'keterangan' => "menghapus paket tour ".$judulartikel);
                        
                $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                redirect('Managements/ManajemenPaket?stats=success_delete_paket', 'refresh');
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosDeleteGaleri()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];
            //deletedata!
            $dataID = $this->uri->segment(3);
            $this->Home_model->deleteData('galeri' , "idGaleri='$dataID'");
            
               
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                $historystats = array('idUser' => $idUser,'keterangan' => "menghapus paket foto galeri");
                        
                $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                redirect('Managements/galeriPage?stats=success_delete_galeri', 'refresh');
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }
    public function prosesDeleteArtikel()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];
            //deletedata!

            $idArtikel = $this->input->post('idArtikel');
            $judulartikel = $this->input->post('judulArtikel');
            $this->Home_model->deleteData('artikel' , "idArtikel='$idArtikel'");
            
               
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                $historystats = array('idUser' => $idUser,'keterangan' => "menghapus artikel ".$judulartikel);
                        
                $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                redirect('Managements/ArticlePage?stats=success_delete_artikel', 'refresh');
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosesDeleteTestimoni()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];
            //deletedata!

            $idTestimoni = $this->input->post('idTestimoni');
            $this->Home_model->deleteData('testimoni' , "idTestimoni='$idTestimoni'");
            
               
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                $historystats = array('idUser' => $idUser,'keterangan' => "menghapus sebuah testimoni dari user");
                        
                $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                redirect('Managements/testimoniPage?stats=success_delete_artikel', 'refresh');
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosesDeleteComments()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];
            //deletedata!

            $idTestimoni = $this->input->post('idTestimoni');
            $this->Home_model->deleteData('komentarartikel' , "idKomentar='$idTestimoni'");
            
               
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                $historystats = array('idUser' => $idUser,'keterangan' => "menghapus sebuah testimoni dari user");
                        
                $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                redirect('Managements/CommentsOnArticle?stats=success_delete_comments', 'refresh');
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function ManajemenJemaah()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['daftarJemaah'] = $this->Home_model->getSelectData("*, TIMESTAMPDIFF(year,birthday,NOW()) as ages","user", "WHERE statusLevelUser='2' ORDER BY username ASC");
            $data['daftarPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,pakettourtravel.tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","user, pakettourtravel", "WHERE user.idUser=pakettourtravel.idUserResponsible AND pakettourtravel.statusTour='aktif'");
            $data['countHajiorUmrohPaket'] = $this->Home_model->getSelectData("COUNT(pakettourtravel.idPaket) jmltotal, (SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='haji') jmlHaji,(SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='umroh') jmlUmroh","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/jemaahpage' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function ManajemenAdmin()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['daftarJemaah'] = $this->Home_model->getSelectData("*, TIMESTAMPDIFF(year,birthday,NOW()) as ages","user", "WHERE statusLevelUser='2' ORDER BY username ASC");
            $data['daftarPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,pakettourtravel.tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","user, pakettourtravel", "WHERE user.idUser=pakettourtravel.idUserResponsible AND pakettourtravel.statusTour='aktif'");
            $data['countAdmin'] = $this->Home_model->getSelectData("*","user", "WHERE statusLevelUser='10'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/adminpage' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function PaymentPage()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");
            $data['dataPaymentLunas'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Lunas'");
            $data['daftarArtikel'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y (%H:%i') tglPublish","artikel", "WHERE statusArtikel='aktif' ORDER BY artikel.tglPublish DESC");
            $data['countHajiorUmrohPaket'] = $this->Home_model->getSelectData("COUNT(pakettourtravel.idPaket) jmltotal, (SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='haji') jmlHaji,(SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='umroh') jmlUmroh","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/paymentpage' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function HeadlinePage()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");
            $data['dataPaymentLunas'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Lunas'");
            $data['daftarArtikel'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y (%H:%i') tglPublish","artikel", "WHERE statusArtikel='aktif' ORDER BY artikel.tglPublish DESC");
            $data['countHajiorUmrohPaket'] = $this->Home_model->getSelectData("COUNT(pakettourtravel.idPaket) jmltotal, (SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='haji') jmlHaji,(SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='umroh') jmlUmroh","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif'");

            $data['tampilHeadline'] = $this->Home_model->getSelectData("*","headline", "ORDER BY idHeadline DESC LIMIT 1");

            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/headlinepage' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    

    public function lihatDataJemaah()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];
            
            $dataID = $this->uri->segment(3);

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$dataID");
            $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");
            $data['dataPaymentLunas'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Lunas'");
            $data['daftarArtikel'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y (%H:%i') tglPublish","artikel", "WHERE statusArtikel='aktif' ORDER BY artikel.tglPublish DESC");
            $data['countHajiorUmrohPaket'] = $this->Home_model->getSelectData("COUNT(pakettourtravel.idPaket) jmltotal, (SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='haji') jmlHaji,(SELECT COUNT(pakettourtravel.idPaket) FROM pakettourtravel WHERE pakettourtravel.jenisPaket='umroh') jmlUmroh","pakettourtravel", "WHERE pakettourtravel.statusTour='aktif'");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/lihat_profil_jemaah' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function prosesDeclineTagihanPembayaran()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];

            $dataID = $this->uri->segment(3);
            $idUserGetIn = $this->uri->segment(4);

            
                        $dataInput = array(
                              'statusPembayaran' => 'Dibatalkan',
                            );
                        
                        $update = $this->Home_model->updateData('tagihanpembayaran' , $dataInput," kodePaketTour='$dataID'");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "membatalkan pembayaran dari tagihan #".$dataID);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        $emailUser = "";
                        $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUserGetIn");
                        

                        foreach ($selectUser->result() as $row) {
                            # code...
                            $emailUser = $row->email;
                        }

                        
                        
                        //Send Verification EMAIL
                        $this->Email_model->sendDeclinePaymentProposal($emailUser,$dataID); 

                        redirect('Managements/PaymentPage?stats=paymentDeclined', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosesAcceptTagihanPembayaran()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            $dateNow = date("Y-m-d H:i:s");
            
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");

            $kodePaketTourGet = $this->input->post('kodePaketTourGet');
            $emailUser = $this->input->post('emailUser');

            $numberOfUser = 1;
            $numberAnotherUserString = "";
            $numberAnotherUserNumber = 0;

            $totalUserBerangkatHaji = 0;

            $idPaketGet = "";

            $getUserCount = $this->Home_model->getSelectData("*","tagihanpembayaran", "WHERE kodePaketTour='$kodePaketTourGet'");

            foreach ($getUserCount->result() as $row) {
                $numberAnotherUserString = $row->idUserTambahan;
                $idPaketGet = $row->idPaket;
            }

            $str_arr = explode(",", $numberAnotherUserString);

            $numberAnotherUserNumber = count($str_arr);

            $totalUserBerangkatHaji = $numberOfUser + $numberAnotherUserNumber;


                    
                        $dataInput = array(
                              'statusPembayaran' => 'Lunas',
                            );
                        
                        $update = $this->Home_model->updateData('tagihanpembayaran' , $dataInput," kodePaketTour='$kodePaketTourGet'");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menerima pembayaran dari tagihan #".$kodePaketTourGet);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        //Send Verification EMAIL
                        $this->Email_model->sendAcceptPaymentProposal($emailUser,$kodePaketTourGet); 

                        $update = $this->Home_model->updatePaketAddMember($idPaketGet, $totalUserBerangkatHaji);

                        redirect('Managements/PaymentPage?stats=paymentAccepted', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function CreateNewJemaah()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");

             $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/tambahJemaahByAdmin' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function CreateNewAdmin()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");

             $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Konfirmasi'");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('adminPage/tambahAnotherAdminByAdmin' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function tambahJemaahByAdminProses()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

            $idUser = $namaadmin['idUser'];
         
            $username = $this->input->post('username');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $birthday = $this->input->post('birthday');
            $gender = $this->input->post('gender');
            $noKTP = $this->input->post('noKTP');
            $alamat = $this->input->post('alamat');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $kelurahan = $this->input->post('kelurahan');
            $kecamatan = $this->input->post('kecamatan');
            $kabupaten = $this->input->post('kabupaten');
            $provinsi = $this->input->post('provinsi');
            $noPassport = $this->input->post('noPassport');
            $lokasiBuatPassport = $this->input->post('lokasiBuatPassport');
            $tglAktifPassport = $this->input->post('tglAktifPassport');
            $tglExpPassport = $this->input->post('tglExpPassport');
            $namaAyah = $this->input->post('namaAyah');
            $pendidikan = $this->input->post('pendidikan');
            $pekerjaan = $this->input->post('pekerjaan');
            $kodePos = $this->input->post('kodePos');
            $status = $this->input->post('status');
            $noTelp = $this->input->post('noTelp');

            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/pictprofile/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureProfile')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        }

                        if (!$imagename) {
                            $dataInput = array(
                              'statusLevelUser' => '2',
                              'activeUser' => 'A',
                              'username' => $username,
                              'email' => $email,
                              'password' => md5($password),
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status);
                        }else {
                            $dataInput = array(
                              'statusLevelUser' => '2',
                              'activeUser' => 'A',
                              'username' => $username,
                              'email' => $email,
                              'password' => md5($password),
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status,
                              'pictureProfile' => 'assets/img/pictprofile/'.$imagename);
                        }
                      
                        
                        $simpan = $this->Home_model->insertData('user' , $dataInput);

                            $this->Email_model->sendMailCreatedUserByAdmin($email,$username, $password); 
                        

                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan user baru : ".$username.", password ".$password);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/CreateNewJemaah?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function tambahAdminByAdminProses()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

            $idUser = $namaadmin['idUser'];
         
            $username = $this->input->post('username');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $birthday = $this->input->post('birthday');
            $gender = $this->input->post('gender');
            $noKTP = $this->input->post('noKTP');
            $alamat = $this->input->post('alamat');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $kelurahan = $this->input->post('kelurahan');
            $kecamatan = $this->input->post('kecamatan');
            $kabupaten = $this->input->post('kabupaten');
            $provinsi = $this->input->post('provinsi');
            $noPassport = $this->input->post('noPassport');
            $lokasiBuatPassport = $this->input->post('lokasiBuatPassport');
            $tglAktifPassport = $this->input->post('tglAktifPassport');
            $tglExpPassport = $this->input->post('tglExpPassport');
            $namaAyah = $this->input->post('namaAyah');
            $pendidikan = $this->input->post('pendidikan');
            $pekerjaan = $this->input->post('pekerjaan');
            $kodePos = $this->input->post('kodePos');
            $status = $this->input->post('status');
            $noTelp = $this->input->post('noTelp');

            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/pictprofile/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp|jfif",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureProfile')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        }

                        if (!$imagename) {
                            $dataInput = array(
                              'statusLevelUser' => '10',
                              'activeUser' => '',
                              'username' => $username,
                              'email' => $email,
                              'password' => md5($password),
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status);
                        }else {
                            $dataInput = array(
                              'statusLevelUser' => '10',
                              'activeUser' => '',
                              'username' => $username,
                              'email' => $email,
                              'password' => md5($password),
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status,
                              'pictureProfile' => 'assets/img/pictprofile/'.$imagename);
                        }
                      
                        
                        $simpan = $this->Home_model->insertData('user' , $dataInput);

                            $this->Email_model->sendMailCreatedUserByAdmin($email,$username, $password); 
                        

                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan user baru : ".$username.", password ".$password);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('Managements/ManajemenAdmin?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function checkUsernameAvailability()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

            $idUser = $namaadmin['idUser'];

            $usernameTyped = $this->input->post('usernameSent');
            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE username='$usernameTyped'");
            if ($selectUser->result()) {
                        $output['statsupdatenya'] = "no";
                        echo json_encode($output);
                        
            }else {
                $output['statsupdatenya'] = "yes";
                echo json_encode($output);
            }
            


        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }
   
}
