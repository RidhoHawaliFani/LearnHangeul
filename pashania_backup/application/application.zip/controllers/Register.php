<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->model('Agivest_model');
        $this->load->model('Email_model');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('string');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('PHPMailerAutoload');
    }
    
	public function index()
	{
		if($this->session->userdata('userSession')){                    
            redirect('Home', 'refresh');
        }else{
            $this->load->helper(array('form'));
            $this->load->view('loginregister/register');   
        }
	}

	public function selectRegister(){

        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|matches[password]');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');

       if ($this->form_validation->run() == FALSE){
            $this->load->view('loginregister/register');
        }else{
            $username   = $this->input->post('username');
            $email      = $this->input->post('email');
            $password   = $this->input->post('password');

            //Veriv Text
            $verificationCode = random_string('alnum',20);
            //CHECK DUPLICATE
            $checkusername  = $this->Agivest_model->checkDuplicate("where username = '$username'");
            $checkemail     = $this->Agivest_model->checkDuplicate("where email = '$email'");

            if($checkusername == 1 || $checkemail == 1){
                $this->session->set_flashdata('duplikasi',' Email / Username telah dipakai');      
                $this->load->view('loginregister/register');
            }else{
                
                $insertLogin = array(
                    'username'  => $username,
                    'email'     => $email,
                    'password'  => md5($password),
                    'statusLevelUser'    => '2',
                    'activeUser'    => 'N',
                    'verificationCode' => $verificationCode
                );
                //INSERT TO DB
                $resultLogin     = $this->Agivest_model->insertData('user',$insertLogin);          

                
                //Send Verification EMAIL
                $this->Email_model->sendVerificatinEmail($email,$verificationCode,$username); 
                $data['greet']  = "Pendaftaran atas akun Anda telah berhasil. Silahkan cek email anda untuk email konfirmasi";
                //$data['greet']  = "Anda telah mendaftar di mungu.com dan silahkan masuk.";
                $this->load->view('loginregister/login', $data);
            }
        }
    }
}
