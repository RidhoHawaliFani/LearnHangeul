<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Agivest_model');
        $this->load->model('Home_model');
        $this->load->model('Email_model');
        $this->load->model('OnlineCashierEmailLibrary');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('string');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('upload');
        $this->load->library('Pdf');

    }

    protected $statsSent = 0;

    public function index()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            $data['alamatUser'] = $namaadmin['alamatUser'];

            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listKlasifikasi'] = $this->Home_model->getSelectData("*","klasifikasibarang", "ORDER BY namaKlasifikasi ASC");
            $data['listMerk'] = $this->Home_model->getSelectData("DISTINCT merk","detailbarang", "ORDER BY merk ASC");
            $data['listUkuran'] = $this->Home_model->getSelectData("DISTINCT ukuran","detailbarang", "ORDER BY ukuran ASC");
            $data['listBarang'] = $this->Home_model->getSelectData("*","klasifikasibarang, detailbarang", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND detailbarang.statusBarang='aktif' ORDER BY namaKlasifikasi ASC");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namalengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('transaksi/index' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function searchItemByTappingFilter(){

        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $data['alamatUser'] = $namaadmin['alamatUser'];

            $idUser = $namaadmin['idUser'];


            
            $pilihanFilterisasi = $this->input->post('isi');

            
            

            if ($pilihanFilterisasi=="allchoosen") {
                $data['allItemQuerys'] = $this->Home_model->getSelectData("*","klasifikasibarang, detailbarang", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND detailbarang.statusBarang='aktif' ORDER BY namaKlasifikasi ASC");
            }elseif ($pilihanFilterisasi=="favorite") {
                $data['allItemQuerys'] = $this->Home_model->getSelectData("*","item_stock_actual, item_on_shop, inventory_item", "WHERE inventory_item.idInvItem=item_on_shop.idItemRequest and inventory_item.idInvItem=item_stock_actual.idInvItem and item_on_shop.statusItemOnShop='successed' and inventory_item.favorited=1 and item_stock_actual.idTokoTerkait=$idToko GROUP BY item_on_shop.idItemRequest ORDER BY inventory_item.namaItem ASC");
            }
                
            
            

            
            $output3 = "";
            if (!$data['allItemQuerys']->result()) {
                $output3 .= '<div class="card-body">
                            <div class="col-md-12 alert alert-warning">
                            
                            <span>
                              <b> Info - </b> Tidak ada data yang berkaitan dengan pencarian Anda tersebut. Silahkan coba kembali nanti.</span>
                          </div>
                          </div>';
              }else{

                  foreach($data['allItemQuerys']->result() as $row)
                  {
                    $words = explode(" ", $row->namaKlasifikasi." ".$row->merk);
                    $inisialItem = "";

                    foreach ($words as $w) {
                      $inisialItem .= $w[0];
                    }
                   // $output .= "<div  class='col-md-3' id='dataDetail".$row->idDetailItem."'><div class='card'><div class='card-body'><a href='".base_url()."Managements/show/dataDetail".$row->idDetailItem."' class='text-dark' >".$row->variabel."</a></div></div></div>";
                   $output3 .= '
                                <div class="col-lg-4 col-md-3 col-sm-6 boxing" style="margin:0; margin-bottom:0px;border-radius:12px">
                                
                                <a href="" class="bg-light " rel="tooltip" title="Pilih item '.$row->namaKlasifikasi.' '.$row->merk.'" id="cardItemTombol'.$row->idBarang.'">
                                   <div class="card" >
                                   <div class="item-show-up card-body ">
                                        
                                        <table width="100%">
                                        <tr>
                                            <td style="font-size:30px;text-align:center;text-transform:uppercase; padding-bottom:15px; padding-top:10px;" colspan="2">'.$inisialItem.'</td>
                                        </tr>
                                        <tr>
                                        <td width="100%" colspan="2" class="text-center">
                                        
                                        <b style="font-size:16px; font-weight:bold;text-align:center;display:block;">'.$row->namaKlasifikasi.' '.$row->merk.'</b>
                                        <small>variant <b>'.$row->ukuran.'</b></small></td>
                                        <input type="hidden" id="idInventoryItemHidden" name="nameInventoryItemHidden" value="'.$row->idBarang.'">
                                        </tr>
                                        <td width="35%">
                                        <small style="display: block;">Stock Tersedia</small>
                                        <b style="font-size:13px;font-weight:bold">'.$row->stok.' buah</b></td>
                                        <td width="65%">
                                        <font style="text-align:right; color:#fff">
                                        <small style="display: block;">Harga</small>
                                        <span class="badge badge-light" style="color:#fff;float:right; background-color:#ff1f1f; padding:6px;"><b style="font-size:17px; text-align:right; ">'.number_format($row->harga,0,",",".").'</b></span>

                                        <span class="badge badge-light" style="color:#fff; background-color:#ff1f1f;float:right;font-size:10px; margin-left:10px; margin-right:2px;">Rp</span>
                                        </font>
                                        </td>


                                        
                                        </tr>
                                        
                                        </table>
                                      
                                     
                                    </div>
                                    </div>
                                     </a>
                                    </div>

                                   


                            

                              

                              <script type="text/javascript">
                                  $("#cardItemTombol'.$row->idBarang.'").click(function(event'.$row->idBarang.') {
                                          event'.$row->idBarang.'.preventDefault();
                                          //mengambil data dari form
                                          
                                          var idItemTerpilihNyooo = '.$row->idBarang.';
                                          
                                          var sum =0;
                                        jQuery.ajax({
                                              type: "POST",
                                              url: "'.base_url().'"+"Transaksi/selectItemBySelectionInShopPages",
                                              dataType: "json",
                                          //mengirim data dengan type post
                                          data: {idInvItemTerpilihNya: idItemTerpilihNyooo},
                                          //menerima result dari controller
                                          
                                          success: function(data) {


                                            $("#bagianItemTerpilihShopBasket").append(data.isi);
                                            $("#alertEmptyBasket").fadeOut();
                                            $("#alertEmptyBasketText").fadeOut();


                                            
                                            //$("#searchBoxItemByName").val("");
                                            //$("#choose1").trigger("click");
                                            $("#cardItemTombol'.$row->idBarang.'").remove();


                                          }
                                          
                                        });
                                  });

                                  
                                   

                                  

                                  

                              </script>

                            </div>
                                ';
                  }
                }
              echo json_encode($output3);
             

        }else{

            $this->load->view('loginregister/login.php'); 
        }

    }

    public function searchItemByNameInShopPages(){

        if($this->session->userdata('adminSession')){        
           $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $data['alamatUser'] = $namaadmin['alamatUser'];

            $idUser = $namaadmin['idUser'];

            $pilihanFilterisasi = "";

            $valueDIkirim = $this->input->post('namaItemDiketikkan');
            $idKlasifikasiTerikat = $this->input->post('idKlasifikasiTerikat');

            $pilihanFilterisasi = $this->input->post('pilihanFilter');

            
            

            if ($valueDIkirim=="*") {
                $data['allItemQuery'] = $this->Home_model->getSelectData("*","klasifikasibarang, detailbarang", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND detailbarang.statusBarang='aktif' ORDER BY namaKlasifikasi ASC");
            }
            else {
                $data['allItemQuery'] = $this->Home_model->getSelectData("*, CONCAT_WS(' ',klasifikasibarang.namaKlasifikasi, detailbarang.merk) namaBarangJoined ","klasifikasibarang, detailbarang", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND detailbarang.statusBarang='aktif' AND CONCAT_WS(' ',klasifikasibarang.namaKlasifikasi, detailbarang.merk) LIKE '%$valueDIkirim%' ORDER BY namaKlasifikasi ASC");
            }

            
            $output2 = "";
            if (!$data['allItemQuery']->result()) {
                $output2 .= '<div class="col-md-12">
                            
                            <img id="alertEmptyBasket" alt="Image placeholder" src="'.base_url().'/assets/img/icons/notfound4.png" style="width: 20%;display: block; padding-bottom:0px;text-align: center; margin: auto;">
                                          <span class="text-muted text-center mb-3" style="display: block;font-size: 12px;">Yah, sayang sekali data yang Anda cari tidak ditemukan disini. <br/>Silahkan cari dengan kata kunci yang lain</span>
                          </div>';
              }else{

                  foreach($data['allItemQuery']->result() as $row)
                  {
                    $words = explode(" ", $row->namaKlasifikasi." ".$row->merk);
                    $inisialItem = "";

                    foreach ($words as $w) {
                      $inisialItem .= $w[0];
                    }
                   // $output .= "<div  class='col-md-3' id='dataDetail".$row->idDetailItem."'><div class='card'><div class='card-body'><a href='".base_url()."Managements/show/dataDetail".$row->idDetailItem."' class='text-dark' >".$row->variabel."</a></div></div></div>";
                   $output2 .= '
                                <div class="col-lg-4 col-md-3 col-sm-6 boxing" style="margin:0; margin-bottom:0px;border-radius:12px">
                                
                                <a href="" class="bg-light " rel="tooltip" title="Pilih item '.$row->namaKlasifikasi.' '.$row->merk.'" id="cardItemTombol'.$row->idBarang.'">
                                   <div class="card" >
                                   <div class="item-show-up card-body ">
                                        
                                        <table width="100%">
                                        <tr>
                                            <td style="font-size:30px;text-align:center;text-transform:uppercase; padding-bottom:15px; padding-top:10px;" colspan="2">'.$inisialItem.'</td>
                                        </tr>
                                        <tr>
                                        <td width="100%" colspan="2" class="text-center">
                                        
                                        <b style="font-size:16px; font-weight:bold;text-align:center;display:block;">'.$row->namaKlasifikasi.' '.$row->merk.'</b>
                                        <small>variant <b>'.$row->ukuran.'</b></small></td>
                                        <input type="hidden" id="idInventoryItemHidden" name="nameInventoryItemHidden" value="'.$row->idBarang.'">
                                        </tr>
                                        <td width="35%">
                                        <small style="display: block;">Stock Tersedia</small>
                                        <b style="font-size:13px;font-weight:bold">'.$row->stok.' buah</b></td>
                                        <td width="65%">
                                        <font style="text-align:right; color:#fff">
                                        <small style="display: block;">Harga</small>
                                        <span class="badge badge-light" style="color:#fff;float:right; background-color:#ff1f1f; padding:6px;"><b style="font-size:17px; text-align:right; ">'.number_format($row->harga,0,",",".").'</b></span>

                                        <span class="badge badge-light" style="color:#fff; background-color:#ff1f1f;float:right;font-size:10px; margin-left:10px; margin-right:2px;">Rp</span>
                                        </font>
                                        </td>


                                        
                                        </tr>
                                        
                                        </table>
                                      
                                     
                                    </div>
                                    </div>
                                     </a>
                                    </div>

                                   


                            

                              

                              <script type="text/javascript">
                                  $("#cardItemTombol'.$row->idBarang.'").click(function(event'.$row->idBarang.') {
                                          event'.$row->idBarang.'.preventDefault();
                                          //mengambil data dari form
                                          
                                          var idItemTerpilihNyooo = '.$row->idBarang.';
                                          
                                          var sum =0;
                                        jQuery.ajax({
                                              type: "POST",
                                              url: "'.base_url().'"+"Transaksi/selectItemBySelectionInShopPages",
                                              dataType: "json",
                                          //mengirim data dengan type post
                                          data: {idInvItemTerpilihNya: idItemTerpilihNyooo},
                                          //menerima result dari controller
                                          
                                          success: function(data) {


                                            $("#bagianItemTerpilihShopBasket").append(data.isi);
                                            $("#alertEmptyBasket").fadeOut();
                                            $("#alertEmptyBasketText").fadeOut();


                                            
                                            //$("#searchBoxItemByName").val("");
                                            //$("#choose1").trigger("click");
                                            $("#cardItemTombol'.$row->idBarang.'").remove();


                                          }
                                          
                                        });
                                  });

                                  
                                   

                                  

                                  

                              </script>

                            </div>
                                ';
                  }
                }
              echo json_encode($output2);
             

        }else{

            $this->load->view('loginregister/login.php'); 
        }

    }

    public function selectItemBySelectionInShopPages(){
        $valueDIkirim = $this->input->post('idInvItemTerpilihNya');
    
        
        if ($valueDIkirim) {
            echo $this->Home_model->selectDetailItemModelShopPages($valueDIkirim);
        }
    }

    public function insertPaymentInvoice(){

         if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $data['alamatUser'] = $namaadmin['alamatUser'];

            $idUser = $namaadmin['idUser'];


           $hargaItemNya = $this->input->post('hargaItemNya');
           $idItemNyaaa = $this->input->post('idItemNyaaa');
           $namaItemNyaaa = $this->input->post('namaItemNyaaa');
           $jumlahPesananNya = $this->input->post('jumlahPesananNya');
           $totalHargaNya = $this->input->post('totalHargaNya');
           $codeTrans = $this->input->post('codeTrans');
           
            //$countsize = count($this->input->post('nameVariabelItemHidden'));

                
                       
                        $data = array(

                            'codeTransaction' => $codeTrans,
                            'idBarang' => $idItemNyaaa,
                            'idUser' => $idUser,
                            'hargaSatuan' => $hargaItemNya,
                            'jumlahPesanan' => $jumlahPesananNya,
                            'totalHargaPesanan' => $totalHargaNya,
                            'statusTransaction' => 'Aktif',
                        );

                        $result = $this->Home_model->insertData('transaksi' , $data);
             
                        $resultX = $this->Home_model->updateStockItemWhenPaymentOut($idItemNyaaa , $jumlahPesananNya);        
                           
                   
                        
                        echo json_encode($result);

            
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }


    public function history()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            $data['alamatUser'] = $namaadmin['alamatUser'];

            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listKlasifikasi'] = $this->Home_model->getSelectData("*","klasifikasibarang", "ORDER BY namaKlasifikasi ASC");
            $data['listMerk'] = $this->Home_model->getSelectData("DISTINCT merk","detailbarang", "ORDER BY merk ASC");
            $data['listUkuran'] = $this->Home_model->getSelectData("DISTINCT ukuran","detailbarang", "ORDER BY ukuran ASC");
            $data['listBarang'] = $this->Home_model->getSelectData("*","klasifikasibarang, detailbarang", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND detailbarang.statusBarang='aktif' ORDER BY namaKlasifikasi ASC");
            $data['listTimeTransaction'] = $this->Home_model->getSelectData("*,DATE_FORMAT(transaksi.timeTransaction, '%Y/%m/%d') tglTrans, sum(transaksi.totalHargaPesanan) ttlHargaAll","klasifikasibarang, detailbarang, transaksi", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND transaksi.idBarang=detailbarang.idBarang AND detailbarang.statusBarang='aktif' GROUP BY DAY(transaksi.timeTransaction), MONTH(transaksi.timeTransaction), YEAR(transaksi.timeTransaction) ORDER BY transaksi.timeTransaction DESC");
            $data['listCodeTransaction'] = $this->Home_model->getSelectData("*,DATE_FORMAT(transaksi.timeTransaction, '%Y/%m/%d') tglTrans, sum(transaksi.totalHargaPesanan) ttlEachCodeTransaction","klasifikasibarang, detailbarang, transaksi", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND transaksi.idBarang=detailbarang.idBarang AND detailbarang.statusBarang='aktif' GROUP BY transaksi.codeTransaction ORDER BY transaksi.timeTransaction DESC");
            $data['listItemTransaction'] = $this->Home_model->getSelectData("*,DATE_FORMAT(transaksi.timeTransaction, '%Y/%m/%d') tglTrans","klasifikasibarang, detailbarang, transaksi", "WHERE klasifikasibarang.idKlasifikasi=detailbarang.idKlasifikasi AND transaksi.idBarang=detailbarang.idBarang AND detailbarang.statusBarang='aktif' ORDER BY transaksi.timeTransaction DESC");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namalengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('transaksi/history' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function hapusRiwayatTransaksi()
    {
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['idUser'] = $namaadmin['idUser'];
            $data['alamatUser'] = $namaadmin['alamatUser'];
            
            $kodeSent = $this->input->post('codeTransactionSent');

            $getDataDulu = $this->Home_model->getSelectData("*","transaksi", "WHERE codeTransaction='$kodeSent'");

            foreach ($getDataDulu->result() as $row) {
              
              $resultX = $this->Home_model->updateStockItemWhenCancelPayment($row->idBarang , $row->jumlahPesanan);

            }
            //deletedata!
            $this->Home_model->deleteData('transaksi' , "codeTransaction='$kodeSent'");
            
               
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                $historystats = array('keterangan' => $userLoginName." menghapus transaksi dengan ID transaksi ".$kodeSent);
                
                $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                redirect('Transaksi/history?stats=success_delete', 'refresh');
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    


    

   
}
