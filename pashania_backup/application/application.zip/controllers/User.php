<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Agivest_model');
        $this->load->model('Home_model');
        $this->load->model('Email_model');
        $this->load->model('OnlineCashierEmailLibrary');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('string');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('upload');
        $this->load->library('Pdf');

    }

    protected $statsSent = 0;

    public function index()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            $data['dataPaketConnected'] = $this->Home_model->getSelectData("*,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai,DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %M %Y') tglSelesai,TIMESTAMPDIFF(day,NOW(),pakettourtravel.tglMulaiTour)+1 as rentangWaktu","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Lunas'");
            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/index' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }
    public function editProfile()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/editProfile' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function prosEditProfilUser()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

            $idUser = $namaadmin['idUser'];
         
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $birthday = $this->input->post('birthday');
            $gender = $this->input->post('gender');
            $noKTP = $this->input->post('noKTP');
            $alamat = $this->input->post('alamat');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $kelurahan = $this->input->post('kelurahan');
            $kecamatan = $this->input->post('kecamatan');
            $kabupaten = $this->input->post('kabupaten');
            $provinsi = $this->input->post('provinsi');
            $noPassport = $this->input->post('noPassport');
            $lokasiBuatPassport = $this->input->post('lokasiBuatPassport');
            $tglAktifPassport = $this->input->post('tglAktifPassport');
            $tglExpPassport = $this->input->post('tglExpPassport');
            $namaAyah = $this->input->post('namaAyah');
            $pendidikan = $this->input->post('pendidikan');
            $pekerjaan = $this->input->post('pekerjaan');
            $kodePos = $this->input->post('kodePos');
            $status = $this->input->post('status');
            $noTelp = $this->input->post('noTelp');

            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/pictprofile/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureProfile')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        }

                        if (!$imagename) {
                            $dataInput = array(
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status);
                        }else {
                            $dataInput = array(
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status,
                              'pictureProfile' => 'assets/img/pictprofile/'.$imagename);
                        }
                      
                        
                        $update = $this->Home_model->updateData('user' , $dataInput," idUser=$idUser");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "memperbaharui foto profilnya");
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('User/editProfile?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function editPassword()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
             $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/editPassword' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function prosEditPassword()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

            $idUser = $namaadmin['idUser'];
         
            $passLama = md5($this->input->post('passLama'));
            $passBaru = md5($this->input->post('passBaru'));

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser AND password='$passLama'");
            if ($selectUser->result()) {
                        $dataInput = array(
                        'password' => $passBaru);
                              
                        $update = $this->Home_model->updateData('user' , $dataInput," idUser=$idUser");   
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "memperbaharui password");
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        redirect('User/editPassword?stats=success', 'refresh');
            }else {
                         redirect('User/editPassword?stats=passFalse', 'refresh');
            }
            
                            

                        
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function tambahJemaahByUser()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");

             $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/tambahJemaahByUser' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function lihatDataJemaahByUser()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataUserConnected'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUserRegistering=$idUser");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
             
             $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/lihatDataJemaah' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function tambahJemaahByUserProses()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

            $idUser = $namaadmin['idUser'];
         
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $birthday = $this->input->post('birthday');
            $gender = $this->input->post('gender');
            $noKTP = $this->input->post('noKTP');
            $alamat = $this->input->post('alamat');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $kelurahan = $this->input->post('kelurahan');
            $kecamatan = $this->input->post('kecamatan');
            $kabupaten = $this->input->post('kabupaten');
            $provinsi = $this->input->post('provinsi');
            $noPassport = $this->input->post('noPassport');
            $lokasiBuatPassport = $this->input->post('lokasiBuatPassport');
            $tglAktifPassport = $this->input->post('tglAktifPassport');
            $tglExpPassport = $this->input->post('tglExpPassport');
            $namaAyah = $this->input->post('namaAyah');
            $pendidikan = $this->input->post('pendidikan');
            $pekerjaan = $this->input->post('pekerjaan');
            $kodePos = $this->input->post('kodePos');
            $status = $this->input->post('status');
            $noTelp = $this->input->post('noTelp');

            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/pictprofile/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureProfile')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        }

                        if (!$imagename) {
                            $dataInput = array(
                              'statusLevelUser' => '50',
                              'idUserRegistering' => $idUser,
                              'activeUser' => 'A',
                              'username' => '-----------',
                              'password' => '-----------',
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status);
                        }else {
                            $dataInput = array(
                              'statusLevelUser' => '50',
                              'idUserRegistering' => $idUser,
                              'activeUser' => 'A',
                              'username' => '-----------',
                              'password' => '-----------',
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status,
                              'pictureProfile' => 'assets/img/pictprofile/'.$imagename);
                        }
                      
                        
                        $simpan = $this->Home_model->insertData('user' , $dataInput);


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "memperbaharui foto profilnya");
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('User/tambahJemaahByUser?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function editDataUserByUser()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $dataID = $this->uri->segment(3);

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$dataID");
            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
             $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/editProfileByUser' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }

    public function prosEditProfilUser2()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];

         
            $idUser = $this->input->post('idUser');
            $namalengkap = $this->input->post('namalengkap');
            $tempatlahir = $this->input->post('tempatlahir');
            $birthday = $this->input->post('birthday');
            $gender = $this->input->post('gender');
            $noKTP = $this->input->post('noKTP');
            $alamat = $this->input->post('alamat');
            $rt = $this->input->post('rt');
            $rw = $this->input->post('rw');
            $kelurahan = $this->input->post('kelurahan');
            $kecamatan = $this->input->post('kecamatan');
            $kabupaten = $this->input->post('kabupaten');
            $provinsi = $this->input->post('provinsi');
            $noPassport = $this->input->post('noPassport');
            $lokasiBuatPassport = $this->input->post('lokasiBuatPassport');
            $tglAktifPassport = $this->input->post('tglAktifPassport');
            $tglExpPassport = $this->input->post('tglExpPassport');
            $namaAyah = $this->input->post('namaAyah');
            $pendidikan = $this->input->post('pendidikan');
            $pekerjaan = $this->input->post('pekerjaan');
            $kodePos = $this->input->post('kodePos');
            $status = $this->input->post('status');
            $noTelp = $this->input->post('noTelp');

            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/pictprofile/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('pictureProfile')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        }

                        if (!$imagename) {
                            $dataInput = array(
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status);
                        }else {
                            $dataInput = array(
                              'namaLengkap' => $namalengkap,
                              'tempatLahir' => $tempatlahir,
                              'birthday' => $birthday,
                              'gender' => $gender,
                              'noKTP' => $noKTP,
                              'alamat' => $alamat,
                              'rt' => $rt,
                              'rw' => $rw,
                              'kelurahan' => $kelurahan,
                              'kecamatan' => $kecamatan,
                              'kabupaten' => $kabupaten,
                              'provinsi' => $provinsi,
                              'noPassport' => $noPassport,
                              'lokasiBuatPassport' => $lokasiBuatPassport,
                              'tglExpPassport' => $tglExpPassport,
                              'tglAktifPassport' => $tglAktifPassport,
                              'namaAyah' => $namaAyah,
                              'pendidikan' => $pendidikan,
                              'noTelp' => $noTelp,
                              'pekerjaan' => $pekerjaan,
                              'kodePos' => $kodePos,
                              'status' => $status,
                              'pictureProfile' => 'assets/img/pictprofile/'.$imagename);
                        }
                      
                        
                        $update = $this->Home_model->updateData('user' , $dataInput," idUser=$idUser");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "memperbaharui foto profilnya");
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('User/lihatDataJemaahByUser?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosAddNewPaketRequest()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            $idUser = $namaadmin['idUser'];

         
            $idUserTambahan = $this->input->post('idUserTambahan');
            $kodePaketTour = $this->input->post('kodePaketTour');
            $idPaket = $this->input->post('idPaket');
            $hargaSatuanPaket = $this->input->post('hargaSatuanPaket');
            $hargaTotalPaket = $this->input->post('hargaTotalPaket');
            $NewDate=Date('y:m:d H:i:s', strtotime("+3 days"));

            if ($hargaTotalPaket=="") {
                $hargaTotalPaket = $hargaSatuanPaket;
            }

                        
                            $dataInput = array(
                              'kodePaketTour' => $kodePaketTour,
                              'idUser' => $idUser,
                              'idUserTambahan' => $idUserTambahan,
                              'idPaket' => $idPaket,
                              'hargaSatuanPaket' => $hargaSatuanPaket,
                              'hargaTotalPaket' => $hargaTotalPaket,
                              'tglExpiredPesanan    ' => $NewDate,
                              'statusPembayaran' => "Menunggu Pembayaran",
                             );
                        
                        $update = $this->Home_model->insertData('tagihanpembayaran', $dataInput);   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "membuat pesanan paket tour dengan Kode ".$kodePaketTour);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        $output['statsupdatenya'] = "berhasil";
                        $output['kodePaketTour'] = $kodePaketTour;
                        echo json_encode($output);
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function lihatTagihanPembayaran()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];


            $idUser = $namaadmin['idUser'];

            $data['dataUser'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUser=$idUser");
            $data['dataUserConnected'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUserRegistering=$idUser");
            $data['dataPaymentBelumBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran='Menunggu Pembayaran'");
            $data['dataPaymentSudahBayar'] = $this->Home_model->getSelectData("*, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y') tglExpired, DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%H:%i:%s') jamExpired,  DATE_FORMAT(tagihanpembayaran.tglDibayar, '%d %M %Y') tglDibayar, DATE_FORMAT(tagihanpembayaran.tglDibayar, '%H:%i:%s') jamDibayar","user, tagihanpembayaran, pakettourtravel", "WHERE user.idUser=$idUser AND user.idUser=tagihanpembayaran.idUser AND pakettourtravel.idPaket=tagihanpembayaran.idPaket AND tagihanpembayaran.statusPembayaran!='Menunggu Pembayaran'");

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('userPage/lihatTagihanPembayaran' , $data);
        }else{

            $this->load->view('loginregister/login.php'); 
        }

        // $this->load->view('index');
    }
    public function prosesUploadBuktiPembayaran()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];
            $dateNow = date("Y-m-d H:i:s");
            
         
            $kodePaketTourGet = $this->input->post('kodePaketTourGet');
           
            $imagename = "";

            
                    //UPLOAD GAMBAAAAAAAAAAAR -----------------------------------------------------------------
                    
                        $initialize = $this->upload->initialize(array(
                            "upload_path" => 'assets/img/gambarbuktipembayaran/',
                            "allowed_types" => "gif|jpg|jpeg|png|bmp",
                            "remove_spaces" => TRUE
                        ));

                    

                        if (!$this->upload->do_upload('uploadgambar')) {
                            $error = array('error' => $this->upload->display_errors());
                            echo $this->upload->display_errors();
                        } else {
                            $data = $this->upload->data();
                            $imagename = $data['file_name'];
                            
                        } 
                      

                    
                        $dataInput = array(
                              'tglDibayar' => $dateNow,
                              'statusPembayaran' => 'Menunggu Konfirmasi',
                              'pictureTagihan' => 'assets/img/gambarbuktipembayaran/'.$imagename
                            );
                        
                        $update = $this->Home_model->updateData('tagihanpembayaran' , $dataInput," kodePaketTour='$kodePaketTourGet'");   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "membayar tagihan #".$kodePaketTourGet);
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('User/lihatTagihanPembayaran?stats=paymentSuccess', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

    public function prosesAddTestimoni()
    {
        if($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $testimoni = $this->input->post('testimoni');
                    
                        $dataInput = array(
                              'testimoni' => $testimoni,
                              'idUser' => $idUser,
                              'statusTestimoni' => 'aktif'
                            );
                        
                        $update = $this->Home_model->insertData('testimoni' , $dataInput);   


                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!
                        $historystats = array('idUser' => $idUser,'keterangan' => "menambahkan testimoni.");
                        
                        $savehistory = $this->Home_model->insertData('historyproses' , $historystats);
                        //history side---------------------------------------------------------------------------------------------------DONT DISTURB THIS SIDE!

                        redirect('User/Index?stats=success', 'refresh');
          
        }else{

            $this->load->view('loginregister/login.php'); 
        }
    }

   
}
