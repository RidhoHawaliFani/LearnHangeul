<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use Twilio\Rest\Client;

class Welcome extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model('Agivest_model');
        $this->load->model('Home_model');
        $this->load->model('Email_model');
        $this->load->model('Email_Notification_Expired_model');
        $this->load->model('OnlineCashierEmailLibrary');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->helper('string');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    public function index()
    {
       
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' ORDER BY tglMulaiTour DESC LIMIT 4");
            $data['listPaketTourAll'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,TIMESTAMPDIFF(day,createdAt,NOW()) as newestItems,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' ORDER BY tglMulaiTour DESC");
            $data['listArtikel'] = $this->Home_model->getSelectData("*,DATE_FORMAT(artikel.tglPublish, '%d %b %Y') tglPublikasi","artikel", "WHERE statusArtikel='aktif' ORDER BY tglPublish DESC LIMIT 4");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*,DATE_FORMAT(testimoni.tglTestimoni, '%d %b %Y') tglTestimoni","user,testimoni", "WHERE user.idUser=testimoni.idUser AND testimoni.statusTestimoni='aktif' ORDER BY RAND() LIMIT 5");
            $data['listGaleri'] = $this->Home_model->getSelectData("*,DATE_FORMAT(galeri.tglCreated, '%d %b %Y') tglCreated","galeri", "WHERE galeri.statusGaleri='aktif' ORDER BY RAND()");

            $data['countMemberAktif'] = $this->Home_model->getSelectData("*","user", "WHERE user.activeUser='A' and statusLevelUser=2");
            $data['countCalonJemaahBerangkat'] = $this->Home_model->getSelectData("sum(currentMember) jmlJemaahBerangkat","pakettourtravel", "WHERE statusTour='aktif' AND tglMulaiTour > NOW()");
            $data['countNextPerjalanan'] = $this->Home_model->getSelectData("*","pakettourtravel", "WHERE statusTour='aktif' AND tglMulaiTour > NOW()");
            $data['countTestimony'] = $this->Home_model->getSelectData("*","testimoni", "WHERE statusTestimoni='aktif'");

            $data['tampilHeadline'] = $this->Home_model->getSelectData("*","headline", "ORDER BY idHeadline DESC LIMIT 1");
            
            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('index' , $data);
        }elseif($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['listPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' ORDER BY tglMulaiTour DESC LIMIT 4");
            $data['listPaketTourAll'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,TIMESTAMPDIFF(day,createdAt,NOW()) as newestItems,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' ORDER BY tglMulaiTour DESC");
            $data['listArtikel'] = $this->Home_model->getSelectData("*,DATE_FORMAT(artikel.tglPublish, '%d %b %Y') tglPublikasi","artikel", "WHERE statusArtikel='aktif' ORDER BY tglPublish DESC LIMIT 4");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*,DATE_FORMAT(testimoni.tglTestimoni, '%d %b %Y') tglTestimoni","user,testimoni", "WHERE user.idUser=testimoni.idUser AND testimoni.statusTestimoni='aktif' ORDER BY RAND() LIMIT 5");
            $data['listGaleri'] = $this->Home_model->getSelectData("*,DATE_FORMAT(galeri.tglCreated, '%d %b %Y') tglCreated","galeri", "WHERE galeri.statusGaleri='aktif' ORDER BY RAND()");

            $data['countMemberAktif'] = $this->Home_model->getSelectData("*","user", "WHERE user.activeUser='A' and statusLevelUser=2");
            $data['countCalonJemaahBerangkat'] = $this->Home_model->getSelectData("sum(currentMember) jmlJemaahBerangkat","pakettourtravel", "WHERE statusTour='aktif' AND tglMulaiTour > NOW()");
            $data['countNextPerjalanan'] = $this->Home_model->getSelectData("*","pakettourtravel", "WHERE statusTour='aktif' AND tglMulaiTour > NOW()");
            $data['countTestimony'] = $this->Home_model->getSelectData("*","testimoni", "WHERE statusTestimoni='aktif'");

            $data['tampilHeadline'] = $this->Home_model->getSelectData("*","headline", "ORDER BY idHeadline DESC LIMIT 1");


            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('index' , $data);
        }else{
            $data['levelUser'] = "";
            $data['listPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' ORDER BY tglMulaiTour DESC LIMIT 4");
            $data['listArtikel'] = $this->Home_model->getSelectData("*,DATE_FORMAT(artikel.tglPublish, '%d %b %Y') tglPublikasi","artikel", "WHERE statusArtikel='aktif' ORDER BY tglPublish DESC LIMIT 4");
            $data['listPaketTourAll'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,TIMESTAMPDIFF(day,createdAt,NOW()) as newestItems,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %b %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' ORDER BY tglMulaiTour DESC");
            $data['listTestimoni'] = $this->Home_model->getSelectData("*,DATE_FORMAT(testimoni.tglTestimoni, '%d %b %Y') tglTestimoni","user,testimoni", "WHERE user.idUser=testimoni.idUser AND testimoni.statusTestimoni='aktif' ORDER BY RAND() LIMIT 5");
            $data['listGaleri'] = $this->Home_model->getSelectData("*,DATE_FORMAT(galeri.tglCreated, '%d %b %Y') tglCreated","galeri", "WHERE galeri.statusGaleri='aktif' ORDER BY RAND()");


            $data['countMemberAktif'] = $this->Home_model->getSelectData("*","user", "WHERE user.activeUser='A' and statusLevelUser=2");
            $data['countCalonJemaahBerangkat'] = $this->Home_model->getSelectData("sum(currentMember) jmlJemaahBerangkat","pakettourtravel", "WHERE statusTour='aktif' AND tglMulaiTour > NOW()");
            $data['countNextPerjalanan'] = $this->Home_model->getSelectData("*","pakettourtravel", "WHERE statusTour='aktif' AND tglMulaiTour > NOW()");
            $data['countTestimony'] = $this->Home_model->getSelectData("*","testimoni", "WHERE statusTestimoni='aktif'");

            $data['tampilHeadline'] = $this->Home_model->getSelectData("*","headline", "ORDER BY idHeadline DESC LIMIT 1");


            
            $this->load->view('index', $data); 
        }
       
        // $this->load->view('index');
    }

    public function termsCondition()
    {
       
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('terms_condition' , $data);
        }elseif($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('terms_condition' , $data);
        }else{
            $data['levelUser'] = "";
            $this->load->view('terms_condition', $data); 
        }
       
        // $this->load->view('index');
    }

    public function detailPaketTour()
    {
       
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $dataID = $this->uri->segment(3);
            $data['listPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' AND idPaket=$dataID");
            
            $tglMulai ="";
            foreach ($data['listPaketTour']->result() as $row) {
                $tglMulai = $row->tglMulaiTour;
            }
            $data['tglMulaiTour'] = $tglMulai;

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUserConnected'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUserRegistering=$idUser");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('detail_paket_tour' , $data);
        }elseif($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $dataID = $this->uri->segment(3);
            $data['listPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' AND idPaket=$dataID");

            $tglMulai ="";
            foreach ($data['listPaketTour']->result() as $row) {
                $tglMulai = $row->tglMulaiTour;
            }
            $data['tglMulaiTour'] = $tglMulai;

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUserConnected'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUserRegistering=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('detail_paket_tour' , $data);
        }else{
            $data['namaUserGiven'] = "";
            $data['dataUserConnected'] = "";
            $dataID = $this->uri->segment(3);
            $data['idUser'] = "";
            $data['levelUser'] = "";
            $data['listPaketTour'] = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tglMulaiTour,tglSelesaiTour)+1 as rentangWaktu,DATE_FORMAT(pakettourtravel.tglMulaiTour, '%d %M %Y') tglMulai, DATE_FORMAT(pakettourtravel.tglSelesaiTour, '%d %b %Y') tglSelesai","pakettourtravel", "WHERE statusTour='aktif' AND idPaket=$dataID");

            $tglMulai ="";
            foreach ($data['listPaketTour']->result() as $row) {
                $tglMulai = $row->tglMulaiTour;
            }
            $data['tglMulaiTour'] = $tglMulai;

            $this->load->view('detail_paket_tour', $data); 
        }
       
        // $this->load->view('index');
    }

    public function invoice()
    {
            $dataID = $this->uri->segment(3);
            $getUserResponsible = $this->Home_model->getSelectData("*,TIMESTAMPDIFF(day,tagihanpembayaran.tglPesanan,tagihanpembayaran.tglExpiredPesanan) as rentangWaktu,DATE_FORMAT(tagihanpembayaran.tglExpiredPesanan, '%d %M %Y (%H:%i') tglExpired,DATE_FORMAT(tagihanpembayaran.tglPesanan, '%d %M %Y') tglPembuatan, DATE_FORMAT(tagihanpembayaran.tglPesanan, '%H:%i') jamPembuatan","user, tagihanpembayaran", "WHERE tagihanpembayaran.kodePaketTour='$dataID' AND user.idUser=tagihanpembayaran.idUser");

            $idArray = "";

            foreach ($getUserResponsible->result() as $row) {
                $idArray = $row->idUser.",".$row->idUserTambahan;
                $data['kodePesanan'] =  $row->kodePaketTour;
                $data['getExpiredDate'] =  $row->tglExpired;
                $data['sisaWaktu'] =  $row->rentangWaktu;
                $data['totalHarga'] =  $row->hargaTotalPaket;
                $data['tglPembuatan'] =  $row->tglPembuatan;
                $data['jamPembuatan'] =  $row->jamPembuatan;
                $data['statusPembayaran'] =  $row->statusPembayaran;
            }
            $data['getDataUsers'] = $this->Home_model->getSelectData("*","user, tagihanpembayaran", "WHERE tagihanpembayaran.kodePaketTour='$dataID' AND user.idUser IN ($idArray)");


            $this->load->view('invoice', $data);
        
    }

    public function detailArtikel()
    {
       
        if($this->session->userdata('adminSession')){        
            $namaadmin = $this->session->userdata('adminSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $dataID = $this->uri->segment(3);
            $data['listPaketTour'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y') tglPublikasi","artikel", "WHERE statusArtikel='aktif' AND idArtikel=$dataID");
            $data['listKomentar'] = $this->Home_model->getSelectData("*,DATE_FORMAT(artikel.tglPublish, '%d %M %Y') tglPembuatan, DATE_FORMAT(artikel.tglPublish, '%H:%i') jamPembuatan","artikel, komentarartikel", "WHERE artikel.idArtikel=$dataID AND artikel.idArtikel=komentarartikel.idArtikel AND komentarartikel.statusKomentar='aktif' ORDER BY komentarartikel.tglKomentar DESC");

            $namaUser = "";
            $pictureUser = "";


            //UPDATE READ COUNT
            $this->Home_model->updateCountReadBy($dataID);


            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            $data['dataUserConnected'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUserRegistering=$idUser");

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('detail_artikel_blog' , $data);
        }elseif($this->session->userdata('userSession')){        
            $namaadmin = $this->session->userdata('userSession');
            $data['namaLengkap'] = $namaadmin['namaLengkap'];
            $userLoginName = $namaadmin['namaLengkap'];
            $data['levelUser'] = "";
            $data['levelUser'] = $namaadmin['levelUser'];
            $data['idUser'] = $namaadmin['idUser'];
            
            $idUser = $namaadmin['idUser'];

            $dataID = $this->uri->segment(3);
            $data['listPaketTour'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y') tglPublikasi","artikel", "WHERE statusArtikel='aktif' AND idArtikel=$dataID");
            $data['listKomentar'] = $this->Home_model->getSelectData("*,DATE_FORMAT(artikel.tglPublish, '%d %M %Y') tglPembuatan, DATE_FORMAT(artikel.tglPublish, '%H:%i') jamPembuatan","artikel, komentarartikel", "WHERE artikel.idArtikel=$dataID AND artikel.idArtikel=komentarartikel.idArtikel AND komentarartikel.statusKomentar='aktif' ORDER BY komentarartikel.tglKomentar DESC");


            $namaUser = "";
            $pictureUser = "";

            $selectUser = $this->Home_model->getSelectData("*","user", "WHERE idUser=$idUser");
            
            //UPDATE READ COUNT
            $this->Home_model->updateCountReadBy($dataID);


            $data['dataUserConnected'] = $this->Home_model->getSelectData("*, DATE_FORMAT(user.birthday, '%d %M %Y') tglUltah","user", "WHERE user.idUserRegistering=$idUser");
            

            foreach ($selectUser->result() as $row) {
                # code...
                $namaUser = $row->namaLengkap;
                $pictureUser = $row->pictureProfile;
            }

            $data['namaUserGiven'] = $namaUser;
            $data['pictureUserGiven'] = $pictureUser;
            
            
            $this->load->view('detail_artikel_blog' , $data);
        }else{
            $data['namaUserGiven'] = "";
            $data['dataUserConnected'] = "";
            $dataID = $this->uri->segment(3);
            $data['idUser'] = "";
            $data['levelUser'] = "";
            $data['listPaketTour'] = $this->Home_model->getSelectData("*, DATE_FORMAT(artikel.tglPublish, '%d %b %Y') tglPublikasi","artikel", "WHERE statusArtikel='aktif' AND idArtikel=$dataID");



            //UPDATE READ COUNT
            $this->Home_model->updateCountReadBy($dataID);



            $data['listKomentar'] = $this->Home_model->getSelectData("*,DATE_FORMAT(artikel.tglPublish, '%d %M %Y') tglPembuatan, DATE_FORMAT(artikel.tglPublish, '%H:%i') jamPembuatan","artikel, komentarartikel", "WHERE artikel.idArtikel=$dataID AND artikel.idArtikel=komentarartikel.idArtikel AND komentarartikel.statusKomentar='aktif' ORDER BY komentarartikel.tglKomentar DESC");

            $this->load->view('detail_artikel_blog', $data); 
        }
       
        // $this->load->view('index');
    }

    public function prosAddComment()
    {
        
            
         
            $idArtikel = $this->input->post('idArtikel');
            $nama = $this->input->post('nama');
            $komentar = $this->input->post('komentar');
            
                    
                        $dataInput = array(
                              'idArtikel' => $idArtikel,
                              'nama' => $nama,
                              'komentar' => $komentar,
                              'statusKomentar' => 'aktif',
                                
                            );
                        
                        $simpan = $this->Home_model->insertData('komentarartikel' , $dataInput);


                        redirect('Welcome/detailArtikel/'.$idArtikel.'?stats=success', 'refresh');
          
        
    }
    
    
}
