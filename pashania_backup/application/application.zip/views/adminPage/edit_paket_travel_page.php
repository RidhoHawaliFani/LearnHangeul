<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />

  <style type="text/css">
    .pilihanHewan {
      position: relative;
      transition: all 0.05s linear 0s;

    }
    .pilihanHewan:hover {
      cursor: pointer;
    }
    .pilihanHewan:active {
      transform: scale(0.8,0.8);
    }

    * {
      margin: 0;
      padding: 0
    }

    html {
      height: 100%
    }

    
    #formBerzakat fieldset {

      border: 0 none;
      border-radius: 0.5rem;
      box-sizing: border-box;
      width: 100%;
      margin: 0;
      padding-bottom: 20px;
      position: relative
    }

    #formBerzakat fieldset:not(:first-of-type) {
      display: none
    }

    
    
    
    #formBerzakat .actbtn {
      width: 100px;
      background: #1ed643;
      font-weight: bold;
      color: white;
      border: 0 none;
      border-radius: 7px;
      cursor: pointer;
      padding: 10px 5px;
      margin: 10px 5px;
      float: right;
    }
    #formBerzakat .actbtn:disabled {
      
      background: #ddd;
      
    }
    #formBerzakat .actbtn:disabled:hover,
    #formBerzakat .actbtn:focus {
      box-shadow: 0 0 0 2px white, 0 0 0 3px #ddd
    }

    #formBerzakat .actbtn:hover,
    #formBerzakat .actbtn:focus {
      box-shadow: 0 0 0 2px white, 0 0 0 3px #1ed643
    }

    #formBerzakat .actbtn-previous {
      width: 100px;
      background: #ddd;
      font-weight: bold;
      color: white;
      border: 0 none;
      border-radius: 7px;
      cursor: pointer;
      padding: 10px 5px;
      margin: 10px 5px
    }

    #formBerzakat .actbtn-previous:hover,
    #formBerzakat .actbtn-previous:focus {
      box-shadow: 0 0 0 2px white, 0 0 0 3px #ddd
    }

    

    select.list-dt:focus {
      border-bottom: 2px solid #1ed643
    }

    .card {
      z-index: 0;
      border: none;

      position: relative
    }

    #progressbar {
      margin-bottom: 30px;
      overflow: hidden;
      color: lightgrey;
      text-align: center;
    }

    #progressbar .active {
      color: #000000
    }

    #progressbar li {
      list-style-type: none;
      font-size: 12px;
      width: 25%;
      float: left;
      position: relative
    }

    #progressbar #thumbnail:before {
      font-family: FontAwesome;
      content: "\f03e"
    }

    #progressbar #account:before {
      font-family: FontAwesome;
      content: "\f023"
    }

    #progressbar #personal:before {
      font-family: FontAwesome;
      content: "\f007"
    }

    #progressbar #payment:before {
      font-family: FontAwesome;
      content: "\f129"
    }

    #progressbar #confirm:before {
      font-family: FontAwesome;
      content: "\f0a1"
    }

    #progressbar li:before {
      width: 50px;
      height: 50px;
      line-height: 45px;
      display: block;
      font-size: 18px;
      color: #ffffff;
      background: lightgray;
      border-radius: 50%;
      margin: 0 auto 10px auto;
      padding: 2px
    }

    #progressbar li:after {
      content: '';
      width: 100%;
      height: 2px;
      background: lightgray;
      position: absolute;
      left: 0;
      top: 25px;
      z-index: -1
    }

    #progressbar li.active:before,
    #progressbar li.active:after {
      background: #1ed643
    }

    .inputfile {
      width: 0.1px;
      height: 0.1px;
      opacity: 0;
      overflow: hidden;
      position: absolute;
      z-index: -1;
    }
    .inputfile + label {
      font-size: 14px;
      font-weight: 200;
      color: white;
      background-color: black;
      display: inline-block;
      padding: 15px;
      padding-left: 25px; padding-right: 25px;
      cursor: pointer;
      border-radius: 3px;
    }

    .inputfile:focus + label,
    .inputfile + label:hover {
      background-color: #ebca13;
    }

    .square {
      width: 350px;
      height: 350px;
      
      background-size: cover;
      background-position: center;
      background-origin:  content-box;
      background-attachment: local;

      display: block;
      margin: auto;
      text-align: center;
      border-radius: 10px;
      margin-bottom: 15px;
    }
    /* Material design styling */

    /*placeholder style*/

    .note-placeholder {
      position: absolute;
      top: 20%;
      left: 5%;
      font-size: 2rem;
      color: #e4e5e7;
      pointer-events: none;
    }

    /*Toolbar panel*/

    .note-editor .note-toolbar {
      background: #f0f0f1;
      border-bottom: 1px solid #c2cad8;
      -webkit-box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.14), 0 3px 4px 0 rgba(0, 0, 0, 0.12), 0 1px 5px 0 rgba(0, 0, 0, 0.2);
      box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.14), 0 3px 4px 0 rgba(0, 0, 0, 0.12), 0 1px 5px 0 rgba(0, 0, 0, 0.2);
    }

    /*Buttons from toolbar*/

    .summernote .btn-group, .popover-content .btn-group {
      background: transparent;
      -webkit-box-shadow: none;
      box-shadow: none;
    }

    .note-popover {
      background: #f0f0f1!important;
    }

    .summernote .btn, .note-btn {
      color: rgba(0, 0, 0, .54)!important;
      background-color: transparent!important;
      padding: 6px 12px;
      font-size: 14px;
      line-height: 1.42857;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-box-shadow: none;
      box-shadow: none;
    }

    .summernote .dropdown-toggle:after {
      vertical-align: middle;
    }

    .note-editor.card {
      -webkit-box-shadow: none;
      box-shadow: none;
      border-radius: 2px;
    }

    /* Border of the Summernote textarea */

    .note-editor.note-frame {
      border: 1px solid rgba(0, 0, 0, .14);
    }

    /* Padding of the text in textarea */

    .note-editor.note-frame .note-editing-area .note-editable {
      padding-top: 1rem;
    }

  </style>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-bs4.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('Managements/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('Managements/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Edit Data Paket Tour</h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          <form class="search-form d-none d-md-block" action="#">
            <i class="icon-magnifier"></i>
            <input type="search" class="form-control" placeholder="Search Here" title="Search here">
          </form>

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <img class="img-xs rounded-circle ml-2" src="<?php echo base_url(); ?>/assets_adminuser/images/faces/face8.jpg" alt="Profile image"> <span class="font-weight-normal"> Henry Klein </span></a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                <div class="dropdown-header text-center">
                  <img class="img-md rounded-circle" src="<?php echo base_url(); ?>/assets_adminuser/images/faces/face8.jpg" alt="Profile image">
                  <p class="mb-1 mt-3">Allen Moreno</p>
                  <p class="font-weight-light text-muted mb-0">allenmoreno@gmail.com</p>
                </div>
                <a class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> My Profile <span class="badge badge-pill badge-danger">1</span></a>
                <a class="dropdown-item"><i class="dropdown-item-icon icon-speech text-primary"></i> Messages</a>
                <a class="dropdown-item"><i class="dropdown-item-icon icon-energy text-primary"></i> Activity</a>
                <a class="dropdown-item"><i class="dropdown-item-icon icon-question text-primary"></i> FAQ</a>
                <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Sign Out</a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="icon-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav" style="">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="profile-image">
             <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
             <div class="dot-indicator bg-success"></div>
           </div>
           <div class="text-wrapper">
            <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
            <p class="designation">Administrator</p>
          </div>

        </a>
      </li>
      <li class="nav-item nav-category">
        <span class="nav-link">Dashboard</span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
          <span class="menu-title">Dashboard</span>
          <i class="icon-screen-desktop menu-icon"></i>
        </a>
      </li>
      <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
          <span class="menu-title">Paket Umroh & Haji</span>
          <i class="icon-book-open menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">

        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Jemaah</span>
          <i class="icon-people menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

          <?php
          $no=0;
          if(!$dataPaymentSudahBayar->result()){ ?>
            <span class="menu-title">Pembayaran </span>
          <?php }else {

            ?>
            <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
              <span class="wave"></span>
              <span class="wave"></span>
              <span class="wave"></span>
            </div>
            <span class="menu-title">Pembayaran 
              <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
            </div>



          </span>

        <?php } ?>
        <i class="icon-wallet menu-icon"></i>
      </a>
    </li>

    <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
    <li class="nav-item">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
          <span class="menu-title">Buat Artikel Baru</span>
          <i class="icon-notebook menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
          <span class="menu-title">Daftar Artikel</span>
          <i class="icon-list menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
          <span class="menu-title">Komentar</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
    <li class="nav-item">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
          <span class="menu-title">Testimoni</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
          <span class="menu-title">Galeri Foto</span>
          <i class="icon-picture menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
      </span>
    </li>

    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
      </span>
    </li>
  </ul>
</nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title"><a href="<?php echo site_url('Managements/ManajemenPaket');?>" class="btn btn-sm"><i class="icon-arrow-left mr-1"></i></a> Formulir Edit Paket Tour</h4>

                  <p class="card-description ml-5"> Silahkan diisi sesuai pengaturan terbaru Anda. </p>

                  <form role="form" method="post" id="formBerzakat" class="forms-sample" action="<?php echo site_url('Managements/prosEditPaketTour');?>" enctype="multipart/form-data">

                    <ul id="progressbar" style="margin-left: -10px;margin-right: -11px;">
                      <li class="active" id="thumbnail"><strong>Thumbnail</strong></li>
                      <li id="account"><strong>Umum</strong></li>
                      <li id="confirm"><strong>Rencana Perjalanan</strong></li>
                      <li id="payment"><strong>Syarat & Ketentuan</strong></li>
                    </ul> <!-- fieldsets -->


                                          <?php
                                            $no=0;
                                          if(!$selectPacketTour->result()){ ?>
                                            
                                          <p class="card-description"> Sorry, no data can be retrieve right now.</p>                                            
                                            
                                          <?php }else {
                                            foreach ($selectPacketTour->result() as $row) {
                                             
                                          ?>

                    <fieldset>

                      <div class="row">
                        <div class="col-md-12 mb-4 ">
                          <div class="card" style="background-color: #fafafa;">
                            <div class="card-body">
                              <div class="row">
                                <div class="col-md-4 col-sm-6 ">
                                  <div class="square" id="previewing" style="display:block;background-image: url('<?php echo base_url(); ?>/<?php echo $row->picturePaket;?>');width: 250px; height: 200px;"></div>

                                  <font style="display: block;text-align: center; font-size: 11px;" class="text-muted">Preview picture</font>
                                </div>
                                <div class="col-md-4 col-sm-6 ">
                                  <b>Keterangan foto</b> <br/><br/>
                                  <div style="margin-bottom: 17px; border-bottom:1px solid #d1d1d1; padding-bottom: 13px; display: block; font-size: 12px;">Nama file <font class="float-right" style="font-weight: bold;" id="name_fileuploaded">-</font></div>
                                  <div style="margin-bottom: 17px; border-bottom:1px solid #d1d1d1; padding-bottom: 13px; display: block; font-size: 12px;">Ukuran file <font class="float-right" style="font-weight: bold;" id="size_fileuploaded">-</font></div>
                                  <div style="margin-bottom: 17px; border-bottom:1px solid #d1d1d1; padding-bottom: 13px; display: block; font-size: 12px;">Format file <font class="float-right" style="font-weight: bold;" id="format_fileuploaded">-</font></div>


                                </div>
                                <div class="col-md-4 col-sm-6 text-right">
                                  <input type="file" name="picturePaket" id="file" class="inputfile tripleh" />
                                  <label for="file">Pilih Gambar</label>
                                </div>
                              </div>

                            </div>
                          </div>
                        </div>
                      </div>

                      <input type="button" name="next" class="next actbtn" value="Lanjut" style="margin: auto; text-align: center;" id="btnTombolNextFirstSlide"/>

                    </fieldset>
                    <fieldset>

                      <div class="row">
                        <div class="col-md-12 mb-4 ">
                          <div class="card" style="background-color: #fafafa;">
                            <div class="card-body">

                              <div class="form-group">
                                <label for="exampleSelectGender">Kategori</label>
                                <select class="form-control" id="exampleSelectGender" name="jenisPaket" required="">
                                  <option value="haji" <?php if($row->jenisPaket=='haji') echo "selected";?>>Haji</option>
                                  <option value="umroh" <?php if($row->jenisPaket=='umroh') echo "selected";?>>Umroh</option>
                                </select>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputName1">Nama Tour</label>
                                <input type="text" class="form-control" id="exampleInputName1" placeholder="Tentukan nama tour..." name="namapaket" required="" value="<?php echo $row->namaPaket;?>">
                                <input type="hidden" class="form-control" id="idHide" name="idpakethide" required="" value="<?php echo $row->idPaket;?>">
                              </div>
                              <div class="form-group">
                                <label for="exampleInputName2">Lokasi Tujuan</label>
                                <input type="text" class="form-control" id="exampleInputName2" placeholder="Contoh : Mekkah - Madinah - Turki" name="tujuanPaket" required="" value="<?php echo $row->tujuanPaket;?>">
                              </div>
                              <div class="row">
                                <div class="col-md-8 form-group">
                                  <label for="exampleInputName3">Durasi Tour</label>
                                  <div class="input-group" id="income-expense-summary-chart-daterange" style="width: 100%;">
                                    <div class="inpu-group-prepend input-group-text"><i class="icon-calendar"></i></div>

                                    <input type="text" class="form-control" id="exampleInputName3" name="tanggalPaketDouble" required="" value="<?php echo $row->namaPaket;?>">
                                    <div class="input-group-prepend input-group-text"><i class="icon-arrow-down"></i></div>
                                  </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="form-group">
                                    <label for="exampleInputName4">Jumlah Hari</label>
                                    <input type="text" class="form-control" id="exampleInputName4" placeholder="Otomatis muncul setelah durasi tour ditentukan" disabled="" name="jmlHariPaket">
                                  </div>
                                </div>

                              </div>
                              <div class="form-group">
                                <label for="hargaPaket">Harga Paket <small>(Rp)</small></label>
                                <input type="text" class="form-control" id="hargaPaket" placeholder="Contoh : Mekkah - Madinah - Turki" name="hargaPaket" required="" value="<?php echo number_format($row->hargaTour,0);?>">
                              </div>



                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="text-center mb-4">
                        <!-- <input type="button" class="btn btn-primary mt-4" disabled="" id="btnSubmitHitungZakat" value="Konfirmasi" /> -->
                      </div>

                      <input type="button" name="previous" class="previous actbtn-previous" value="Kembali" /> <input type="button" name="next" class="next actbtn" value="Lanjut" id="btnSubmitHitungZakat"  />

                    </fieldset>
                    <fieldset>
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group">
                            <textarea id="my-summernote" name="rencanaPerjalananText" required=""><?php echo $row->itineraryTour;?></textarea>
                          </div>
                        </div>
                      </div>
                      <input type="button" name="previous" class="previous actbtn-previous" value="Kembali" /> <input type="button" name="next" class="next actbtn" value="Lanjut" />
                    </fieldset>
                    <fieldset>
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group">
                            <textarea id="my-summernote3" name="syaratKetentuanPaket" required=""><?php echo $row->syaratKetentuanTour;?></textarea>
                          </div>
                        </div>
                      </div>
                      <input type="button" name="previous" class="previous actbtn-previous" value="Kembali" /> <input type="submit" name="finish" style="width: 200px;" class="actbtn" value="Simpan Paket" id="savePaketTour" />
                    </fieldset>

                    <?php } } ?>

                  </form>

                </div>
              </div>
            </div>
            <!-- Quick Action Toolbar Starts-->
            
            <!-- Quick Action Toolbar Ends-->
            
            
            
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo date('Y');?>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>

    <!-- include summernote css/js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote-bs4.min.js"></script>
    
    <!-- End custom js for this page -->


    <script type="text/javascript">
      $(document).ready(function(){

                         $("#hargaPaket").blur(function() {
                              this.value = parseFloat(this.value.replace(/,/g, ""))
                              .toFixed(0)
                              .toString()
                              .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                          });

            var current_fs, next_fs, previous_fs; //fieldsets
            var opacity;

            $(".next").click(function(){

              current_fs = $(this).parent();
              next_fs = $(this).parent().next();

              //Add Class Active
              $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

              //show the next fieldset
              next_fs.show();
              //hide the current fieldset with style
              current_fs.animate({opacity: 0}, {
                step: function(now) {
              // for making fielset appear animation
              opacity = 1 - now;

              current_fs.css({
                'display': 'none',
                'position': 'relative'
              });
              next_fs.css({'opacity': opacity});
            },
            duration: 600
          });
            });

            $(".previous").click(function(){

              current_fs = $(this).parent();
              previous_fs = $(this).parent().prev();

            //Remove class active
            $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

            //show the previous fieldset
            previous_fs.show();

            //hide the current fieldset with style
            current_fs.animate({opacity: 0}, {
              step: function(now) {
            // for making fielset appear animation
            opacity = 1 - now;

            current_fs.css({
              'display': 'none',
              'position': 'relative'
            });
            previous_fs.css({'opacity': opacity});
          },
          duration: 600
        });
          });

            $('.radio-group .radio').click(function(){
              $(this).parent().find('.radio').removeClass('selected');
              $(this).addClass('selected');
            });

            $(".submit").click(function(){
              return false;
            })

          });
        </script>

        <script type="text/javascript">
          $(document).ready(function() {
            $(".tripleh").change(function() {
              var file = this.files[0];
              var imagefile = file.type;
              var match= ["image/jpeg","image/png","image/jpg"];
              if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
              {
                return false;
              }
              else
              {
                var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);
              }
            });

            function imageIsLoaded(e) {
              $("#file").css("color","green");
              $('#image_preview').css("display", "block");
                      //$('#previewing').attr('src', e.target.result);
                      $('#previewing').css("background", "url("+e.target.result+")");
                      $('#previewing').attr('width', '250px');
                      $('#previewing').attr('height', '154px');
                      document.getElementById("btnTombolNextFirstSlide").disabled = false;

                      document.getElementById('name_fileuploaded').innerHTML = file.files.item(0).name;
                      document.getElementById('size_fileuploaded').innerHTML = file.files.item(0).size+ " bytes in size";
                      document.getElementById('format_fileuploaded').innerHTML = file.files.item(0).type;
                    };



                    var start = moment().subtract(29, 'days');
                    var end = moment();

                    function cb(start, end) {
                      $('#income-expense-summary-chart-daterange input').val(start.format('YYYY-MM-DD') + ' sampai ' + end.format('YYYY-MM-DD'));
                      var diff = end.diff(start, 'days');
                      $('#exampleInputName4').val(diff+1);
                    }

                    $('#income-expense-summary-chart-daterange').daterangepicker({
                      opens: 'left',
                      startDate: start,
                      endDate: end,
                      ranges: {

                      }
                    }, cb);

                    cb(start, end);

                    //Bootstrap 4 + daemonite material UI + Summernote wysiwyg text editor
                    //doc : https://github.com/summernote/summernote

                    $('#my-summernote').summernote({
                      minHeight: 200,
                      placeholder: 'Ketik rencana perjalanan tour.',
                      focus: false,
                      airMode: false,
                      fontNames: ['Roboto', 'Calibri', 'Times New Roman', 'Arial'],
                      fontNamesIgnoreCheck: ['Roboto', 'Calibri'],
                      dialogsInBody: true,
                      dialogsFade: true,
                      disableDragAndDrop: false,
                      toolbar: [
                        // [groupName, [list of button]]
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['para', ['style', 'ul', 'ol', 'paragraph']],
                        ['fontsize', ['fontsize']],
                        ['font', ['strikethrough', 'superscript', 'subscript']],
                        ['height', ['height']],
                        ['misc', ['undo', 'redo', 'print', 'help', 'fullscreen']]
                      ],
                      popover: {
                        air: [
                          ['color', ['color']],
                          ['font', ['bold', 'underline', 'clear']]
                        ]
                      },
                      print: {
                        //'stylesheetUrl': 'url_of_stylesheet_for_printing'
                      }
                    });
                    $('#my-summernote3').summernote({
                      minHeight: 200,
                      placeholder: 'Ketik syarat dan ketentuan paket tour ini...',
                      focus: false,
                      airMode: false,
                      fontNames: ['Roboto', 'Calibri', 'Times New Roman', 'Arial'],
                      fontNamesIgnoreCheck: ['Roboto', 'Calibri'],
                      dialogsInBody: true,
                      dialogsFade: true,
                      disableDragAndDrop: false,
                      toolbar: [
                        // [groupName, [list of button]]
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['para', ['style', 'ul', 'ol', 'paragraph']],
                        ['fontsize', ['fontsize']],
                        ['font', ['strikethrough', 'superscript', 'subscript']],
                        ['height', ['height']],
                        ['misc', ['undo', 'redo', 'print', 'help', 'fullscreen']]
                      ],
                      popover: {
                        air: [
                          ['color', ['color']],
                          ['font', ['bold', 'underline', 'clear']]
                        ]
                      },
                      print: {
                        //'stylesheetUrl': 'url_of_stylesheet_for_printing'
                      }
                    });
                    $('#my-summernote2').summernote({airMode: true,placeholder:'Try the airmode'});


                  });
                </script>

                <!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
                  <script type="text/javascript">
                      function getUrlVars() {
                          var vars = {};
                          var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                              vars[key] = value;
                          });
                          return vars;
                      }


                          var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                          
                          if (mytext=='success') {
                                            Swal.fire({
                                              position: 'top-center',
                                              icon: 'success',
                                              title: 'Paket berhasil ditambahkan.',
                                              showConfirmButton: true,
                                              timer: 3500
                                            });

                          }if (mytext=='success_delete') {
                                            Swal.fire({
                                              position: 'top-center',
                                              icon: 'success',
                                              title: 'Data berhasil dihapuskan.',
                                              showConfirmButton: true,
                                              timer: 3500
                                            });

                          }if (mytext=='failed_update') {
                                            Swal.fire({
                                              position: 'top-center',
                                              icon: 'danger',
                                              title: 'Maaf isian tidak boleh kosong',
                                              showConfirmButton: true,
                                              timer: 3500
                                            });

                          }
                  </script>

              </body>
              </html>