<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">
    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }

    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      

    }

    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }
    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }
  </style>
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('Managements/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('Managements/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Dashboard</h5>
        <ul class="navbar-nav navbar-nav-left">
          <a href="<?php echo site_url('Managements/manifest');?>" target="_blank" class="btn btn-outline-dark nav-link ml-2 p-2"><i class="icon icon-notebook"></i> Tampilkan Manifest</a>
        </ul>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          <!-- <form class="search-form d-none d-md-block" action="#">
            <i class="icon-magnifier"></i>
            <input type="search" class="form-control" placeholder="Search Here" title="Search here">
          </form>
        -->
        <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
          <?php
          $no=0;
          if(!$dataUser->result()){ ?>

            <p class="card-description">.</p>                                            

          <?php }else {
            foreach ($dataUser->result() as $row) {

              ?>
              <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
               <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
               <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>


               <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                <div class="dropdown-header text-center">
                 <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                 <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                 <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
               </div>
               <a href="<?php echo site_url('Managements/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
               <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
             <?php } } ?>
           </div>
         </li>
       </ul>
       <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="icon-menu"></span>
      </button>
    </div>
  </nav>
  <!-- partial -->
  <div class="container-fluid page-body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav" style="">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="profile-image">
             <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
             <div class="dot-indicator bg-success"></div>
           </div>
           <div class="text-wrapper">
            <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
            <p class="designation">Administrator</p>
          </div>

        </a>
      </li>
      <li class="nav-item nav-category">
        <span class="nav-link">Dashboard</span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
          <span class="menu-title">Dashboard</span>
          <i class="icon-screen-desktop menu-icon"></i>
        </a>
      </li>
      <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
          <span class="menu-title">Paket Umroh & Haji</span>
          <i class="icon-book-open menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">

        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Jemaah</span>
          <i class="icon-people menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

          <?php
          $no=0;
          if(!$dataPaymentSudahBayar->result()){ ?>
            <span class="menu-title">Pembayaran </span>
          <?php }else {

            ?>
            <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
              <span class="wave"></span>
              <span class="wave"></span>
              <span class="wave"></span>
            </div>
            <span class="menu-title">Pembayaran 
              <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
            </div>



          </span>

        <?php } ?>
        <i class="icon-wallet menu-icon"></i>
      </a>
    </li>

    <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
    <li class="nav-item">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
          <span class="menu-title">Buat Artikel Baru</span>
          <i class="icon-notebook menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
          <span class="menu-title">Daftar Artikel</span>
          <i class="icon-list menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
          <span class="menu-title">Komentar</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
    <li class="nav-item">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
          <span class="menu-title">Testimoni</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
          <span class="menu-title">Galeri Foto</span>
          <i class="icon-picture menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
      </span>
    </li>

    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
      </span>
    </li>
  </ul>
</nav>
<!-- partial -->
<div class="main-panel">
  <div class="content-wrapper">
            <!-- <div class="row purchace-popup">
              <div class="col-12 stretch-card grid-margin">
                <div class="card card-secondary">
                  <span class="card-body d-lg-flex align-items-center">
                    <p class="mb-lg-0">Sepertinya data diri Anda belum lengkap, lengkapi sekarang yuk!</p>
                    <a href="https://github.com/BootstrapDash/StellarAdmin-Free-Bootstrap-Admin-Template" target="_blank" class="btn ml-lg-auto download-button btn-success btn-sm my-1 my-sm-0">Lengkapi Sekarang</a>
                    <a href="https://www.bootstrapdash.com/product/stellar-admin/" target="_blank" class="btn btn-warning purchase-button btn-sm ml-sm-2 my-1 my-sm-0">Lihat Profil</a>
                    <button class="close popup-dismiss ml-2">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </span>
                </div>
              </div>
            </div> -->
            <div class="row">
              <div class="col-md-3 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Keberangkatan Terdekat</h4>
                    
                    <div class="wrapper mt-4">
                      <?php
                      $no=0;
                      if(!$dataPaketConnected->result()){ ?>

                        <p class="card-description">Tidak ada perjalanan dalam waktu dekat ini.</p>                                            

                      <?php }else {
                        foreach ($dataPaketConnected->result() as $row) {

                          ?>
                          <div class=" border rounded p-4 mt-2">
                            <h5><a href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>" class="text-dark" target="_blank"><?php echo $row->namaPaket;?></a></h5>

                            <div class="row mt-3 mb-4 ">
                              <div class="col-md-1 col-1">
                                <div class="badge badge-success float-left p-1" style="margin-left: -5px; z-index: 192"><i class="icon-plane"></i></div>
                                <div style="border-left: 2px dashed grey; height: 40px; position: relative; z-index: 190; margin-top: 23px; margin-left: 3px"></div>
                                <div class="badge badge-danger float-left p-1" style="margin-left: -5px; z-index: 192; margin-top: 2px"><i class="icon-plane"></i></div>
                              </div>
                              <div class="col-md-11 col-11">
                                Berangkat <font class="ml-3 float-right"><?php echo $row->tglMulai;?></font>
                                <br/><br/><br/>
                                <font class="mt-2">
                                  Kembali <font class="ml-3 float-right"><?php echo $row->tglSelesai;?></font>
                                </font>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col-md-12 text-center">
                                <font class="badge badge-outline-success p-3 text-center" style="font-size: 14px;">Kuota <?php echo $row->currentMember;?> / <?php echo $row->maxMember;?></font>
                              </div>
                            </div>
                            <div class="card-footer mt-4" style="margin: -25px;">
                              <i class="icon-clock mr-3"></i><?php echo $row->rentangWaktu;?> Hari Lagi
                            </div>
                          </div>

                        <?php } } ?>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-9 ">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="card">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="d-sm-flex align-items-baseline report-summary-header">
                                <h5 class="font-weight-semibold">Rangkuman</h5> 
                              </div>
                            </div>
                          </div>
                          <div class="row report-inner-cards-wrapper">
                            <div class=" col-md -6 col-xl report-inner-card">
                              <div class="inner-card-text">
                                <span class="report-title">TOTAL AKUN AKTIF</span>
                                <h4>
                                  <?php
                                  $no=0;
                                  if(!$dataUserAktif->result()){ ?>

                                    <p class="card-description">0</p>                                            

                                  <?php }else { ?>
                                    <?php echo $dataUserAktif->num_rows();?>
                                  <?php } ?>
                                </h4>
                                <a href="<?php echo site_url('Managements/ManajemenJemaah');?>" class="text-dark" style="font-size: 12px;"> Lihat Detail</a>
                              </div>
                              <div class="inner-card-icon bg-success">
                                <i class="icon-user"></i>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl report-inner-card">
                              <div class="inner-card-text">
                                <span class="report-title">PAKET AKTIF</span>
                                <h4>
                                  <?php
                                  $no=0;
                                  if(!$dataPaketAktif->result()){ ?>

                                    <p class="card-description">0</p>                                            

                                  <?php }else { ?>
                                    <?php echo $dataPaketAktif->num_rows();?>
                                  <?php } ?>
                                </h4>
                                <a href="<?php echo site_url('Managements/ManajemenPaket');?>" class="text-dark" style="font-size: 12px;"> Lihat Detail</a>
                              </div>
                              <div class="inner-card-icon bg-danger">
                                <i class="icon-plane"></i>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl report-inner-card">
                              <div class="inner-card-text">
                                <span class="report-title">TOTAL ARTIKEL</span>
                                <h4>
                                  <?php
                                  $no=0;
                                  if(!$dataArtikel->result()){ ?>

                                    <p class="card-description">0</p>                                            

                                  <?php }else { ?>
                                    <?php echo $dataArtikel->num_rows();?>
                                  <?php } ?>
                                </h4>
                                <a href="<?php echo site_url('Managements/ArticlePage');?>" class="text-dark" style="font-size: 12px;"> Lihat Detail</a>
                              </div>
                              <div class="inner-card-icon bg-warning">
                                <i class="icon-book-open"></i>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl report-inner-card">
                              <div class="inner-card-text">
                                <span class="report-title">TESTIMONI</span>
                                <h4>
                                  <?php
                                  $no=0;
                                  if(!$dataTestimoni->result()){ ?>

                                    <p class="card-description">0</p>                                            

                                  <?php }else { ?>
                                    <?php echo $dataTestimoni->num_rows();?>
                                  <?php } ?>
                                </h4>
                                <a href="<?php echo site_url('Managements/testimoniPage');?>" class="text-dark" style="font-size: 12px;"> Lihat Detail</a>
                              </div>
                              <div class="inner-card-icon bg-primary">
                                <i class="icon-diamond"></i>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row mt-4">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="card" style="border-left: 12px double #3fc42d">
                            <div class="card-body">
                              <div class="row">
                                <div class="col-md-12">
                                  <div class="d-sm-flex align-items-baseline report-summary-header">
                                    <h5 class="font-weight-semibold">Paket Tour Favorit Saat Ini</h5> 
                                  </div>
                                </div>
                              </div>
                              <div class="row report-inner-cards-wrapper">
                                <div class=" col-md-12 col-xl report-inner-card">
                                  <div class="inner-card-text">
                                    <?php
                                    $no=0;
                                    if(!$dataFavoritPaket->result()){ ?>

                                      <p class="card-description">Tidak ada data.</p>                                            

                                    <?php }else {
                                      foreach ($dataFavoritPaket->result() as $row) {

                                        ?>
                                        <span class="report-title"><a href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>" class="text-dark" target="_blank"><?php echo $row->namaPaket;?></a></span>
                                        <h4 style="font-size: 12px;" class="mt-1">Rp 250.000.000,-</h4>
                                        <a href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>"  target="_blank" class="text-success"> Lihat Detail</a>

                                      <?php } } ?>
                                    </div>

                                  </div>


                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-md-6">
                            <div class="card" style="border-left: 12px double #d16041">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-md-12">
                                    <div class="d-sm-flex align-items-baseline report-summary-header">
                                      <h5 class="font-weight-semibold">Artikel Sering Dikunjungi</h5> 
                                    </div>
                                  </div>
                                </div>
                                <?php
                                $no=0;
                                if(!$dataArtikelFavorit->result()){ ?>

                                  <p class="card-description">Tidak ada data.</p>                                            

                                <?php }else {
                                  foreach ($dataArtikelFavorit->result() as $row) {
                                    $jdlUrl = $row->judulArtikel;
                                    $cleanStr = preg_replace('/[^A-Za-z0-9 ]/', '', $jdlUrl);
                                    ?>

                                    <div class="row report-inner-cards-wrapper">
                                      <div class=" col-md-12 col-xl report-inner-card">
                                        <div class="inner-card-text">
                                          <span class="report-title"><a href="<?php echo site_url('Welcome/detailArtikel/'.$row->idArtikel.'/'.$cleanStr.'');?>" class="text-dark"><?php echo $row->judulArtikel;?></a></span>
                                          <h4 style="font-size: 12px;" class="mt-1"><i class="icon-eye"></i> <?php echo $row->readCount;?> kali dibaca</h4>
                                          <a href="<?php echo site_url('Welcome/detailArtikel/'.$row->idArtikel.'/'.$cleanStr.'');?>" target="_blank" class="text-danger"> Lihat Detail</a>
                                        </div>

                                      </div>


                                    </div>

                                  <?php } } ?>
                                </div>
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Quick Action Toolbar Starts-->
                  <div class="row quick-action-toolbar">
                    <div class="col-md-12 grid-margin">
                      <div class="card">
                        <div class="card-header d-block d-md-flex">
                          <h5 class="mb-0">Aksi Tanggap</h5>
                          <p class="ml-auto mb-0">Atur fitur-fitur secepat yang Anda bisa dengan menggunakan tombol pintas dibawah ini.<i class="icon-bulb"></i></p>
                        </div>
                        <div class="d-md-flex row m-0 quick-action-btns" role="group" aria-label="Quick action buttons">
                          <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                            <a href="<?php echo site_url('Managements/BuatPaketTravel');?>" class="btn px-0"> <i class="icon-plus mr-2"></i> Tambah Paket Tour</a>
                          </div>
                          <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                            <a href="<?php echo site_url('Managements/BuatPaketTravel');?>" class="btn px-0"><i class="icon-user mr-2"></i> Lihat Data Jemaah</a>
                          </div>
                          <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                            <a href="<?php echo site_url('Managements/CreateNewArticle');?>" class="btn px-0"></i> Buat Artikel Baru & Publish di Blog</a>
                          </div>
                          <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                            <a href="<?php echo site_url('Managements/PaymentPage');?>" class="btn px-0"></i>Lihat Tagihan Pembayaran</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Quick Action Toolbar Ends-->

            <!-- <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <div class="row income-expense-summary-chart-text">
                      <div class="col-xl-4">
                        <h5>Income And Expenses Summary</h5>
                        <p class="small text-muted">A comparison of people who mark themselves of their ineterest from the date range given above. Learn more.</p>
                      </div>
                      <div class=" col-md-3 col-xl-2">
                        <p class="income-expense-summary-chart-legend"> <span style="border-color: #6469df"></span> Total Income </p>
                        <h3>$ 1,766.00</h3>
                      </div>
                      <div class="col-md-3 col-xl-2">
                        <p class="income-expense-summary-chart-legend"> <span style="border-color: #37ca32"></span> Total Expense </p>
                        <h3>$ 5,698.30</h3>
                      </div>
                      <div class="col-md-6 col-xl-4 d-flex align-items-center">
                        <div class="input-group" id="income-expense-summary-chart-daterange">
                          <div class="inpu-group-prepend input-group-text"><i class="icon-calendar"></i></div>
                          <input type="text" class="form-control">
                          <div class="input-group-prepend input-group-text"><i class="icon-arrow-down"></i></div>
                        </div>
                      </div>
                    </div>
                    <div class="row income-expense-summary-chart mt-3">
                      <div class="col-md-12">
                        <div class="ct-chart" id="income-expense-summary-chart"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          -->

          <div class="row">
           <div class="col-md-12 ">
            <div class="row mt-4">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-3 grid-margin stretch-card">
                    <div class="card" style="border: 1px solid #3fc42d;">
                      <div class="card-body " style="background-color: #f0f0f0">

                        <div class="row report-inner-cards-wrapper ">
                          <div class=" col-md-12 col-xl text-center">
                            <i class="icon-screen-desktop mb-5" style="font-size: 70px;"></i>
                            <div class="inner-card-text mt-3 pb-5">

                              <h4 style="font-size: 26px;" class="mt-1 h4 text-success">
                                <a href="<?php echo site_url('Managements/HeadlinePage');?>" class="text-success">Ubah Headline</a>
                              </h4>
                              <span class="report-title h4">Kelola Headline</span>
                              <br/>

                            </div>

                          </div>


                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-3 grid-margin stretch-card">
                    <div class="card" style="border: 1px solid #3fc42d">
                      <div class="card-body ">

                        <div class="row report-inner-cards-wrapper ">
                          <div class=" col-md-12 col-xl text-center">
                            <i class="icon-eyeglass mb-5" style="font-size: 70px;"></i>
                            <div class="inner-card-text mt-3 pb-5">

                              <h4 style="font-size: 26px;" class="mt-1 h4 text-success">

                                <?php
                                $no=0;
                                if(!$dataTotalArtikelTerbaca->result()){ ?>

                                  0

                                <?php }else {
                                  foreach ($dataTotalArtikelTerbaca->result() as $row) {

                                    ?>
                                    <?php echo $row->terbaca;?>

                                  <?php } } ?>

                                </h4>
                                <span class="report-title h4">Total Artikel Terbaca</span>
                                <br/>

                              </div>

                            </div>
                            

                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-3 grid-margin stretch-card">
                      <div class="card" style="border: 1px solid #3fc42d;">
                        <div class="card-body " style="background-color: #f0f0f0">

                          <div class="row report-inner-cards-wrapper ">
                            <div class=" col-md-12 col-xl text-center">
                              <i class="icon-emotsmile mb-5" style="font-size: 70px;"></i>
                              <div class="inner-card-text mt-3 pb-5">
                                <?php
                                $no=0;
                                if(!$dataPemberiTestiTerbanyak->result()){ ?>

                                  0

                                <?php }else {
                                  foreach ($dataPemberiTestiTerbanyak->result() as $row) {

                                    ?>

                                    

                                    <h4 style="font-size: 26px;" class="mt-1 h4 text-success"><a href="<?php echo site_url('Managements/lihatDataJemaah/'.$row->idUser);?>" class="text-success"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></a></h4>
                                    <span class="report-title h4">Pemberi Testimoni Terbanyak<br/><font class="text-muted" style="font-size: 15px;">
                                      <?php if(!$row->jmlTesti){ echo "0";}else { echo $row->jmlTesti;}?>
                                    testimoni</font></span>
                                    <br/>

                                  <?php } } ?>
                                  
                                </div>
                                
                              </div>


                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-md-3 grid-margin stretch-card">
                        <div class="card" style="border: 1px solid #3fc42d">
                          <div class="card-body ">

                            <div class="row report-inner-cards-wrapper ">
                              <div class=" col-md-12 col-xl text-center">
                                <i class="icon-people mb-5" style="font-size: 70px;"></i>
                                <div class="inner-card-text mt-3 pb-5">
                                  <?php
                                  $no=0;
                                  if(!$dataPembawaJemaahTerbanyak->result()){ ?>

                                    <h4 style="font-size: 26px;" class="mt-1 h4 text-success"><a href="" class="text-success">Belum diketahui</a></h4>
                                    <span class="report-title h4">Pembawa Jemaah Terbanyak<br/><font class="text-muted" style="font-size: 15px;">0 Jemaah</font></span>

                                  <?php }else {
                                    foreach ($dataPembawaJemaahTerbanyak->result() as $row) {

                                      ?>

                                      <h4 style="font-size: 26px;" class="mt-1 h4 text-success"><a href="" class="text-success"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></a></h4>
                                      <span class="report-title h4">Membawa Jemaah Terbanyak<br/><font class="text-muted" style="font-size: 15px;"><?php if(!$row->jmlJemaahBersamanya){ echo "0";}else { echo $row->jmlJemaahBersamanya;}?> jemaah bersamanya</font></span>

                                    <?php } } ?>

                                    <br/>

                                  </div>

                                </div>


                              </div>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>

              </div>
              <div class="row mt-4">
                <div class="col-md-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-sm-flex align-items-center mb-4">
                        <h4 class="card-title mb-sm-0">Progres Kuota Paket</h4>

                      </div>
                      <div class="table-responsive border rounded p-1 table-hover">
                        <table class="table">
                          <thead>
                            <tr>
                              <th class="font-weight-bold">Nama Paket</th>
                              <th class="font-weight-bold">Berangkat Pada</th>
                              <th class="font-weight-bold">Kuota</th>
                              <th class="font-weight-bold">Progress</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $no=0;
                            if(!$dataPaketProgress->result()){ ?>

                              <p class="card-description">Tidak ada data.</p>                                            

                            <?php }else {
                              foreach ($dataPaketProgress->result() as $row) {

                                ?>
                                <tr>
                                  <td >
                                  <a href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>" class="text-dark" target="_blank"><?php echo $row->namaPaket;?></a></td>
                                  <td >
                                  <?php echo $row->berangkatPada;?> </td>
                                  <td >
                                  <?php echo $row->currentMember;?> / <?php echo $row->maxMember;?> </td>
                                  <td>
                                    <div class="progress">
                                      <div class="progress-bar progress-bar-striped active" role="progressbar"
                                      aria-valuenow="<?php echo $row->progressNow;?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $row->progressNow;?>%">
                                      <?php echo round($row->progressNow,2);?> %
                                    </div>
                                  </div>
                                </td>

                              </tr>

                            <?php } } ?>

                          </tbody>
                        </table>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- content-wrapper ends -->
            <!-- partial:partials/_footer.html -->
            <footer class="footer">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo date('Y');?> <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap Dash</a>. All rights reserved.</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
              </div>
            </footer>
            <!-- partial -->
          </div>
          <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
      </div>
      <!-- container-scroller -->
      <!-- plugins:js -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
      <!-- endinject -->
      <!-- Plugin js for this page -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
      <!-- End plugin js for this page -->
      <!-- inject:js -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
      <!-- endinject -->
      <!-- Custom js for this page -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>

      <script type="text/javascript">
        $(function () {
          $('[data-toggle="tooltip"]').tooltip()
        })
      </script>
      <!-- End custom js for this page -->
    </body>
    </html>