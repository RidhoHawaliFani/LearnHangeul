<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">

    .square {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .previewing {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }
    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }
  </style>
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('User/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('User/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex"></h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
                            <?php
                            $no=0;
                            if(!$dataUser->result()){ ?>

                              <p class="card-description">.</p>                                            

                            <?php }else {
                              foreach ($dataUser->result() as $row) {

                            ?>
                            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                               <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                              <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>
                            

              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                <div class="dropdown-header text-center">
                  <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                  <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                  <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                </div>
                <a href="<?php echo site_url('User/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
                <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
                <?php } } ?>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="icon-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav" style="">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="profile-image">
             <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
             <div class="dot-indicator bg-success"></div>
           </div>
           <div class="text-wrapper">
            <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
            <p class="designation">Administrator</p>
          </div>

        </a>
      </li>
      <li class="nav-item nav-category">
        <span class="nav-link">Dashboard</span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
          <span class="menu-title">Dashboard</span>
          <i class="icon-screen-desktop menu-icon"></i>
        </a>
      </li>
      <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
          <span class="menu-title">Paket Umroh & Haji</span>
          <i class="icon-book-open menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">

        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Jemaah</span>
          <i class="icon-people menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

          <?php
          $no=0;
          if(!$dataPaymentSudahBayar->result()){ ?>
            <span class="menu-title">Pembayaran </span>
          <?php }else {

            ?>
            <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
              <span class="wave"></span>
              <span class="wave"></span>
              <span class="wave"></span>
            </div>
            <span class="menu-title">Pembayaran 
              <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
            </div>



          </span>

        <?php } ?>
        <i class="icon-wallet menu-icon"></i>
      </a>
    </li>

    <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
    <li class="nav-item">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
          <span class="menu-title">Buat Artikel Baru</span>
          <i class="icon-notebook menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
          <span class="menu-title">Daftar Artikel</span>
          <i class="icon-list menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
          <span class="menu-title">Komentar</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
    <li class="nav-item">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
          <span class="menu-title">Testimoni</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
          <span class="menu-title">Galeri Foto</span>
          <i class="icon-picture menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
      </span>
    </li>

    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
      </span>
    </li>
  </ul>
</nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row purchace-popup">
              <div class="col-2 col-sm-12">
                <div class="row text-center">
                  <a href="javascript:history.go(-1)"  type="button" class="btn btn-outline-danger btn-icon-text mt-5" style="margin: auto; position: fixed; margin-left: 0px;">
                    <i class="icon-arrow-left btn-icon-prepend"></i> </a>
                  
                  </div>

                </div>
                <?php
                    $no=0;
                    if(!$dataUser->result()){ ?>

                      <p class="card-description"> Sorry, no data can be retrieve right now.</p>                                            

                    <?php }else {
                      foreach ($dataUser->result() as $row) {
                        if(empty($row->namaLengkap) or empty($row->noPassport) or empty($row->tempatLahir) or empty($row->birthday) or empty($row->tglAktifPassport) or empty($row->tglExpPassport) or empty($row->lokasiBuatPassport) or empty($row->gender) or empty($row->noTelp) or empty($row->alamat) or empty($row->rt) or empty($row->rw) or empty($row->kelurahan) or empty($row->kecamatan) or empty($row->kabupaten) or empty($row->provinsi) or empty($row->pendidikan) or empty($row->status) or empty($row->pekerjaan) or empty($row->namaAyah)){
                        ?>
                          <div class="col-8 offset-sm-2">
                            <div class="card" style="border: 1px dashed #e02d2d">
                              <span class="card-body d-lg-flex align-items-center">
                                <p class="mb-lg-0">Sepertinya data diri Anda belum lengkap, <b>lengkapi sekarang yuk!</b></p>
                                <a href="#" class="btn ml-lg-auto btn-danger btn-sm">Lengkapi Sekarang</a>

                              </span>
                            </div>
                          </div>

                  <?php }else { echo "";} } }?>

              </div>
              <div class="row quick-action-toolbar">
                <div class="offset-sm-2 col-md-8 col-sm-12 grid-margin mt-5">
                  <div class="card">
                    <div class="card-header d-block d-md-flex">
                      <h5 class="mb-0">Data Profil</h5>
                    </div>
                    <?php
                    $no=0;
                    if(!$dataUser->result()){ ?>

                      <p class="card-description"> Sorry, no data can be retrieve right now.</p>                                            

                    <?php }else {
                      foreach ($dataUser->result() as $row) {

                        ?>
                        <div class="card-body d-block">
                          <div class="row">
                            <div class="col-md-9" id="firstSection">
                              <h4 class="card-title text-success">Informasi Umum</h4>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nama Lengkap</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;">
                                <?php if(!$row->namaLengkap){ echo "-";}else { echo $row->namaLengkap;}?>

                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tempat Lahir</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->tempatLahir){ echo "-";}else { echo $row->tempatLahir;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Lahir</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->tglUltah){ echo "-";}else { echo $row->tglUltah;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kelamin</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->gender){ echo "-";}else { echo $row->gender;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nomor Whatsapp Aktif</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <b>+62 </b><?php if(!$row->noTelp){ echo "-";}else { echo $row->noTelp;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nomor KTP</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->noKTP){ echo "-";}else { echo $row->noKTP;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nama Ayah</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->namaAyah){ echo "-";}else { echo $row->namaAyah;}?>
                              </p>

                              <h4 class="card-title text-success mt-5">Alamat</h4>
                              <div class="row">
                                <div class="col-md-10">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Alamat</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->alamat){ echo "-";}else { echo $row->alamat;}?>
                                  </p>
                                  <hr/>
                                </div>
                                <div class="col-md-1">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> RT</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->rt){ echo "-";}else { echo $row->rt;}?>
                                  </p>
                                  <hr/>
                                </div>
                                <div class="col-md-1">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> RW</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->rw){ echo "-";}else { echo $row->rw;}?>
                                  </p>
                                  <hr/>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-3">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kelurahan</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->kelurahan){ echo "-";}else { echo $row->kelurahan;}?>
                                  </p>
                                  <hr/>
                                </div>
                                <div class="col-md-3">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kecamatan</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->kecamatan){ echo "-";}else { echo $row->kecamatan;}?>
                                  </p>
                                  <hr/>
                                </div>
                                <div class="col-md-3">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kabupaten</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->kabupaten){ echo "-";}else { echo $row->kabupaten;}?>
                                  </p>
                                  <hr/>
                                </div> 
                                <div class="col-md-3">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Provinsi</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->provinsi){ echo "-";}else { echo $row->provinsi;}?>
                                  </p>
                                  <hr/>
                                </div>
                              </div>

                              <h4 class="card-title text-success mt-5">Passpor</h4>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> No. Paspor</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->noPassport){ echo "-";}else { echo $row->noPassport;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Lokasi Buat Paspor</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;">
                                <?php if(!$row->lokasiBuatPassport){ echo "-";}else { echo $row->lokasiBuatPassport;}?>
                              </p>
                              <hr/>
                              <div class="row">
                                <div class="col-md-6">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Pembuatan</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->tglAktifPassport){ echo "-";}else { echo $row->tglAktifPassport;}?>
                                  </p>
                                  <hr/>
                                </div>
                                <div class="col-md-6">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Berakhir</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->tglExpPassport){ echo "-";}else { echo $row->tglExpPassport;}?>
                                  </p>
                                  <hr/>
                                </div>

                              </div>

                              <h4 class="card-title text-success mt-5">Informasi Tambahan</h4>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Pendidikan Terakhir</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                <?php if(!$row->pendidikan){ echo "-";}else { echo $row->pendidikan;}?>
                              </p>
                              <hr/>
                              <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Pekerjaan</p>
                              <p class="card-description text-dark" style="margin-bottom: 10px;">
                                <?php if(!$row->pekerjaan){ echo "-";}else { echo $row->pekerjaan;}?>
                              </p>
                              <hr/>
                              <div class="row">
                                <div class="col-md-6">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kode Pos</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->kodePos){ echo "-";}else { echo $row->kodePos;}?>
                                  </p>
                                  <hr/>
                                </div>
                                <div class="col-md-6">
                                  <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Status</p>
                                  <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                    <?php if(!$row->status){ echo "-";}else { echo $row->status;}?>
                                  </p>
                                  <hr/>
                                </div>

                              </div>
                            </div>

                            <div class="col-md-9" id="secondSection">
                              <form role="form" method="post" id="formBerzakat" class="forms-sample" action="<?php echo site_url('User/prosEditProfilUser');?>" enctype="multipart/form-data">
                                <h4 class="card-title text-success">Informasi Umum</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nama Lengkap</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="namalengkap" value="<?php if(!$row->namaLengkap){ echo "";}else { echo $row->namaLengkap;}?>" placeholder="Ketik nama lengkap" required>


                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tempat Lahir</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="tempatlahir" value="<?php if(!$row->tempatLahir){ echo "";}else { echo $row->tempatLahir;}?>" placeholder="Ketik tempat lahir" required>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Lahir</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="birthday" value="<?php if(!$row->birthday){ echo "";}else { echo $row->birthday;}?>" placeholder="yyyy-mm-dd" required>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kelamin</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <div class="form-group">
                                    <select class="form-control" id="exampleSelectGender" name="gender">
                                      <option value="Laki-laki">Laki-laki</option>
                                      <option value="Perempuan">Perempuan</option>
                                    </select>
                                  </div>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nomor Whatsapp Aktif</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="noTelp" value="<?php if(!$row->noTelp){ echo "";}else { echo $row->noTelp;}?>" required placeholder="Tanpa awalan +62 atau 62 atau 0" maxlength="11">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nomor KTP</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="noKTP" value="<?php if(!$row->noKTP){ echo "";}else { echo $row->noKTP;}?>" required placeholder="16 digit Nomor KTP" maxlength="16">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nama Ayah</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="namaAyah" value="<?php if(!$row->namaAyah){ echo "";}else { echo $row->namaAyah;}?>" required placeholder="Nama Ayah Kandung">

                                </p>

                                <h4 class="card-title text-success mt-5">Alamat</h4>
                                <div class="row">
                                  <div class="col-md-8">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Alamat saat ini</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="alamat" value="<?php if(!$row->alamat){ echo "";}else { echo $row->alamat;}?>" required placeholder="Ketik alamat saat ini">

                                    </p>
                                  </div>
                                  <div class="col-md-2">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> RT</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="rt" value="<?php if(!$row->rt){ echo "";}else { echo $row->rt;}?>" required placeholder="0">

                                    </p>
                                  </div>
                                  <div class="col-md-2">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> RW</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="rw" value="<?php if(!$row->rw){ echo "";}else { echo $row->rw;}?>" required placeholder="0">

                                    </p>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kelurahan</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kelurahan" value="<?php if(!$row->kelurahan){ echo "";}else { echo $row->kelurahan;}?>" required placeholder="Ketik  lahir">

                                    </p>
                                  </div>
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kecamatan</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kecamatan" value="<?php if(!$row->kecamatan){ echo "";}else { echo $row->kecamatan;}?>" required placeholder="Ketik tempat lahir">

                                    </p>
                                  </div>
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kabupaten</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kabupaten" value="<?php if(!$row->kabupaten){ echo "";}else { echo $row->kabupaten;}?>" required placeholder="Ketik tempat lahir">

                                    </p>
                                  </div> 
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Provinsi</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="provinsi" value="<?php if(!$row->provinsi){ echo "";}else { echo $row->provinsi;}?>" required placeholder="Ketik tempat lahir">

                                    </p>
                                  </div>
                                </div>

                                <h4 class="card-title text-success mt-5">Passpor</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> No. Paspor</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="noPassport" value="<?php if(!$row->noPassport){ echo "-";}else { echo $row->noPassport;}?>" required placeholder="Ketik nomor pasport">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Lokasi Buat Paspor</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="lokasiBuatPassport" value="<?php if(!$row->lokasiBuatPassport){ echo "";}else { echo $row->lokasiBuatPassport;}?>" required placeholder="Lokasi pembuatan paspor">

                                </p>
                                <div class="row">
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Pembuatan</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="tglAktifPassport" value="<?php if(!$row->tglAktifPassport){ echo "";}else { echo $row->tglAktifPassport;}?>" required placeholder="yyyy-mm-dd">

                                    </p>
                                  </div>
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Berakhir</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="tglExpPassport" value="<?php if(!$row->tglExpPassport){ echo "";}else { echo $row->tglExpPassport;}?>" required placeholder="yyyy-mm-dd">

                                    </p>
                                  </div>

                                </div>

                                <h4 class="card-title text-success mt-5">Informasi Tambahan</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Pendidikan Terakhir</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="pendidikan" value="<?php if(!$row->pendidikan){ echo "";}else { echo $row->pendidikan;}?>" required placeholder="">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Pekerjaan</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="pekerjaan" value="<?php if(!$row->pekerjaan){ echo "";}else { echo $row->pekerjaan;}?>" required placeholder="">

                                </p>
                                <div class="row">
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kode Pos <small>(optional)</small></p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kodePos" value="<?php if(!$row->kodePos){ echo "";}else { echo $row->kodePos;}?>" required placeholder="">

                                    </p>
                                  </div>
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Status</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="status" value="<?php if(!$row->status){ echo "";}else { echo $row->status;}?>" required placeholder="">

                                    </p>
                                  </div>

                                </div>

                                <div class="row">
                                  <div class="offset-sm-3 col-md-6">
                                    <button type="submit" class="btn btn-success mt-5" style="width: 100%;">Simpan Pengaturan</button>
                                  </div>

                                </div>

                                <div class="modal fade" id="modaldelete" data-keyboard="false" data-backdrop="static">
                                <div class="modal-dialog modal-normal">
                                  <form id="showForm" action="<?php echo site_url('Managements/prosesDeletePaketTour');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="idPaket" value="">
                                    <div class="modal-content ">

                                      <div class="modal-body text-center">
                                        <div class="row">
                                            <div class="col-md-12" style="margin: auto;text-align: center;">
                                             <div id="image_preview mb-3"><img class="profile-user-img img-circle" id="previewing" src="<?php echo base_url(); ?>/assets/img/images.png" style="width: 200px; height: 200px; border-radius: 1000px;" /></div>
                                           </div>
                                           <!-- /.col -->
                                         </div>
                                        <div class="form-group mt-3">
                                          <div class="input-group" style="width: 50%; text-align: left; padding-top: 10px; margin: auto;">
                                            <div class="custom-file">
                                              <input type="file" name="pictureProfile" class="custom-file-input tripleh" id="exampleInputFile">
                                              <label class="custom-file-label" for="exampleInputFile">Pilih foto</label>
                                            </div>

                                          </div>
                                        </div>
                                      </div>

                                      <div class="modal-footer d-block" id="sideBtnSave" style="margin:auto;">
                                        <button type="submit" class="btn btn-primary" data-dismiss="modal" aria-label="Close"  id="cancelDelete" style="float: left;"><i class="fas fa-times" style=""></i> OK</button>
                                      </div>
                                    </div>
                                  </form>
                                  <!-- /.modal-content -->
                                </div>
                              </div>

                              </form>
                            </div>

                            <div class="col-md-3">

                              <div class="square rounded-circle d-block mb-3" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>'); margin-top: -130px; position: absolute; right: -50px;">
                              </div>
                              <button type="button" class="btn btn-social-icon btn-google btn-rounded" id="btnUploadGambar" style="z-index: 555; position: absolute; right: -70px;" data-toggle="modal" data-target="#modaldelete">
                                <i class="icon-camera text-secondary"></i>
                              </button>
                            </div>
                          </div>

                        </div>
                      <?php } } ?>

                    </div>
                  </div>
                  <!-- Quick Action Toolbar Ends-->



                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                  <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright ©  <?php echo date('Y');?> <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap Dash</a>. All rights reserved.</span>
                    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
                  </div>
                </footer>


                

                <!-- partial -->
              </div>
              <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
          </div>
          <!-- container-scroller -->
          <!-- plugins:js -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
          <!-- endinject -->
          <!-- Plugin js for this page -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
          <!-- End plugin js for this page -->
          <!-- inject:js -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
          <!-- endinject -->
          <!-- Custom js for this page -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>
          <!-- End custom js for this page -->


          <script type="text/javascript">
            $(document).ready(function() {
                      $(".tripleh").change(function() {
                      var file = this.files[0];
                      var imagefile = file.type;
                      var match= ["image/jpeg","image/png","image/jpg"];
                      if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
                      {
                      return false;
                      }
                      else
                      {
                      var reader = new FileReader();
                      reader.onload = imageIsLoaded;
                      reader.readAsDataURL(this.files[0]);
                      }
                      });
                      
                      function imageIsLoaded(e) {
                      $("#file").css("color","green");
                      $('#image_preview').css("display", "block");
                      $('#previewing').attr('src', e.target.result);
                      $('#previewing').attr('width', '250px');
                      $('#previewing').attr('height', '154px');

                      $('#previewing2').attr('style', 'background-image:url('+e.target.result+');display:block;background-color: #fff; z-index: 554; margin-top: -130px; position: absolute; right: -50px;');
                      };

            });
        </script>


          <script type="text/javascript">
           $(window).on('load',function(){
            document.getElementById("secondSection").style.display = "none";
            document.getElementById("btnUploadGambar").style.display = "none";
          });
        </script>

        <script type="text/javascript">
          $(document).ready(function() {

            var pivot = 1;

            $('#btnEditNow').on('click', function(){
              if (pivot == 1) {
                document.getElementById("firstSection").style.display = "none";
                document.getElementById("secondSection").style.display = "block";
                document.getElementById("btnUploadGambar").style.display = "block";
                document.getElementById("btnEditNow").style.display = "none";
                pivot = 0;
              }else {
                document.getElementById("firstSection").style.display = "block";
                document.getElementById("secondSection").style.display = "none";
                document.getElementById("btnUploadGambar").style.display = "none";
                pivot = 1;
              }


            });      

          });
        </script>
      </body>
      </html>