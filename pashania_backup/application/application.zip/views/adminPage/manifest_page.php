<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">
    .square {
      width: 100%;
      height: 200px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      
      
    }

    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }

    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }

    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }

    /* Style the Image Used to Trigger the Modal */
    #myImg {
      cursor: pointer;
      transition: 0.3s;
    }

    #myImg:hover {opacity: 0.7;}

    /* The Modal (background) */
    .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 10000; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
    }

    /* Modal Content (Image) */
    .modal-content {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
    }

    /* Caption of Modal Image (Image Text) - Same Width as the Image */
    .caption {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
      text-align: center;
      color: #ccc;
      padding: 10px 0;
      height: 150px;
    }

    /* Add Animation - Zoom in the Modal */
    .modal-content, .caption {
      animation-name: zoom;
      animation-duration: 0.6s;
    }

    @keyframes zoom {
      from {transform:scale(0)}
      to {transform:scale(1)}
    }

    /* The Close Button */
    .close {
      position: absolute;
      top: 15px;
      right: 35px;
      color: #f1f1f1;
      font-size: 40px;
      font-weight: bold;
      transition: 0.3s;
    }

    .close:hover,
    .close:focus {
      color: #bbb;
      text-decoration: none;
      cursor: pointer;
    }

    /* 100% Image Width on Smaller Screens */
    @media only screen and (max-width: 700px){
      .modal-content {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('Managements/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('Managements/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Daftar Manifest</h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          <form class="search-form d-none d-md-block" action="#">
            <i class="icon-magnifier"></i>
            <input type="search" class="form-control" placeholder="Search Here" title="Search here">
          </form>

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
            <?php
            $no=0;
            if(!$dataUser->result()){ ?>

              <p class="card-description">.</p>                                            

            <?php }else {
              foreach ($dataUser->result() as $row) {

                ?>
                <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                 <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                 <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>


                 <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                  <div class="dropdown-header text-center">
                   <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                   <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                   <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                 </div>
                 <a href="<?php echo site_url('Managements/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
                 <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
               <?php } } ?>
             </div>
           </li>
         </ul>
         <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav" style="">
          <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
              <div class="profile-image">
               <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
               <div class="dot-indicator bg-success"></div>
             </div>
             <div class="text-wrapper">
              <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
              <p class="designation">Administrator</p>
            </div>

          </a>
        </li>
        <li class="nav-item nav-category">
          <span class="nav-link">Dashboard</span>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
            <span class="menu-title">Dashboard</span>
            <i class="icon-screen-desktop menu-icon"></i>
          </a>
        </li>
        <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
            <span class="menu-title">Paket Umroh & Haji</span>
            <i class="icon-book-open menu-icon"></i>
          </a>
        </li>
        <li class="nav-item">

          <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
            <span class="menu-title">Jemaah</span>
            <i class="icon-people menu-icon"></i>
          </a>
          <div class="collapse" id="ui-basic">
            <ul class="nav flex-column sub-menu">

              <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
              <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
              <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

              <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
              <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
            </ul>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

            <?php
            $no=0;
            if(!$dataPaymentSudahBayar->result()){ ?>
              <span class="menu-title">Pembayaran </span>
            <?php }else {

              ?>
              <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
                <span class="wave"></span>
                <span class="wave"></span>
                <span class="wave"></span>
              </div>
              <span class="menu-title">Pembayaran 
                <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
              </div>



            </span>

          <?php } ?>
          <i class="icon-wallet menu-icon"></i>
        </a>
      </li>

      <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
      <li class="nav-item">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
            <span class="menu-title">Buat Artikel Baru</span>
            <i class="icon-notebook menu-icon"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
            <span class="menu-title">Daftar Artikel</span>
            <i class="icon-list menu-icon"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
            <span class="menu-title">Komentar</span>
            <i class="icon-speech menu-icon"></i>
          </a>
        </li>

      </li>


      <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
      <li class="nav-item">

        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
            <span class="menu-title">Testimoni</span>
            <i class="icon-speech menu-icon"></i>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
            <span class="menu-title">Galeri Foto</span>
            <i class="icon-picture menu-icon"></i>
          </a>
        </li>

      </li>


      <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
        <span class="">
          <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
        </span>
      </li>

      <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
        <span class="">
          <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
        </span>
      </li>
    </ul>
  </nav>
  <!-- partial -->
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
      <div class="card">
      <div class="table-responsive border rounded p-1 table-hover">
                        <table class="table">
                          <thead>
                            <tr>
                              <th class="font-weight-bold">No</th>
                              <th class="font-weight-bold">Username</th>
                              <th class="font-weight-bold">Golongan User</th>
                              <th class="font-weight-bold">Email</th>
                              <th class="font-weight-bold">Nama Lengkap</th>
                              <th class="font-weight-bold">Tempat Lahir</th>
                              <th class="font-weight-bold">Tanggal Lahir</th>
                              <th class="font-weight-bold">Jenis Kelamin</th>
                              <th class="font-weight-bold">Nomor KTP</th>
                              <th class="font-weight-bold">Nomor Paspor</th>
                              <th class="font-weight-bold">Tanggal Aktif Paspor</th>
                              <th class="font-weight-bold">Tanggal Berakhir Paspor</th>
                              <th class="font-weight-bold">Lokasi Buat Paspor</th>
                              <th class="font-weight-bold">Nomor Telepon</th>
                              <th class="font-weight-bold">Alamat</th>
                              <th class="font-weight-bold">RT</th>
                              <th class="font-weight-bold">RW</th>
                              <th class="font-weight-bold">Kelurahan</th>
                              <th class="font-weight-bold">Kecamatan</th>
                              <th class="font-weight-bold">Kabupaten</th>
                              <th class="font-weight-bold">Provinsi</th>
                              <th class="font-weight-bold">Pendidikan</th>
                              <th class="font-weight-bold">Kode Pos</th>
                              <th class="font-weight-bold">Status</th>
                              <th class="font-weight-bold">Pekerjaan</th>
                              <th class="font-weight-bold">Nama Ayah</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $no=1;
                            if(!$dataAllUser->result()){ ?>

                              <p class="card-description">Tidak ada data.</p>                                            

                            <?php }else {
                              foreach ($dataAllUser->result() as $row) {

                                ?>
                                <tr>
                                  <td >
                                    <?php echo $no++ ;?>
                                  </td>
                                  <td >
                                  <a href="#" class="text-dark" target="_blank">
                                    <?php if(!$row->username){ echo "";}else { echo $row->username;}?>
                                      
                                    </a></td>
                                  <td >
                                  <?php if(!$row->statusLevelUser){ echo "";}else { if ($row->statusLevelUser=='2') {
                                    echo "Akun Aktif";
                                  }else { echo "Jemaah Tambahan";}}?> </td>
                                  <td >
                                    <?php if(!$row->email){ echo "";}else { echo $row->email;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->namaLengkap){ echo "";}else { echo $row->namaLengkap;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->tempatLahir){ echo "";}else { echo $row->tempatLahir;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->tglUltah){ echo "";}else { echo $row->tglUltah;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->gender){ echo "";}else { echo $row->gender;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->noKTP){ echo "";}else { echo $row->noKTP;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->noPassport){ echo "";}else { echo $row->noPassport;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->tglAktifPassport){ echo "";}else { echo $row->tglAktifPassport;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->tglExpPassport){ echo "";}else { echo $row->tglExpPassport;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->lokasiBuatPassport){ echo "";}else { echo $row->lokasiBuatPassport;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->noTelp){ echo "";}else { echo $row->noTelp;}?>
                                  </td>
                                   <td>
                                      <?php if(!$row->alamat){ echo "";}else { echo $row->alamat;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->rt){ echo "";}else { echo $row->rt;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->rw){ echo "";}else { echo $row->rw;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->kelurahan){ echo "";}else { echo $row->kelurahan;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->kecamatan){ echo "";}else { echo $row->kecamatan;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->kabupaten){ echo "";}else { echo $row->kabupaten;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->provinsi){ echo "";}else { echo $row->provinsi;}?>
                                  </td>

                                  <td>
                                      <?php if(!$row->pendidikan){ echo "";}else { echo $row->pendidikan;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->kodePos){ echo "";}else { echo $row->kodePos;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->status){ echo "";}else { echo $row->status;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->pekerjaan){ echo "";}else { echo $row->pekerjaan;}?>
                                  </td>
                                  <td>
                                      <?php if(!$row->namaAyah){ echo "";}else { echo $row->namaAyah;}?>
                                  </td>


                              </tr>

                            <?php } } ?>

                          </tbody>
                        </table>
                      </div>
                      </div>
                  </div>

                  <div class="modal fade" id="modaldelete" data-keyboard="false" data-backdrop="static">
                    <div class="modal-dialog modal-normal">
                      <form id="showForm" action="<?php echo site_url('Managements/prosesAddGaleri');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="idTestimoni" value="">
                        <div class="modal-content ">

                          <h3 style="" class="p-4">
                            Upload Gambar Baru
                          </h3>

                          <div class="modal-body text-left" style="padding-top: 0; padding-bottom: 0">
                            <div class="form-group">
                              <label for="t1">Pilih gambar</label>
                              <input type="file" id="t1" name="gambarUpload" class="form-control">
                            </div>

                            <div class="form-group mt-3">
                             <label for="t2">Keterangan</label>
                             <textarea class="form-control" id="t2" name="caption" required="" rows="4"></textarea>
                           </div>

                           <div class="form-group mt-3">
                             <label for="t3">Kategori</label>
                             <input type="text" name="kategori" class="form-control" id="t3" placeholder="Contoh : haji, umroh">
                           </div>
                         </div>

                         <div class="modal-footer d-block" style="padding-top: 50px;">
                          <button type="submit" class="btn btn-primary" data-dismiss="modal" aria-label="Close"  id="cancelDelete" style="float: left;"><i class="fas fa-times" style=""></i> Batal</button>
                          <button type="submit" class="btn btn-danger" style="float: right;display: block;"><i class="fas fa-check" style="margin-right: 10px;"></i> Ya, Tetap Hapus</button>
                        </div>
                      </div>
                    </form>
                    <!-- /.modal-content -->
                  </div>
                </div>

              </div>
              <!-- content-wrapper ends -->
              <!-- partial:partials/_footer.html -->
              <footer class="footer">
                <div class="d-sm-flex justify-content-center justify-content-sm-between">
                  <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo date('Y');?> <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap Dash</a>. All rights reserved.</span>
                  <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
                </div>
              </footer>
              <!-- partial -->
            </div>
            <!-- main-panel ends -->
          </div>
          <!-- page-body-wrapper ends -->
        </div>
        <!-- container-scroller -->
        <!-- plugins:js -->
        <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
        <!-- endinject -->
        <!-- Plugin js for this page -->
        <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
        <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
        <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
        <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
        <!-- End plugin js for this page -->
        <!-- inject:js -->
        <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
        <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
        <!-- endinject -->
        <!-- Custom js for this page -->
        <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>

        <script type="text/javascript">
          $(function () {
            $('[data-toggle="tooltip"]').tooltip()
          })
        </script>

        <script type="text/javascript">
          function getUrlVars() {
            var vars = {};
            var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
              vars[key] = value;
            });
            return vars;
          }


                          var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                          
                          if (mytext=='success') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Gambar berhasil ditambahkan',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }if (mytext=='success_delete_galeri') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Data berhasil dihapuskan.',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }if (mytext=='failed_update') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'danger',
                              title: 'Maaf isian tidak boleh kosong',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }
                        </script>

                        <!-- End custom js for this page -->
                      </body>
                      </html>