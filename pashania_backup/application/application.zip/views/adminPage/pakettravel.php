<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">

    .square {
      width: 100%;
      height: 200px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      
      
    }
    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }

    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      

    }

    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }
    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }
  </style>
</head>
<body>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('Managements/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('Managements/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Kelola Pembayaran</h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          <form class="search-form d-none d-md-block" action="#">
            <i class="icon-magnifier"></i>
            <input type="search" class="form-control" placeholder="Search Here" title="Search here">
          </form>

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
            <?php
            $no=0;
            if(!$dataUser->result()){ ?>

              <p class="card-description">.</p>                                            

            <?php }else {
              foreach ($dataUser->result() as $row) {

                ?>
                <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                 <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                 <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>


                 <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                  <div class="dropdown-header text-center">
                   <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                   <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                   <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                 </div>
                 <a href="<?php echo site_url('Managements/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
                 <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
               <?php } } ?>
             </div>
           </li>
         </ul>
         <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav" style="">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="profile-image">
             <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
             <div class="dot-indicator bg-success"></div>
           </div>
           <div class="text-wrapper">
            <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
            <p class="designation">Administrator</p>
          </div>

        </a>
      </li>
      <li class="nav-item nav-category">
        <span class="nav-link">Dashboard</span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
          <span class="menu-title">Dashboard</span>
          <i class="icon-screen-desktop menu-icon"></i>
        </a>
      </li>
      <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
          <span class="menu-title">Paket Umroh & Haji</span>
          <i class="icon-book-open menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">

        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Jemaah</span>
          <i class="icon-people menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

          <?php
          $no=0;
          if(!$dataPaymentSudahBayar->result()){ ?>
            <span class="menu-title">Pembayaran </span>
          <?php }else {

            ?>
            <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
              <span class="wave"></span>
              <span class="wave"></span>
              <span class="wave"></span>
            </div>
            <span class="menu-title">Pembayaran 
              <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
            </div>



          </span>

        <?php } ?>
        <i class="icon-wallet menu-icon"></i>
      </a>
    </li>

    <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
    <li class="nav-item">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
          <span class="menu-title">Buat Artikel Baru</span>
          <i class="icon-notebook menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
          <span class="menu-title">Daftar Artikel</span>
          <i class="icon-list menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
          <span class="menu-title">Komentar</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
    <li class="nav-item">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
          <span class="menu-title">Testimoni</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
          <span class="menu-title">Galeri Foto</span>
          <i class="icon-picture menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
      </span>
    </li>

    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
      </span>
    </li>
  </ul>
</nav>
  <!-- partial -->
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row quick-action-toolbar">
        <div class="col-md-12 grid-margin">
          <div class="card">
            <div class="card-header d-block d-md-flex">
              <h5 class="mb-0">Aksi Tanggap</h5>
              <p class="ml-auto mb-0">Atur fitur-fitur secepat yang Anda bisa dengan menggunakan tombol pintas dibawah ini.<i class="icon-bulb"></i></p>
            </div>
            <div class="d-md-flex row m-0 quick-action-btns" role="group" aria-label="Quick action buttons">
              <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                <a href="<?php echo site_url('Managements/BuatPaketTravel');?>" class="btn px-0"> <i class="icon-plus mr-2"></i> Tambah Paket Tour</a>
              </div>
              <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                <a href="<?php echo site_url('Managements/BuatPaketTravel');?>" class="btn px-0"><i class="icon-user mr-2"></i> Lihat Data Jemaah</a>
              </div>
              <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                <a href="<?php echo site_url('Managements/CreateNewArticle');?>" class="btn px-0"></i> Buat Artikel Baru & Publish di Blog</a>
              </div>
              <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                <a href="<?php echo site_url('Managements/PaymentPage');?>" class="btn px-0"></i>Lihat Tagihan Pembayaran</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title text-center">Seluruh Paket</h4>
              <div class="aligner-wrapper" style="padding-top: 60px; padding-bottom: 110px;">

                <div class="wrapper d-flex flex-column justify-content-center absolute absolute-center" >
                  <h2 class="text-center mb-0 font-weight-bold text-primary" style="font-size: 8pc;">
                    <?php
                    $no=0;
                    if(!$daftarPaketTour->result()){ ?>
                      0
                    <?php }else {
                      echo $daftarPaketTour->num_rows();
                    }

                    ?>
                  </h2>
                  <small class="d-block text-center text-muted  font-weight-semibold mb-0">Jumlah paket yang masih aktif</small>
                </div>
              </div>

            </div>
          </div>
        </div>
        <div class="col-md-8 grid-margin stretch-card">
          <div class="card">

            <div class="card-body" >
              <?php
              $no=0;
              if(!$countHajiorUmrohPaket->result()){ ?>

               <div class="row report-inner-cards-wrapper" >
                <div class=" col-md-6 col-xl report-inner-card">
                  <div class="inner-card-text">
                    <span class="report-title">HAJI</span>
                    <h4 class="text-success" style="font-size: 5pc;">0</h4>
                    <span class="report-count text-muted"> Total paket yang tersedia saat ini</span>
                  </div>
                  <div class="inner-card-icon bg-success mt-5">
                    <font style="font-weight: 900"> H</font>
                  </div>
                </div>
                <div class="col-md-6 col-xl report-inner-card">
                  <div class="inner-card-text">
                    <span class="report-title">UMROH</span>
                    <h4 class="text-danger" style="font-size: 5pc;">0</h4>
                    <span class="report-count text-muted"> Total paket yang tersedia saat ini</span>
                  </div>
                  <div class="inner-card-icon bg-danger mt-5">
                   <font style="font-weight: 900"> U</font>
                 </div>
               </div>
             </div>
           <?php }else {
            foreach ($countHajiorUmrohPaket->result() as $row) {

              ?>
              <div class="row report-inner-cards-wrapper" >
                <div class=" col-md-6 col-xl report-inner-card">
                  <div class="inner-card-text">
                    <span class="report-title">HAJI</span>
                    <h4 class="text-success" style="font-size: 5pc;"><?php echo $row->jmlHaji;?></h4>
                    <span class="report-count text-muted"> Total paket yang tersedia saat ini</span>
                  </div>
                  <div class="inner-card-icon bg-success mt-5">
                    <font style="font-weight: 900"> H</font>
                  </div>
                </div>
                <div class="col-md-6 col-xl report-inner-card">
                  <div class="inner-card-text">
                    <span class="report-title">UMROH</span>
                    <h4 class="text-danger" style="font-size: 5pc;"><?php echo $row->jmlUmroh;?></h4>
                    <span class="report-count text-muted"> Total paket yang tersedia saat ini</span>
                  </div>
                  <div class="inner-card-icon bg-danger mt-5">
                   <font style="font-weight: 900"> U</font>
                 </div>
               </div>
             </div>
           <?php } } ?>

         </div>

       </div>
     </div>
   </div>
   <!-- Quick Action Toolbar Starts-->

   <!-- Quick Action Toolbar Ends-->


   <div class="row">

    <div class="col-sm-6 col-lg-2 col-md-4  grid-margin scaleUp mt-2" >
      <a href="<?php echo site_url('Managements/BuatPaketTravel');?>" class="nav-link" style="padding: 0" title="Tambah Paket Tour Baru">
        <div class="card" style="background-color: #fff; border: 1px dashed #f0f0f0;">
          <div class="card-body text-center">
            <font style="font-size: 200px; color: #f0f0f0; text-align: center; line-height: 450px;">+</font>

          </div>
        </div>

      </div>
    </a>
    <?php
    $no=0;
    if(!$daftarPaketTour->result()){ ?>


    <?php }else {
      foreach ($daftarPaketTour->result() as $row) {

        ?>
        <div class=" col-sm-6 col-lg-2 col-md-4  grid-margin stretch-card scaleUp">
          <div class="card">
            <div class="square" id="previewing" style="display:block;background-image: url('<?php echo base_url(); ?><?php echo $row->picturePaket;?>')"></div>
            <div class="card-body text-center">
              <font class="text-left" style="font-weight: bold; display: block; margin-bottom: 10px; text-transform: uppercase;"><?php echo $row->namaPaket;?></font>

              <font class="text-left" style="font-weight: normal; display: block; font-size: 12px; margin-bottom: 10px; text-transform: lowercase;"><i class="icon-location-pin text-success"></i> <?php echo $row->tujuanPaket;?> </font>
              <font class="text-left" style="font-weight: normal; display: block; font-size: 12px; margin-bottom: 10px;"><i class="icon-clock text-success"></i> <?php echo $row->rentangWaktu;?> Hari </font>
              <font class="text-left " style="font-weight: normal; display: block; font-size: 12px; margin-bottom: 10px;"><i class="icon-graph text-success"></i> <?php echo $row->currentMember;?> / <?php echo $row->maxMember;?> Orang </font>
              <font class="text-left text-success" style="font-weight: 700; display: block; font-size: 12px; margin-bottom: 10px;"><i class="icon-diamond text-success"></i> <?php echo "Rp " . number_format($row->hargaTour,0,',','.');?>,- </font>
              <div class="btn-group mt-2" role="group" aria-label="Basic example">
                <a target="_blank" href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>" type="button" class="btn btn-sm btn-outline-secondary">Detail</a>
                <a href="<?php echo site_url('Managements/EditPaketTravel');?>/<?php echo $row->namaPaket.'_'.$row->idPaket;?>" type="button" class="btn btn-sm btn-outline-secondary"><i class="icon-pencil"></i></a>
                <a href="#" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#modaldelete<?php echo $row->idPaket;?>"><i class="icon-trash"></i></a>

              </div>
            </div>
            <div class="card-header d-block ">
              <?php
              if ($row->tglSelesai > date("Y-m-d")) {
                # code...
              ?>
                <h6 class="mb-0 text-center"><i class="icon-plane mr-2"></i><?php echo $row->tglMulai;?> - <?php echo $row->tglSelesai;?></h6>
              <?php }else { ?>
                <div class="badge badge-danger float-left" data-toggle="tooltip" data-placement="top" title="Masa paket ini telah selesai.">
                  SELESAI
                </div>
                <div class="float-right">
                  <h6 class="mb-0"><?php echo $row->tglMulai;?> - <?php echo $row->tglSelesai;?></h6>
                </div>
              <?php } ?>
            </div>
          </div>
        </div>


        <div class="modal fade" id="modaldelete<?php echo $row->idPaket;?>" data-keyboard="false" data-backdrop="static">
          <div class="modal-dialog modal-normal">
            <form id="showForm<?php echo $row->idPaket;?>" action="<?php echo site_url('Managements/prosesDeletePaketTour');?>" class="m-t-40" method="post" enctype="multipart/form-data">
              <input type="hidden" name="idPaket" value="<?php echo $row->idPaket;?>">
              <div class="modal-content ">

                <div class="modal-body text-center">
                  <h3>Konfirmasi</h3>
                  Apakah anda yakin ingin menghapus paket tour ini?<br/>
                  <small class="text-muted" style="font-size: 10px;"><b>Penting!</b> Data tersebut tidak dapat dikembalikan lagi apabila telah dihapus</small>
                </div>

                <div class="modal-footer d-block" id="sideBtnSave<?php echo $row->idPaket;?>">
                  <button type="submit" class="btn btn-primary" data-dismiss="modal" aria-label="Close"  id="cancelDelete<?php echo $row->idPaket;?>" style="float: left;"><i class="fas fa-times" style=""></i> Batal</button>
                  <button type="submit" class="btn btn-outline-danger" style="float: right;display: block;"><i class="fas fa-check" style="margin-right: 10px;"></i> Ya, Tetap Hapus</button>
                </div>
              </div>
            </form>
            <!-- /.modal-content -->
          </div>
        </div>

      <?php } } ?>

    </div>
  </div>
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->
  <footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
      <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo date('Y');?>. All rights reserved.</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
    </div>
  </footer>
  <!-- partial -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<!-- plugins:js -->
<script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
<script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>
<!-- End custom js for this page -->
<!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
<script type="text/javascript">
  function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
      vars[key] = value;
    });
    return vars;
  }


                          var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                          
                          if (mytext=='success_update') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Paket berhasil diperbaharui.',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }if (mytext=='success_delete_paket') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Data berhasil dihapuskan.',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }if (mytext=='failed_update') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'danger',
                              title: 'Maaf isian tidak boleh kosong',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }
                        </script>

                        <script type="text/javascript">
                          $(function () {
                            $('[data-toggle="tooltip"]').tooltip()
                          })
                        </script>

                      </body>
                      </html>