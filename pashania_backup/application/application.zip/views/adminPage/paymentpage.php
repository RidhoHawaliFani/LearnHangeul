<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">

    .square {
      width: 100%;
      height: 400px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      
      
    }

    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }

    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }

    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }

    /* Style the Image Used to Trigger the Modal */
    #myImg {
      cursor: pointer;
      transition: 0.3s;
    }

    #myImg:hover {opacity: 0.7;}

    /* The Modal (background) */
    .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 10000; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
    }

    /* Modal Content (Image) */
    .modal-content {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
    }

    /* Caption of Modal Image (Image Text) - Same Width as the Image */
    .caption {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
      text-align: center;
      color: #ccc;
      padding: 10px 0;
      height: 150px;
    }

    /* Add Animation - Zoom in the Modal */
    .modal-content, .caption {
      animation-name: zoom;
      animation-duration: 0.6s;
    }

    @keyframes zoom {
      from {transform:scale(0)}
      to {transform:scale(1)}
    }

    /* The Close Button */
    .close {
      position: absolute;
      top: 15px;
      right: 35px;
      color: #f1f1f1;
      font-size: 40px;
      font-weight: bold;
      transition: 0.3s;
    }

    .close:hover,
    .close:focus {
      color: #bbb;
      text-decoration: none;
      cursor: pointer;
    }

    /* 100% Image Width on Smaller Screens */
    @media only screen and (max-width: 700px){
      .modal-content {
        width: 100%;
      }
    }
    
  </style>
</head>
<body>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('Managements/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('Managements/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Kelola Pembayaran</h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          <form class="search-form d-none d-md-block" action="#">
            <i class="icon-magnifier"></i>
            <input type="search" class="form-control" placeholder="Search Here" title="Search here">
          </form>

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
            <?php
            $no=0;
            if(!$dataUser->result()){ ?>

              <p class="card-description">.</p>                                            

            <?php }else {
              foreach ($dataUser->result() as $row) {

                ?>
                <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                 <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                 <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>


                 <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                  <div class="dropdown-header text-center">
                   <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                   <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                   <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                 </div>
                 <a href="<?php echo site_url('User/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
                 <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
               <?php } } ?>
             </div>
           </li>
         </ul>
         <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav" style="">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="profile-image">
             <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
             <div class="dot-indicator bg-success"></div>
           </div>
           <div class="text-wrapper">
            <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
            <p class="designation">Administrator</p>
          </div>

        </a>
      </li>
      <li class="nav-item nav-category">
        <span class="nav-link">Dashboard</span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
          <span class="menu-title">Dashboard</span>
          <i class="icon-screen-desktop menu-icon"></i>
        </a>
      </li>
      <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
          <span class="menu-title">Paket Umroh & Haji</span>
          <i class="icon-book-open menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">

        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Jemaah</span>
          <i class="icon-people menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

          <?php
          $no=0;
          if(!$dataPaymentSudahBayar->result()){ ?>
            <span class="menu-title">Pembayaran </span>
          <?php }else {

            ?>
            <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
              <span class="wave"></span>
              <span class="wave"></span>
              <span class="wave"></span>
            </div>
            <span class="menu-title">Pembayaran 
              <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
            </div>



          </span>

        <?php } ?>
        <i class="icon-wallet menu-icon"></i>
      </a>
    </li>

    <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
    <li class="nav-item">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
          <span class="menu-title">Buat Artikel Baru</span>
          <i class="icon-notebook menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
          <span class="menu-title">Daftar Artikel</span>
          <i class="icon-list menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
          <span class="menu-title">Komentar</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
    <li class="nav-item">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
          <span class="menu-title">Testimoni</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
          <span class="menu-title">Galeri Foto</span>
          <i class="icon-picture menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
      </span>
    </li>

    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
      </span>
    </li>
  </ul>
</nav>
  <!-- partial -->
  <div class="main-panel">
    <div class="content-wrapper">


      <div class="row">

        <div class="col-sm-12 col-lg-8 col-md-12">
          <div class="row">


            <?php
            $no=0;
            if(!$dataPaymentSudahBayar->result()){ ?>

              <div class=" col-12 col-sm-12 col-lg-3 col-md-6  grid-margin stretch-card scaleUp">
                <div class="card" style="border: 1px dashed #c7c7c7">
                  <div class="square" id="previewing" style="display:block;background-image: url('<?php echo base_url(); ?>/assets_adminuser/images/faces/no-image.png');background-size: contain; background-repeat: no-repeat;";></div>
                  <div class="card-body text-left">
                    <font class="text-center" style="font-weight: normal; display: block; margin-bottom: 10px; text-transform: uppercase;">Tidak ada data</font>
                    <font class="text-left" style="font-weight: normal; display: block; margin-bottom: 20px; font-size: 13px;"></b></font>


                  </div>
                  <div class="card-header d-block ">
                    <div class="row">
                      <div class="col-md-2">
                        <i class="icon-clock mr-2"></i>
                      </div>
                      <div class="col-md-10">
                        <h6 class="mb-0 text-left"><small>Tidak ada data yang dapat ditampilkan</small></h6>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

            <?php }else {
              foreach ($dataPaymentSudahBayar->result() as $row) {

                ?>
                <div class=" col-12 col-sm-12 col-lg-3 col-md-6  grid-margin stretch-card scaleUp">
                  <div class="card">
                    <a href="#" class="mb-2 d-block text-dark text-muted"><div class="square" id="myImg<?php echo $row->kodePaketTour;?>" style="display:block;background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureTagihan){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureTagihan;}?>')" data-toggle="tooltip" data-placement="right" title="Zoom Gambar"></div></a>


                    <div class="card-body text-left">
                      <a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" target="_blank" class="mb-2 d-block text-dark text-muted">#<?php echo $row->kodePaketTour;?></a>
                      <font class="text-left" style="font-weight: normal; display: block; margin-bottom: 10px; text-transform: uppercase;"><?php echo $row->namaLengkap;?></font>
                      <font class="text-left" style="font-weight: normal; display: block; margin-bottom: 20px; font-size: 13px;">Telah melakukan transfer sebesar<b> <?php echo "Rp " . number_format($row->hargaTotalPaket,0,',','.');?>,-</b></font>
                      <form id="showForm" action="<?php echo site_url('Managements/prosesAcceptTagihanPembayaran');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                        <input type="hidden" class="" name="emailUser" required="" value="<?php echo $row->email;?>">
                        <input type="hidden" class="" name="kodePaketTourGet" required="" value="<?php echo $row->kodePaketTour;?>">
                        <div class="btn-group mt-2" role="group" aria-label="Basic example">

                          <button type="submit" class="btn btn-sm btn-outline-success">Konfirmasi Pembayaran</button>
                          <a href="<?php echo site_url('Managements/prosesDeclineTagihanPembayaran/').$row->kodePaketTour.'/'.$row->idUser;?>" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="right" title="Tolak pembayaran dan kirim email pemberitahuan" onclick="return confirm('Anda yakin membatalkan permohonan tagihan tersebut?')"><i class="icon-close"></i></a>

                        </div>
                      </form>
                    </div>
                    <div class="card-header d-block ">
                      <div class="row">
                        <div class="col-md-2">
                          <i class="icon-clock mr-2"></i>
                        </div>
                        <div class="col-md-10">
                          <h6 class="mb-0 text-left"><small>Dibayar pada <br/><?php echo $row->tglDibayar;?> WIB</small></h6>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>

                <!-- The Modal -->
                <div id="myModal<?php echo $row->kodePaketTour;?>" class="modal">

                  <!-- The Close Button -->
                  <span class="close" id="closeShadow<?php echo $row->kodePaketTour;?>">&times;</span>

                  <!-- Modal Content (The Image) -->
                  <img class="modal-content" id="img01<?php echo $row->kodePaketTour;?>">

                  <!-- Modal Caption (Image Text) -->
                  <div id="caption<?php echo $row->kodePaketTour;?>" class="caption"></div>
                </div>

                <script type="text/javascript">

                        // Get the modal
                        var modal = document.getElementById("myModal<?php echo $row->kodePaketTour;?>");

                        // Get the image and insert it inside the modal - use its "alt" text as a caption
                        var img = document.getElementById("myImg<?php echo $row->kodePaketTour;?>");
                        var modalImg = document.getElementById("img01<?php echo $row->kodePaketTour;?>");
                        var captionText = document.getElementById("caption<?php echo $row->kodePaketTour;?>");
                        img.onclick = function(){
                          modal.style.display = "block";
                          modalImg.src = '<?php echo base_url(); ?><?php if(!$row->pictureTagihan){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureTagihan;}?>';
                          captionText.innerHTML = "Bukti pembayaran paket <?php echo $row->jenisPaket;?> oleh <?php echo $row->namaLengkap;?><br/><b>Aset PT. Nida Utama Sejahtera &copy <?php echo date('Y');?></b>";
                        }

                        // Get the <span> element that closes the modal
                        var span = document.getElementById("closeShadow<?php echo $row->kodePaketTour;?>");

                        // When the user clicks on <span> (x), close the modal
                        span.onclick = function() {
                          modal.style.display = "none";
                        }

                      </script>


                    <?php } } ?>

                  </div>
                </div>
                <div class="col-md-4 col-lg-4">
                  <div class="row quick-action-toolbar">
                    <div class="col-12 col-md-12 col-lg-12 col-sm-12">
                      <div class="card ">
                        <div class="card-header" style="margin-bottom: 0;">
                          <h5 class="mb-0">Jemaah Belum Membayar</h5>

                        </div>
                        <div class="card-body" style="margin-left: 0; padding-left: 0; padding-right: 0; margin-top: 0; padding-top: 0">
                          <table class="table table-hover table-responsive" style="margin-top: 0">

                            <?php
                            $no=0;
                            if(!$dataPaymentBelumBayar->result()){ ?>
                              <div class="row">
                                <div class="card-body">
                                  <h6 class="mb-0 text-left"><small><i class="icon-info text-danger mr-3"></i> Tidak ada data yang dapat ditampilkan</small></h6>
                                </div>
                              </div>

                            <?php }else {
                              foreach ($dataPaymentBelumBayar->result() as $row) {

                                ?>
                                <tr>
                                  <td> 
                                    <a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" class="mb-2 d-block text-dark text-muted">#<?php echo $row->kodePaketTour;?></a>
                                    <a href="<?php echo site_url('Managements/lihatDataJemaah/').$row->idUser;?>" class="mb-2 d-block text-dark"><?php echo $row->namaLengkap;?></a>
                                    <i><?php echo $row->namaPaket;?></i>
                                    <font class="mt-2 d-block">Batas pembayaran <strong><?php echo $row->tglExpired;?></strong> <small>(<?php echo $row->jamExpired;?> WIB)</small></font>
                                  </td>

                                  <td width="160 text-right"> <span class="badge badge-pill badge-danger pull-right float-right" style="padding: 9px;">
                                   <?php echo "Rp " . number_format($row->hargaTotalPaket,0,',','.');?>,-
                                 </span> </td>
                               </tr>

                             <?php } } ?>
                           </table>
                         </div>
                       </div>
                     </div>

                     <div class="col-12 col-md-12 col-lg-12 col-sm-12 mt-3">
                      <div class="card ">
                        <div class="card-header" style="margin-bottom: 0;">
                          <h5 class="mb-0">Riwayat Pembayaran Lunas</h5>

                        </div>
                        <div class="card-body" style="margin-left: 0; padding-left: 0; padding-right: 0; margin-top: 0; padding-top: 0;padding-bottom: 0">
                          <table class="table table-hover table-responsive" style="margin-top: 0">

                            <?php
                            $no=0;
                            if(!$dataPaymentLunas->result()){ ?>
                              <div class="row">
                                <div class="card-body">
                                  <h6 class="mb-0 text-left"><small><i class="icon-info text-danger mr-3"></i> Tidak ada data yang dapat ditampilkan</small></h6>
                                </div>
                              </div>

                            <?php }else {
                              foreach ($dataPaymentLunas->result() as $row) {

                                ?>
                                <tr>
                                  <td> 
                                    <a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" class="mb-2 d-block text-dark text-muted">#<?php echo $row->kodePaketTour;?></a>
                                    <a href="<?php echo site_url('Managements/lihatDataJemaah/').$row->idUser;?>" class="mb-2 d-block text-dark"><?php echo $row->namaLengkap;?></a>
                                    <i><?php echo $row->namaPaket;?></i>
                                    <font class="mt-2 d-block">Telah dibayar pada <strong><?php echo $row->tglExpired;?></strong> <small>(<?php echo $row->jamExpired;?> WIB)</small></font>
                                  </td>

                                  <td width="160 text-right"> <span class="badge badge-pill badge-success pull-right float-right" style="padding: 9px;">
                                   <?php echo "Rp " . number_format($row->hargaTotalPaket,0,',','.');?>,-
                                 </span> </td>
                               </tr>

                             <?php } } ?>
                           </table>
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>



               </div>
             </div>
             <!-- content-wrapper ends -->
             <!-- partial:partials/_footer.html -->
             <footer class="footer">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?php echo date('Y');?>. All rights reserved.</span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
              </div>
            </footer>
            <!-- partial -->
          </div>
          <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
      </div>

      <!-- Trigger the Modal -->


      <!-- container-scroller -->
      <!-- plugins:js -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
      <!-- endinject -->
      <!-- Plugin js for this page -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
      <!-- End plugin js for this page -->
      <!-- inject:js -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
      <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
      <!-- endinject -->
      <!-- Custom js for this page -->
      <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>
      <!-- End custom js for this page -->
      <!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
      <script type="text/javascript">
        function getUrlVars() {
          var vars = {};
          var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
            vars[key] = value;
          });
          return vars;
        }

        


                          var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                          
                          if (mytext=='paymentAccepted') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Berhasil Dikonfirmasi & \nEmail Telah Terkirim',
                              showConfirmButton: true,
                              timer: 4500
                            });

                          }if (mytext=='success_delete_artikel') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Data berhasil dihapuskan.',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }if (mytext=='paymentDeclined') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'error',
                              title: 'Tagihan Berhasil Dibatalkan',
                              showConfirmButton: true,
                              timer: 4500
                            });

                          }
                        </script>
                        <script type="text/javascript">
                          $(function () {
                            $('[data-toggle="tooltip"]').tooltip()
                          })
                        </script>
                      </body>
                      </html>