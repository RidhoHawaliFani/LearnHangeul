<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">

    .square {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .previewing {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }
    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }
  </style>
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('Managements/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('Managements/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Manajemen Admin</h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">
          <form class="search-form d-none d-md-block" action="#">
            <i class="icon-magnifier"></i>
            <input type="search" class="form-control" placeholder="Search Here" title="Search here">
          </form>

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
            <?php
            $no=0;
            if(!$dataUser->result()){ ?>

              <p class="card-description">.</p>                                            

            <?php }else {
              foreach ($dataUser->result() as $row) {

                ?>
                <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                 <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                 <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>


                 <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                  <div class="dropdown-header text-center">
                   <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                   <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                   <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                 </div>
                 <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
               <?php } } ?>
             </div>
           </li>
         </ul>
         <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav" style="">
        <li class="nav-item nav-profile">
          <a href="#" class="nav-link">
            <div class="profile-image">
             <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
             <div class="dot-indicator bg-success"></div>
           </div>
           <div class="text-wrapper">
            <p class="profile-name" style="width: 100px"><?php echo $namaUserGiven;?></p>
            <p class="designation">Administrator</p>
          </div>

        </a>
      </li>
      <li class="nav-item nav-category">
        <span class="nav-link">Dashboard</span>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/index');?>">
          <span class="menu-title">Dashboard</span>
          <i class="icon-screen-desktop menu-icon"></i>
        </a>
      </li>
      <li class="nav-item nav-category"><span class="nav-link">Kelola Sistem</span></li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ManajemenPaket');?>">
          <span class="menu-title">Paket Umroh & Haji</span>
          <i class="icon-book-open menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">

        <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
          <span class="menu-title">Jemaah</span>
          <i class="icon-people menu-icon"></i>
        </a>
        <div class="collapse" id="ui-basic">
          <ul class="nav flex-column sub-menu">

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal;"><span class="text-muted">Kelola Jemaah</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/CreateNewJemaah');?>">Tambah Jemaah Manual</a></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenJemaah');?>">Data Jemaah</a></li>

            <li class="nav-item nav-category" style="color: #f0f0f0; text-transform: none; font-weight: normal; "><span class="text-muted">Kelola Administrator</span></li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo site_url('Managements/ManajemenAdmin');?>">Data Admin</a></li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/PaymentPage');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dikonfirmasi segera">

          <?php
          $no=0;
          if(!$dataPaymentSudahBayar->result()){ ?>
            <span class="menu-title">Pembayaran </span>
          <?php }else {

            ?>
            <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
              <span class="wave"></span>
              <span class="wave"></span>
              <span class="wave"></span>
            </div>
            <span class="menu-title">Pembayaran 
              <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentSudahBayar->num_rows();?>
            </div>



          </span>

        <?php } ?>
        <i class="icon-wallet menu-icon"></i>
      </a>
    </li>

    <li class="nav-item nav-category"><span class="nav-link">Kelola Artikel</span></li>
    <li class="nav-item">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CreateNewArticle');?>">
          <span class="menu-title">Buat Artikel Baru</span>
          <i class="icon-notebook menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/ArticlePage');?>">
          <span class="menu-title">Daftar Artikel</span>
          <i class="icon-list menu-icon"></i>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/CommentsOnArticle');?>">
          <span class="menu-title">Komentar</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item nav-category"><span class="nav-link">Lainnya</span></li>
    <li class="nav-item">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/testimoniPage');?>">
          <span class="menu-title">Testimoni</span>
          <i class="icon-speech menu-icon"></i>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('Managements/galeriPage');?>">
          <span class="menu-title">Galeri Foto</span>
          <i class="icon-picture menu-icon"></i>
        </a>
      </li>

    </li>


    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
      </span>
    </li>

    <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
      <span class="">
        <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
      </span>
    </li>
  </ul>
</nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row purchace-popup">

              </div>

              <form role="form" method="post" id="formBerzakat" class="forms-sample" action="<?php echo site_url('Managements/tambahAdminByAdminProses');?>" enctype="multipart/form-data">

              <div class="row quick-action-toolbar">
                <div class="offset-sm-2 col-md-8 grid-margin mt-5">
                  <div class="card">
                    <div class="card-header d-block ">
                      <h5 class="mb-0">Tambah Admin</h5>
                      <span class="mb-0 text-small">Data berikut untuk admin yang dibawah tanggung jawab Anda</span>
                    </div>
                    
                        <div class="card-body d-block">
                          <div class="row">
                            
                            <div class="col-md-9" id="secondSection">
                              
                                <h4 class="card-title text-success">Informasi Akun</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Username & Email</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="username" value="" placeholder="Ketik username pilihan" required id="usernameTyped">
                                  <input type="email" class="form-control" name="email" value="" placeholder="Ketik email aktif" required>
                                  <div id="usernameAvailable" class="badge bg-success ml-3" style="font-weight: normal; border-radius: 4px; font-size: 9px; float: right; position: absolute; right: 20px; color:white; top: 67px; visibility: hidden;">
                                    Username tersedia
                                  </div>
                                  <div id="usernameCannotUsed" class="badge bg-danger ml-3" style="font-weight: normal; border-radius: 4px; font-size: 9px; float: right; position: absolute; right: 20px; color:white; top: 67px; visibility: hidden;">
                                    Username telah dipakai
                                  </div>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Password</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="password" style="font-weight: bold;" value="<?php 
                              $length = 10;
                              $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                              $charactersLength = strlen($characters);
                              $randomString = '';
                              for ($i = 0; $i < $length; $i++) {
                                  $randomString .= $characters[rand(0, $charactersLength - 1)];
                              }
                              echo $randomString;
                          ?>" placeholder="" required>


                                </p>
                                <h4 class="card-title text-success mt-5">Informasi Umum</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nama Lengkap</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="namalengkap" value="" placeholder="Ketik nama lengkap" required>


                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tempat Lahir</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="tempatlahir" value="" placeholder="Ketik tempat lahir" required>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Lahir</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="birthday" value="" placeholder="yyyy-mm-dd" required>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kelamin</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <div class="form-group">
                                    <select class="form-control" id="exampleSelectGender" name="gender">
                                      <option value="Laki-laki">Laki-laki</option>
                                      <option value="Perempuan">Perempuan</option>
                                    </select>
                                  </div>

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nomor Whatsapp Aktif</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="noTelp" value="" required placeholder="Tanpa awalan +62 atau 62 atau 0" maxlength="11">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nomor KTP</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="noKTP" value="" required placeholder="16 digit Nomor KTP" maxlength="16">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Nama Ayah</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="namaAyah" value="" required placeholder="Nama Ayah Kandung">

                                </p>

                                <h4 class="card-title text-success mt-5">Alamat</h4>
                                <div class="row">
                                  <div class="col-md-8">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Alamat saat ini</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="alamat" value="" required placeholder="Ketik alamat saat ini">

                                    </p>
                                  </div>
                                  <div class="col-md-2">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> RT</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="rt" value="" required placeholder="0">

                                    </p>
                                  </div>
                                  <div class="col-md-2">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> RW</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="rw" value="" required placeholder="0">

                                    </p>
                                  </div>
                                </div>

                                <div class="row">
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kelurahan</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kelurahan" value="" required placeholder="Ketik  lahir">

                                    </p>
                                  </div>
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kecamatan</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kecamatan" value="" required placeholder="Ketik tempat lahir">

                                    </p>
                                  </div>
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kabupaten</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kabupaten" value="" required placeholder="Ketik tempat lahir">

                                    </p>
                                  </div> 
                                  <div class="col-md-3">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Provinsi</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="provinsi" value="" required placeholder="Ketik tempat lahir">

                                    </p>
                                  </div>
                                </div>

                                <h4 class="card-title text-success mt-5">Passpor</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> No. Paspor</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="noPassport" value="" required placeholder="Ketik nomor pasport">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Lokasi Buat Paspor</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="lokasiBuatPassport" value="" required placeholder="Lokasi pembuatan paspor">

                                </p>
                                <div class="row">
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Pembuatan</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="tglAktifPassport" value="" required placeholder="yyyy-mm-dd">

                                    </p>
                                  </div>
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Tanggal Berakhir</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="tglExpPassport" value="" required placeholder="yyyy-mm-dd">

                                    </p>
                                  </div>

                                </div>

                                <h4 class="card-title text-success mt-5">Informasi Tambahan</h4>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Pendidikan Terakhir</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                  <input type="text" class="form-control" name="pendidikan" value="" required placeholder="">

                                </p>
                                <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Pekerjaan</p>
                                <p class="card-description text-dark" style="margin-bottom: 10px;">
                                  <input type="text" class="form-control" name="pekerjaan" value="" required placeholder="">

                                </p>
                                <div class="row">
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Kode Pos <small>(optional)</small></p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="kodePos" value="" required placeholder="">

                                    </p>
                                  </div>
                                  <div class="col-md-6">
                                    <p class="card-description" style="margin-bottom: 0; font-size: 12px;"> Status</p>
                                    <p class="card-description text-dark" style="margin-bottom: 10px;"> 
                                      <input type="text" class="form-control" name="status" value="" required placeholder="">

                                    </p>
                                  </div>

                                </div>

                                

                                <div class="modal fade" id="modaldelete" data-keyboard="false" data-backdrop="static">
                                <div class="modal-dialog modal-normal">
                                    <input type="hidden" name="idPaket" value="">
                                    <div class="modal-content ">

                                      <div class="modal-body text-center">
                                        <div class="row">
                                            <div class="col-md-12" style="margin: auto;text-align: center;">
                                             <div id="image_preview mb-3"><img class="profile-user-img img-circle" id="previewing" src="<?php echo base_url(); ?>/assets/img/images.png" style="width: 200px; height: 200px; border-radius: 1000px;" /></div>
                                           </div>
                                           <!-- /.col -->
                                         </div>
                                        <div class="form-group mt-3">
                                          <div class="input-group" style="width: 50%; text-align: left; padding-top: 10px; margin: auto;">
                                            <div class="custom-file">
                                              <input type="file" name="pictureProfile" class="custom-file-input tripleh" id="exampleInputFile">
                                              <label class="custom-file-label" for="exampleInputFile">Pilih foto</label>
                                            </div>

                                          </div>
                                        </div>
                                      </div>

                                      <div class="modal-footer d-block" id="sideBtnSave" style="margin:auto;">
                                        <button type="submit" class="btn btn-primary"  data-dismiss="modal" aria-label="Close"  id="cancelDelete" style="float: left;"><i class="fas fa-times" style=""></i> OK</button>
                                      </div>
                                    </div>
                            
                                  <!-- /.modal-content -->
                                </div>
                              </div>

                              
                            </div>

                            
                            <div class="col-md-3 text-right">

                              <div class="square d-block mb-3" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?>/assets_adminuser/images/faces/no-image.png'); ">
                              </div>
                              <button type="button" class="btn btn-social-icon btn-google btn-rounded" id="btnUploadGambar" style="z-index: 555; margin-top: -50px;" data-toggle="modal" data-target="#modaldelete">
                                <i class="icon-camera text-secondary"></i>
                              </button>
                            </div>
                          </div>

                        </div>
                                 <div class="row">
                                  <div class="offset-sm-3 col-md-6">
                                    <button type="submit" id="buttonSubmitForm" class="btn btn-success mt-5" style="width: 100%;">Simpan Pengaturan</button>
                                  </div>

                                </div>
                      
                    </div>
                  </div>
                  </form>
                  <!-- Quick Action Toolbar Ends-->



                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                  <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright ©  <?php echo date('Y');?> <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap Dash</a>. All rights reserved.</span>
                    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
                  </div>
                </footer>


                

                <!-- partial -->
              </div>
              <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
          </div>
          <!-- container-scroller -->
          <!-- plugins:js -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
          <!-- endinject -->
          <!-- Plugin js for this page -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
          <!-- End plugin js for this page -->
          <!-- inject:js -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
          <!-- endinject -->
          <!-- Custom js for this page -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>
          <!-- End custom js for this page -->


          <script type="text/javascript">
            $(document).ready(function() {
                      $(".tripleh").change(function() {
                      var file = this.files[0];
                      var imagefile = file.type;
                      var match= ["image/jpeg","image/png","image/jpg"];
                      if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
                      {
                      return false;
                      }
                      else
                      {
                      var reader = new FileReader();
                      reader.onload = imageIsLoaded;
                      reader.readAsDataURL(this.files[0]);
                      }
                      });
                      
                      function imageIsLoaded(e) {
                      $("#file").css("color","green");
                      $('#image_preview').css("display", "block");
                      $('#previewing').attr('src', e.target.result);
                      $('#previewing').attr('width', '250px');
                      $('#previewing').attr('height', '154px');

                      $('#previewing2').attr('style', 'background-image:url('+e.target.result+');display:block;background-color: #fff; z-index: 554; margin-top: -130px; position: absolute; right: -50px;');
                      };


                      $('#usernameTyped').on('keyup', function(){
                        //document.getElementById("usernameAvailable").style.visibility = "visible";
                        var value = $(this).val();
                        jQuery.ajax({
                              type: "POST",
                              url: "<?php echo base_url(); ?>"+"Managements/checkUsernameAvailability",
                              dataType: 'json',
                          //mengirim data dengan type post
                          data: {usernameSent: value},
                          //menerima result dari controller
                          success: function(data) {
                             if (data.statsupdatenya== "yes") {
                              document.getElementById("usernameAvailable").style.visibility = "visible";
                              document.getElementById("usernameCannotUsed").style.visibility = "hidden";
                              document.getElementById("buttonSubmitForm").disabled = false;
                             }else {
                              document.getElementById("usernameAvailable").style.visibility = "hidden";
                              document.getElementById("usernameCannotUsed").style.visibility = "visible";
                              document.getElementById("buttonSubmitForm").disabled = true;
                             }
                          }
                        });

                      });

            });
        </script>

        <script type="text/javascript">
        function getUrlVars() {
          var vars = {};
          var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
            vars[key] = value;
          });
          return vars;
        }

        


                          var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                          
                          if (mytext=='success') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Berhasil Ditambahkan & \nEmail Pemberitahuan Terkirim',
                              showConfirmButton: true,
                              timer: 4500
                            });

                          }if (mytext=='success_delete_artikel') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'success',
                              title: 'Data berhasil dihapuskan.',
                              showConfirmButton: true,
                              timer: 3500
                            });

                          }if (mytext=='paymentDeclined') {
                            Swal.fire({
                              position: 'top-center',
                              icon: 'error',
                              title: 'Tagihan Berhasil Dibatalkan',
                              showConfirmButton: true,
                              timer: 4500
                            });

                          }
                        </script>
                        <script type="text/javascript">
                          $(function () {
                            $('[data-toggle="tooltip"]').tooltip()
                          })
                        </script>


          

        
      </body>
      </html>