
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Kelola Karyawan</title>

  <link href="<?php echo base_url(); ?>/assets/img/icons/logo.png" rel="icon" type="image/png">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">

  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/dist/css/adminlte.min.css">
  <style type="text/css">
        /*
         *  STYLE 3
         */
.item-show-up {
          box-shadow: 0px;
          border-radius: 0px;
          background: rgba(255,31,31,1);
background: -moz-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -webkit-gradient(left bottom, right top, color-stop(0%, rgba(255,31,31,1)), color-stop(100%, rgba(227,200,102,1)));
background: -webkit-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -o-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -ms-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff1f1f', endColorstr='#e3c866', GradientType=1 );
          -moz-transition: all 0.2s linear 0s;
          -webkit-transition: all 0.2s linear 0s;
          -o-transition: all 0.2s linear 0s;
          -ms-transition: all 0.2s linear 0s;
          color: #fff;
          
        }
        .item-show-up:hover {
          transform: scale(1.03,1.03);
          box-shadow: 0px 12px 12px #bfbfbf;

        }
        #style-3::-webkit-scrollbar-track
        {
          -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar
        {
          width: 6px;
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar-thumb
        {
          background-color: #000000;
          border-radius: 3px;
        }

        .boxing {
          position: relative;
          -webkit-transition:all 0.1s linear 0s;
          -moz-transition:all 0.1s linear 0s;
          -o-transition:all 0.1s linear 0s;
        }
        .boxing:hover {
          -webkit-transform: translateY(-5px);
          -moz-transform: translateY(-5px);
          -o-transform: translateY(-5px);
          z-index:100;
        }


    .square {
      width: 130px;
      height: 130px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      display: block;
      margin: auto;
      text-align: center;
      border-radius: 100px;
      margin-bottom: 15px;
    }
    .square2 {
      width: 60%;
      height: 110px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      margin-bottom: 15px;
    }

    /* input number stylish */
       input[type=number] {
          float: left;
          width: 70px;
          height: 35px;
          padding: 0;
          font-size: 1.2em;
          text-transform: uppercase;
          text-align: center;
          color: #93504C;
          border: 2px #93504C solid;
          background: none;
          outline: none;
          pointer-events: none;
        }

        span.spinner {
          position: absolute;
          height: 40px;
          user-select: none;
          -ms-user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -webkit-touch-callout: none;
        }

        span.spinner > .sub,
        span.spinner > .add {
          float: left;
          display: block;
          width: 35px;
          height: 35px;
          text-align: center;
          font-family: Lato;
          font-weight: 700;
          font-size: 1.2em;
          line-height: 33px;
          color: #93504C;
          border: 2px #93504C solid;
          border-right: 0;
          border-radius: 2px 0 0 2px;
          cursor: pointer;
          transition: 0.1s linear;
          -o-transition: 0.1s linear;
          -ms-transition: 0.1s linear;
          -moz-transition: 0.1s linear;
          -webkit-transition: 0.1s linear;
        }

        span.spinner > .add {
          top: 0;
          border: 2px #93504C solid;
          border-left: 0;
          border-radius: 0 2px 2px 0;
        }

        span.spinner > .sub:hover,
        span.spinner > .add:hover {
          background: #93504C;
          color: #25323B;
        }
         input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
         -webkit-appearance: none;
        }
        .selecteds {
          background-color: #999;
        }

   
  </style>
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to to the body tag
to get the desired effect
|---------------------------------------------------------|
|LAYOUT OPTIONS | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/demo.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/pages/dashboard3.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>

<script>
  $(document).on('click', '.number-spinner span', function () {    
    var btn = $(this),
      oldValue = btn.closest('.number-spinner').find('input').val().trim(),
      newVal = 0;

      btn.closest('.number-spinner').find('input').focus();
    
    if (btn.attr('data-dir') == 'up') {
      newVal = parseInt(oldValue) + 1;
      btn.closest('.number-spinner').find('input').val(newVal);
      btn.closest('.number-spinner').find('input').trigger("change");
    } else {
      if (oldValue > 1) {
        newVal = parseInt(oldValue) - 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      } else {
        newVal = 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      }
    }
    btn.closest('.number-spinner').find('input').val(newVal);
    btn.closest('.number-spinner').find('input').trigger("change");
  });
  </script>

  


  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-black  navbar-dark">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="<?php echo site_url('Welcome/index');?>" class="nav-link">Home</a>
        </li>
      
      </ul>

    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
          class="fas fa-ellipsis-h"></i></a>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="<?php echo site_url('Welcome/index');?>" class="brand-link">
        <img src="<?php echo base_url(); ?>/assets/img/icons/logo.png" alt="Dabalpro Logo" class="brand-image img-circle elevation-3"
        style="opacity: .8">
        <span class="brand-text font-weight-light"><b>Dabal</b>pro</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="<?php echo base_url(); ?><?php echo $pictureUserGiven;?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block"><?php echo $namaUserGiven;?></a>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->

           <li class="nav-item">
            <a href="<?php echo site_url('Welcome/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          

          <li class="nav-header">TRANSAKSI</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Transaksi Baru
                
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/history');?>" class="nav-link">
              <i class="nav-icon far fa-file"></i>
              <p>
                Riwayat Transaksi
                
              </p>
            </a>
          </li>
          
          
          
          <li class="nav-header">GUDANG</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/index');?>" class="nav-link">
              <i class="nav-icon fas fa-boxes"></i>
              <p>Lihat Gudang</p>
            </a>
          </li>
          
          <li class="nav-header">AKUN</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/akun');?>" class="nav-link ">
              <i class="nav-icon fas fa-user"></i>
              <p>Kelola Akun</p>
            </a>
          </li>
          <?php
            if ($levelUser=='10') { ?>
            <li class="nav-item">
            <a href="<?php echo site_url('Managements/akunKaryawan');?>" class="nav-link active">
              <i class="nav-icon fas fa-users"></i>
              <p>Kelola Karyawan</p>
            </a>
          </li>

          <?php } ?>
          <li class="nav-item " style="position: fixed; bottom: 0px;width: 235px;">
            <a href="<?php echo site_url('Login/logoutUser');?>" class="nav-link " >
              <i class="nav-icon fas fa-power-off text-danger"></i>
              <p class="text-danger">
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        
        <!-- /.row -->
                                        
        <div class="col-lg-12 col-md-12">
            
            <div class="row">
                    
                    
                      
                      <div class="col-md-3 mt-3">
                        <div class="card card-success">
                          <div class="card-header">
                            <h3 class="card-title float-left" style="display: block;">Tambah Karyawan </h3>
                            <font style="text-align: right; float: right;font-size: 11px; margin-top: 4px;">Fitur cepat</font>
                          </div>
                         
                            <div class="card-body">
                              <form id="showForm" action="<?php echo site_url('Managements/addDataKaryawan');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-12" style="margin: auto;text-align: center;">
                                     <div id="image_preview"><img class="profile-user-img img-circle" id="previewing" src="<?php echo base_url(); ?>/assets/img/images.png" style="width: 200px; height: 200px;" /></div>
                                   </div>
                                   <!-- /.col -->
                                 </div>
                                 <div class="row">
                                  <div class="col-md-8" style="margin: auto; margin-top: 15px">
                                   <div class="form-group">
                                    <div class="input-group">
                                      <div class="custom-file">
                                        <input type="file" name="pictureBarangX" class="custom-file-input tripleh" id="exampleInputFile">
                                        <label class="custom-file-label" for="exampleInputFile">Pilih foto</label>
                                      </div>

                                    </div>
                                  </div>
                                </div>
                                <!-- /.col -->
                              </div>
                              <hr/>
                                <div class="input-group mb-3">
                                  <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                  </div>
                                  <input type="text" class="form-control" placeholder="Username" name="username">
                                </div>

                                <div class="input-group mb-3">
                                  <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                  </div>
                                  <input type="email" class="form-control" placeholder="Email" name="email">
                                </div>
                                
                                
                                <div class="form-group row">
                                  <div class="col-sm-12">
                                    <button type="submit" class="btn btn-success float-right">Simpan Perubahan</button>
                                    
                                  </div>
                                </div>
                              </form>
                            </div>
                          
                          <!-- /.card-body -->
                        </div>
                      </div>

                      <div class="col-md-9 mt-3">
                        <div class="card card-primary">
                          <div class="card-header">
                            <h3 class="card-title float-left" style="display: block;">Daftar Karyawan </h3>
                            
                          </div>
                          <div class="card-body">
                              <div class="row d-flex align-items-stretch">
                                          <?php
                                            $no=0;
                                          if(!$listKaryawan->result()){ ?>
                                            
                                              <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                Tidak ada data untuk saat ini.
                                          <?php }else {
                                            foreach ($listKaryawan->result() as $row) {
                                             
                                          ?>

                                  <div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
                                    <div class="card bg-light">
                                      <div class="card-header text-muted border-bottom-0">
                                        Karyawan
                                      </div>
                                      <div class="card-body pt-0">
                                        <div class="row">
                                          <div class="col-7">
                                            <h2 class="lead"><b><?php if(!$row->namalengkap){echo "<b>Belum ditentukan</b>";}else{ echo $row->namalengkap;} ?></b></h2>
                                            <p class="text-muted text-sm"><b>Username: </b> <?php if(!$row->username){echo "<b>Belum ditentukan</b>";}else{ echo $row->username;} ?> </p>
                                            <ul class="ml-4 mb-0 fa-ul text-muted">
                                              <li class="small"><span class="fa-li"><i class="fas fa-lg fa-building"></i></span> Address: <?php if(!$row->address){echo "<b>Belum ditentukan</b>";}else{ echo $row->address;} ?></li>
                                              <li class="small"><span class="fa-li"><i class="fas fa-lg fa-phone"></i></span> Phone #: <?php if(!$row->telephone){echo "<b>Belum ditentukan</b>";}else{ echo $row->telephone;} ?></li>
                                            </ul>
                                          </div>
                                          <div class="col-5 text-center">
                                            <div class="img-circle square " style="background-image: url('<?php echo base_url().$row->pictureProfile; ?>')"></div>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="card-footer">
                                        <a href="#" class="btn btn-sm float-left" data-toggle="modal" id="btnShowDeleteBox" data-target="#modaldelete<?php echo $row->idUser;?>">
                                            <i class="fas fa-trash"></i>
                                          </a>
                                        <div class="text-right">

                                          <a href="https://wa.me/<?php echo $row->telephone;?>?text=Assalamualaikum warahmatullahi wabarakaatuh" class="btn btn-sm bg-teal" target="_blank" >
                                            <i class="fas fa-comments"></i>
                                          </a>

                                          
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="modal fade" id="modaldelete<?php echo $row->idUser;?>" data-keyboard="false" data-backdrop="static">
                                        <div class="modal-dialog modal-normal modal-dialog-centered">
                                          <form id="showForm<?php echo $row->idUser;?>" action="<?php echo site_url('Managements/prosesDeleteUser');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                                            <input type="hidden" name="idUser" value="<?php echo $row->idUser;?>">
                                          <div class="modal-content ">
                                            
                                            <div class="modal-body text-center">
                                              <h3>Konfirmasi</h3>
                                              Apakah anda yakin ingin menghapus user ini?<br/>
                                              <small class="text-muted" style="font-size: 10px;"><b>Penting!</b> Data user tersebut tidak dapat dikembalikan lagi apabila telah dihapus</small>
                                            </div>

                                            <div class="modal-footer" id="sideBtnSave<?php echo $row->idUser;?>">
                                              <button type="submit" class="btn btn-primary" data-dismiss="modal" aria-label="Close"  id="cancelDelete<?php echo $row->idUser;?>" style="float: left;"><i class="fas fa-times" style="margin-right: 10px;"></i> Batal</button>
                                              <button type="submit" class="btn btn-outline-danger" style="float: right;display: block;"><i class="fas fa-check" style="margin-right: 10px;"></i> Ya, Tetap Hapus</button>
                                            </div>
                                    </div>
                                    </form>
                                    <!-- /.modal-content -->
                                    </div>
                                  </div>
                                  <!-- /.modal-dialog -->
                                  

                                  

                                  <?php  } } ?>

                                 </div>
                      </div>
                    </div>
                  </div>

            </div>

            


            
          </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->




<!-- Main Footer -->
<footer class="main-footer " id="onlinehulp">
   <strong>Copyright &copy; Dabalpro - <?php echo date('Y');?>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->




<script type="text/javascript">
 $(window).on('load',function(){
 
});
</script>

<script type="text/javascript">
    $(document).ready(function() {
              $(".tripleh").change(function() {
              var file = this.files[0];
              var imagefile = file.type;
              var match= ["image/jpeg","image/png","image/jpg"];
              if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
              {
              return false;
              }
              else
              {
              var reader = new FileReader();
              reader.onload = imageIsLoaded;
              reader.readAsDataURL(this.files[0]);
              }
              });
              
              function imageIsLoaded(e) {
              $("#file").css("color","green");
              $('#image_preview').css("display", "block");
              $('#previewing').attr('src', e.target.result);
              $('#previewing').attr('width', '250px');
              $('#previewing').attr('height', '154px');
              };

    });
</script>


<!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
          <script type="text/javascript">
              function getUrlVars() {
                  var vars = {};
                  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                      vars[key] = value;
                  });
                  return vars;
              }


                  var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                  if (mytext=='klasifikasiduplicated') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'warning',
                                      title: 'Maaf kategori dengan nama tersebut sudah ada. Silahkan cek kembali.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
                  if (mytext=='username_duplicate') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'info',
                                      title: 'Maaf username tersebut sudah ada.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'User berhasil ditambahkan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
                  if (mytext=='success_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil diupdate.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil dihapuskan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete_user') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'User berhasil dihapuskan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='failed_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'danger',
                                      title: 'Maaf isian tidak boleh kosong',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }

                  $("input[data-bootstrap-switch]").each(function(){
                    $(this).bootstrapSwitch('state', $(this).prop('checked'));
                  });
          </script>




<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });

     
  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    $('[data-mask]').inputmask()

    
  })
</script>

<script type="text/javascript">
  $(document).ready(function () {
    bsCustomFileInput.init();
  });
</script>

          

</body>
</html>
