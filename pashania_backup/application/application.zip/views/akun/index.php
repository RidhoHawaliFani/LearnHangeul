
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Kelola Akun Anda</title>

  <link href="<?php echo base_url(); ?>/assets/img/icons/logo.png" rel="icon" type="image/png">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">

  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/dist/css/adminlte.min.css">
  <style type="text/css">
        /*
         *  STYLE 3
         */
.item-show-up {
          box-shadow: 0px;
          border-radius: 0px;
          background: rgba(255,31,31,1);
background: -moz-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -webkit-gradient(left bottom, right top, color-stop(0%, rgba(255,31,31,1)), color-stop(100%, rgba(227,200,102,1)));
background: -webkit-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -o-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -ms-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff1f1f', endColorstr='#e3c866', GradientType=1 );
          -moz-transition: all 0.2s linear 0s;
          -webkit-transition: all 0.2s linear 0s;
          -o-transition: all 0.2s linear 0s;
          -ms-transition: all 0.2s linear 0s;
          color: #fff;
          
        }
        .item-show-up:hover {
          transform: scale(1.03,1.03);
          box-shadow: 0px 12px 12px #bfbfbf;

        }
        #style-3::-webkit-scrollbar-track
        {
          -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar
        {
          width: 6px;
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar-thumb
        {
          background-color: #000000;
          border-radius: 3px;
        }

        .boxing {
          position: relative;
          -webkit-transition:all 0.1s linear 0s;
          -moz-transition:all 0.1s linear 0s;
          -o-transition:all 0.1s linear 0s;
        }
        .boxing:hover {
          -webkit-transform: translateY(-5px);
          -moz-transform: translateY(-5px);
          -o-transform: translateY(-5px);
          z-index:100;
        }


    .square {
      width: 200px;
      height: 200px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      display: block;
      margin: auto;
      text-align: center;
      border-radius: 10px;
      margin-bottom: 15px;
    }
    .square2 {
      width: 60%;
      height: 110px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      margin-bottom: 15px;
    }

    /* input number stylish */
       input[type=number] {
          float: left;
          width: 70px;
          height: 35px;
          padding: 0;
          font-size: 1.2em;
          text-transform: uppercase;
          text-align: center;
          color: #93504C;
          border: 2px #93504C solid;
          background: none;
          outline: none;
          pointer-events: none;
        }

        span.spinner {
          position: absolute;
          height: 40px;
          user-select: none;
          -ms-user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -webkit-touch-callout: none;
        }

        span.spinner > .sub,
        span.spinner > .add {
          float: left;
          display: block;
          width: 35px;
          height: 35px;
          text-align: center;
          font-family: Lato;
          font-weight: 700;
          font-size: 1.2em;
          line-height: 33px;
          color: #93504C;
          border: 2px #93504C solid;
          border-right: 0;
          border-radius: 2px 0 0 2px;
          cursor: pointer;
          transition: 0.1s linear;
          -o-transition: 0.1s linear;
          -ms-transition: 0.1s linear;
          -moz-transition: 0.1s linear;
          -webkit-transition: 0.1s linear;
        }

        span.spinner > .add {
          top: 0;
          border: 2px #93504C solid;
          border-left: 0;
          border-radius: 0 2px 2px 0;
        }

        span.spinner > .sub:hover,
        span.spinner > .add:hover {
          background: #93504C;
          color: #25323B;
        }
         input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
         -webkit-appearance: none;
        }
        .selecteds {
          background-color: #999;
        }

   
  </style>
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to to the body tag
to get the desired effect
|---------------------------------------------------------|
|LAYOUT OPTIONS | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/jquery/jquery.min.js"></script>
    <!--  Bootstrap -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/adminlte.js"></script>

  <!-- OPTIONAL SCRIPTS -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/chart.js/Chart.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/demo.js"></script>
  <script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/pages/dashboard3.js"></script>

  <!-- DataTables -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables/jquery.dataTables.js"></script>
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- bs-custom-file-input -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
  <!-- Select2 -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/js/select2.full.min.js"></script>
  <!-- InputMask -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/moment/moment.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

<script>
  $(document).on('click', '.number-spinner span', function () {    
    var btn = $(this),
      oldValue = btn.closest('.number-spinner').find('input').val().trim(),
      newVal = 0;

      btn.closest('.number-spinner').find('input').focus();
    
    if (btn.attr('data-dir') == 'up') {
      newVal = parseInt(oldValue) + 1;
      btn.closest('.number-spinner').find('input').val(newVal);
      btn.closest('.number-spinner').find('input').trigger("change");
    } else {
      if (oldValue > 1) {
        newVal = parseInt(oldValue) - 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      } else {
        newVal = 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      }
    }
    btn.closest('.number-spinner').find('input').val(newVal);
    btn.closest('.number-spinner').find('input').trigger("change");
  });
  </script>

  


  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-black  navbar-dark">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="<?php echo site_url('Welcome/index');?>" class="nav-link">Home</a>
        </li>
      
      </ul>

    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
          class="fas fa-ellipsis-h"></i></a>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="<?php echo site_url('Welcome/index');?>" class="brand-link">
        <img src="<?php echo base_url(); ?>/assets/img/icons/logo.png" alt="Dabalpro Logo" class="brand-image img-circle elevation-3"
        style="opacity: .8">
        <span class="brand-text font-weight-light"><b>Dabal</b>pro</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="<?php echo base_url(); ?><?php echo $pictureUserGiven;?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block"><?php echo $namaUserGiven;?></a>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->

           <li class="nav-item">
            <a href="<?php echo site_url('Welcome/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          

          <li class="nav-header">TRANSAKSI</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Transaksi Baru
                
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/history');?>" class="nav-link">
              <i class="nav-icon far fa-file"></i>
              <p>
                Riwayat Transaksi
                
              </p>
            </a>
          </li>
          
          
          
          <li class="nav-header">GUDANG</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/index');?>" class="nav-link">
              <i class="nav-icon fas fa-boxes"></i>
              <p>Lihat Gudang</p>
            </a>
          </li>
          
          <li class="nav-header">AKUN</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/akun');?>" class="nav-link active">
              <i class="nav-icon fas fa-user"></i>
              <p>Kelola Akun</p>
            </a>
          </li>
          <?php
            if ($levelUser=='10') { ?>
            <li class="nav-item">
            <a href="<?php echo site_url('Managements/akunKaryawan');?>" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Kelola Karyawan</p>
            </a>
          </li>

          <?php } ?>
          <!-- <li class="nav-header">LABEL</li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-danger"></i>
              <p class="text">Penting</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Perhatian</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Informasi</p>
            </a>
          </li> -->

          <li class="nav-item " style="position: fixed; bottom: 0px;width: 235px;">
            <a href="<?php echo site_url('Login/logoutUser');?>" class="nav-link " >
              <i class="nav-icon fas fa-power-off text-danger"></i>
              <p class="text-danger">
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        
        <!-- /.row -->
                                          <?php
                                            $no=0;
                                          if(!$userData->result()){ ?>
                                            
                                              <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                Tidak ada data untuk saat ini.
                                          <?php }else {
                                            foreach ($userData->result() as $row) {
                                             
                                          ?>
        <div class="col-lg-12 col-md-12">
            
            <div class="row">
                    <div class="col-md-3 mt-3">
                        <!-- Profile Image -->
                        <div class="card card-primary card-outline">
                          <div class="card-body box-profile">
                            <div class="text-center">
                              <a class="btn btn-sm btn-outline-primary" style="position: absolute; right: 20px;" href="#" id="btnEditFotoProfil" >
                                <i class="fas fa-pen"></i>
                              </a>
                              <div class="square" id="divFotoProfilLama" style="background-image: url('<?php echo base_url().$row->pictureProfile; ?>')"></div>

                              <div id="editFotoProfil">
                                <form id="showForm" action="<?php echo site_url('Managements/uploadFotoProfil');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                                  <button class="btn btn-sm btn-success" type="submit" style="position: absolute; right: 20px;z-index: 1000;"><i class="fas fa-check"></i></button>
                                    <div class="row">
                                        <div class="col-md-12" style="margin: auto;text-align: center;">
                                         <div id="image_preview"><img class="profile-user-img img-circle" id="previewing" src="<?php echo base_url(); ?>/assets/img/images.png" style="width: 200px; height: 200px;" /></div>
                                       </div>
                                       <!-- /.col -->
                                     </div>
                                     <div class="row">
                                      <div class="col-md-8" style="margin: auto; margin-top: 15px">
                                       <div class="form-group">
                                        <div class="input-group">
                                          <div class="custom-file">
                                            <input type="file" name="fotobaru" class="custom-file-input tripleh" id="exampleInputFile" required="">
                                            <label class="custom-file-label text-left" for="exampleInputFile">Pilih foto</label>
                                          </div>

                                        </div>
                                      </div>
                                    </div>
                                    <!-- /.col -->
                                  </div>

                                </form>
                              </div>

                            </div>

                            <h3 class="profile-username text-center"><?php echo $row->namalengkap;?></h3>

                            <p class="text-muted text-center"><?php if($row->statusLevelUser=='10'){echo "Administrator Sistem";}else {echo "Karyawan";};?></p>

                            <ul class="list-group list-group-unbordered mb-3">
                              <li class="list-group-item">
                                <b>Username</b> <a class="float-right"><?php echo $row->username;?></a>
                              </li>
                              <li class="list-group-item">
                                <b>Password</b> <a class="float-right">* * * * *</a>
                              </li>
                              <li class="list-group-item">
                                <b>Email</b> <a class="float-right"><?php echo $row->email;?></a>
                              </li>
                            </ul>
                            <a href="#" class="btn btn-primary btn-block" id="btnEdit"><b>Edit Akun</b></a>

                          </div>
                          <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- About Me Box -->
                        
                      </div>
                      <div class="col-md-4 mt-3">
                        <div class="card card-primary">
                          <div class="card-header">
                            <h3 class="card-title">Informasi Pribadi</h3>
                          </div>
                          <!-- /.card-header -->
                          <div class="card-body">
                            <strong><i class="fas fa-map-marker-alt mr-1"></i> Alamat</strong>

                            <p class="text-muted ml-4">
                              <?php echo $row->address;?>
                            </p>

                            <hr>

                            <strong><i class="fas fa-calendar-alt mr-1"></i> Tanggal Lahir (Umur)</strong>

                            <p class="text-muted ml-4"><?php echo $row->tglTrans;?> (<?php echo $row->ages;?> tahun)</p>

                            <hr>

                            <strong><i class="fas fa-male"></i><i class="fas fa-female mr-1"></i> Gender</strong>

                            <p class="text-muted ml-4">
                               <?php echo $row->gender;?>
                            </p>

                            <hr>

                            <strong><i class="fas fa-phone mr-1"></i> Kontak</strong>

                            <p class="text-muted ml-4"> <?php echo $row->telephone;?></p>
                          </div>
                          <!-- /.card-body -->
                        </div>
                      </div>

                      <div class="col-md-5 mt-3 scrollbar" style="max-height: 780px; overflow-y:scroll;" id="style-3">
                        <div class="card card-primary">
                          <div class="card-header">
                            <h3 class="card-title">Aktifitas Terakhir Saya</h3>
                          </div>
                          <!-- /.card-header -->
                          <div class="card-body">
                            <ul class="list-group list-group-unbordered mb-3 ">

                                          <?php
                                            $no=0;
                                          if(!$listActivity->result()){ ?>
                                            
                                              <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                Tidak ada data untuk saat ini.
                                          <?php }else {
                                            foreach ($listActivity->result() as $row2) {
                                             
                                          ?>
                              <li class="list-group-item">
                                <div class="row">
                                  <div class="col-md-9">
                                    <?php echo $row->username.' '.$row2->keterangan;?>
                                  </div>
                                  <div class="col-md-3 float-right text-right text-muted"><small><?php echo $row2->tglTrans;?> WIB</small><br/>
                                  <font style="font-size: 10px;" class="text-muted"><?php echo $row2->dateTrans;?></font></div>
                                </div>
                              </li>

                            <?php }} ?>
                              
                            </ul>
                          </div>
                          <!-- /.card-body -->
                        </div>
                      </div>

                      <div class="col-md-5 mt-3" id="style-4">
                        <div class="card card-warning">
                          <div class="card-header">
                            <h3 class="card-title">Edit Profil</h3>
                          </div>
                          <!-- /.card-header -->
                                          <?php
                                            $no=0;
                                          if(!$userData->result()){ ?>
                                            
                                              <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                Tidak ada data untuk saat ini.
                                          <?php }else {
                                            foreach ($userData->result() as $row) {
                                             
                                          ?>
                            <div class="card-body">
                              <form id="showForm" action="<?php echo site_url('Managements/updateDataUser');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                                <div class="form-group row">
                                  <label for="inputName" class="col-sm-2 col-form-label">Username</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputName" placeholder="Name" value="<?php echo $row->username;?>" disabled="">
                                  </div>
                                </div>
                                <div class="form-group row">
                                  <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                                  <div class="col-sm-10">
                                    <input type="email" class="form-control" id="inputEmail" placeholder="Email" value="<?php echo $row->email;?>" name="email">
                                  </div>
                                </div>
                                <div class="form-group row">
                                  <label for="inputName2" class="col-sm-2 col-form-label">Display name</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputName2" placeholder="Name" value="<?php echo $row->namalengkap;?>" name="namaLengkap">
                                  </div>
                                </div>
                                <div class="form-group row">
                                  <label for="inputExperience" class="col-sm-2 col-form-label">Address</label>
                                  <div class="col-sm-10">
                                    <textarea class="form-control" id="inputExperience" placeholder="Experience" name="address"><?php echo $row->address;?></textarea>
                                  </div>
                                </div>
                                <div class="form-group row">
                                  <label for="inputSkills" class="col-sm-2 col-form-label">Telephone</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputSkills" placeholder="Skills" value="<?php echo $row->telephone;?>" name="telephone">
                                  </div>
                                </div>
                                <div class="form-group row input-group">
                                  <label for="inputSkills" class="col-sm-2 col-form-label">Birthday</label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" data-inputmask-alias="datetime" name="birthday" data-inputmask-inputformat="yyyy/mm/dd" data-mask value="<?php echo $row->birthday;?>">
                                  </div>
                                </div>

                                <div class="form-group row input-group">
                                  <label for="inputSkills" class="col-sm-2 col-form-label">Gender</label>
                                  <div class="col-sm-10">
                                        
                                    <div class="icheck-primary d-inline mr-3">
                                      <input type="radio" id="radioPrimary1" name="gender" <?php if($row->gender=='Laki-laki'){echo "checked";} ?> value="Laki-laki" >
                                      <label for="radioPrimary1"> Laki laki
                                      </label>
                                    </div>
                                    <div class="icheck-primary d-inline">
                                      <input type="radio" id="radioPrimary2" name="gender" <?php if($row->gender=='Perempuan'){echo "checked";} ?> value="Perempuan">
                                      <label for="radioPrimary2"> Perempuan
                                      </label>
                                    </div>
                                    
                                  </div>
                                </div>


                                
                                <div class="form-group row">
                                  <div class="offset-sm-2 col-sm-10">
                                    <button type="submit" class="btn btn-success float-left">Simpan Perubahan</button>
                                    <button type="button" class="btn btn-outline-secondary float-right" id="btnBatalEdit">Batal</button>

                                  </div>
                                </div>
                              </form>
                            </div>
                          <?php } } ?>
                          <!-- /.card-body -->
                        </div>
                      </div>

                    <?php } } ?>
                    

            </div>

            


            
          </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->




<!-- Main Footer -->
<footer class="main-footer " id="onlinehulp">
   <strong>Copyright &copy; Dabalpro - <?php echo date('Y');?>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<script type="text/javascript">
    $(document).ready(function() {
              $(".tripleh").change(function() {
              var file = this.files[0];
              var imagefile = file.type;
              var match= ["image/jpeg","image/png","image/jpg"];
              if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
              {
              return false;
              }
              else
              {
              var reader = new FileReader();
              reader.onload = imageIsLoaded;
              reader.readAsDataURL(this.files[0]);
              }
              });
              
              function imageIsLoaded(e) {
              $("#file").css("color","green");
              $('#image_preview').css("display", "block");
              $('#previewing').attr('src', e.target.result);
              $('#previewing').attr('width', '250px');
              $('#previewing').attr('height', '154px');
              };

    });
</script>


<script type="text/javascript">
 $(window).on('load',function(){
  document.getElementById("style-3").style.display = "block";
  document.getElementById("style-4").style.display = "none";


  document.getElementById("editFotoProfil").style.display = "none";


  
});
</script>

<script type="text/javascript">
    $(document).ready(function() {

                $('#btnEditFotoProfil').on('click', function(){
                  
                    document.getElementById("divFotoProfilLama").style.display = "none";
                    document.getElementById("editFotoProfil").style.display = "block";
                    // $("#btnEdit").attr('class', 'btn btn-secondary btn-block disabled');
                  
                });
                
                $('#btnEdit').on('click', function(){
                  
                    document.getElementById("style-3").style.display = "none";
                    document.getElementById("style-4").style.display = "block";
                    $("#btnEdit").attr('class', 'btn btn-secondary btn-block disabled');
                  
                });

                $('#btnBatalEdit').on('click', function(){
                    document.getElementById("style-3").style.display = "block";
                    document.getElementById("style-4").style.display = "none";
                    $("#btnEdit").attr('class', 'btn btn-primary btn-block');
                  
                });

    });
</script>


          <!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
          <script type="text/javascript">
              function getUrlVars() {
                  var vars = {};
                  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                      vars[key] = value;
                  });
                  return vars;
              }


                  var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                  if (mytext=='klasifikasiduplicated') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'warning',
                                      title: 'Maaf kategori dengan nama tersebut sudah ada. Silahkan cek kembali.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
                  if (mytext=='success_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil diupdate.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_update_photo') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Foto profil berhasil diupdate',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil dihapuskan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='failed_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'danger',
                                      title: 'Maaf isian tidak boleh kosong',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
          </script>




<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });

     
  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    $('[data-mask]').inputmask()

    
  })
</script>

<script type="text/javascript">
  $(document).ready(function () {
    bsCustomFileInput.init();
  });
</script>

          

</body>
</html>
