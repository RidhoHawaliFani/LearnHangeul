<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>PT. Nida Utama Sejahtera  Travel Haji & Umrah</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <link href="<?php echo base_url(); ?>/assets_nidautama/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/animate/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link href="<?php echo base_url(); ?>/assets_nidautama/css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />

  <!-- =======================================================
    Theme Name: Regna
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
    ======================================================= -->

    <style type="text/css">

      .square {
        width: 100%;
        height: 550px;
        text-align: center;
        margin: auto;
        background-size: cover;
        background-position: center;
        border-radius: 10px;
        border: 4px solid #fff;

      }
      .square2 {
        width: 100px;
        height: 100px;
        text-align: center;
        margin: auto;
        background-size: cover;
        background-position: center;
        border-radius: 10px;
        border: 4px solid #fff;
      }

      .square5 {
        width: 40px;
        height: 40px;
        text-align: center;
        margin: auto;
        background-size: cover;
        background-position: center;
        border-radius: 10px;
        border: 4px solid #f0f0f0;
      }

      #quote-carousel {
        padding: 0 10px 30px 10px;
        margin-top: 30px;
      }

      #quote-carousel .carousel-control {
        background: none;
        color: #222;
        font-size: 2.3em;
        text-shadow: none;
        margin-top: 30px;
      }

      #quote-carousel .carousel-control.left {
        left: -12px;
      }

      #quote-carousel .carousel-control.right {
        right: -12px !important;
      }

      #quote-carousel .carousel-indicators {
        right: 50%;
        top: auto;
        bottom: 0px;
        margin-right: -19px;
      }

      #quote-carousel .carousel-indicators li {
        background: #c0c0c0;
      }
      #quote-carousel .carousel-indicators .active {
        background: #333333;
      }
      #quote-carousel img {
        width: 250px;
        height: 100px
      }

      .item blockquote {
        border-left: none;
        margin: 0;
      }
      .item blockquote img {
        margin-bottom: 10px;
      }
      .item blockquote p:before {
        content: "\f10d";
        font-family: 'Fontawesome';
        float: left;
        margin-right: 10px;
      }
      @media (min-width: 768px) {
        #quote-carousel {
         margin-bottom: 0;
         padding: 0 40px 30px 40px;
       }
     }

     @media (max-width: 768px) {

      #quote-carousel .carousel-indicators {
       bottom: -20px !important;
     }
     #quote-carousel .carousel-indicators li {
       display: inline-block;
       margin: 0px 5px;
       width: 15px;
       height: 15px;
     }
     #quote-carousel .carousel-indicators li.active {
       margin: 0px 5px;
       width: 20px;
       height: 20px;
     }
   }


   .slider {
    width: 100%;
    height: 430px;
    position: relative;
    overflow: hidden;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-flow: row nowrap;
    -ms-flex-flow: row nowrap;
    flex-flow: row nowrap;
    -webkit-box-align: end;
    -webkit-align-items: flex-end;
    -ms-flex-align: end;
    align-items: flex-end;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
  }

  .slider__nav {
    width: 17px;
    height: 17px;
    margin: 2rem 12px;
    border-radius: 50%;
    z-index: 10;
    outline: 6px solid #ffb803;
    outline-offset: -6px;
    box-shadow: 0 0 0 0 #333, 0 0 0 0 rgba(51, 51, 51, 0);
    cursor: pointer;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    -webkit-backface-visibility: hidden;
    padding-bottom: 20px;
    backface-visibility: hidden;
  }

  .slider__nav:checked {
    -webkit-animation: check 0.5s linear forwards;
    animation: check 0.5s linear forwards;
  }

  .slider__nav:checked:nth-of-type(1) ~ .slider__inner {
    -webkit-transform: translateX(0%);
    transform: translateX(0%);
  }

  .slider__nav:checked:nth-of-type(2) ~ .slider__inner {
    -webkit-transform: translateX(-40%);
    transform: translateX(-40%);
  }



  .slider__inner {
    position: absolute;
    top: 0;
    left: 0;
    width: 1000px;
    height: 100%;
    -webkit-transition: all 1s ease-out;
    transition: all 1.2s ease-out;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-flow: row nowrap;
    -ms-flex-flow: row nowrap;
    flex-flow: row nowrap;
  }

  .slider__contents {
    width: 100%;
    height: 100%;
    padding: 2rem;
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    -webkit-flex-flow: column nowrap;
    -ms-flex-flow: column nowrap;
    flex-flow: column nowrap;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;

  }

  .slider__image { font-size: 2.7rem; }

  .slider__caption {
    font-weight: 700;
    margin: 2rem 0 1rem;
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
    text-transform: uppercase;
  }

  .slider__txt {
    color: #999;
    margin-bottom: 3rem;
    max-width: 300px;
  }

  .slidesXXX {
    width: 100%;
    height: 100%;
    background: url(<?php echo base_url(); ?>/assets_nidautama/img/hero-bg-2.jpg) center center;
    background-repeat:  no-repeat;
    background-size: cover;
    position: relative;
    box-shadow: 3px 10px 13px #1c1c1c ;
    border-radius: 12px;
    min-height: 350px;
    padding: 0px;
    border: none;
    color: white;

  }
  #tetew {
    position: relative;
    -moz-transition : all 0.1s linear 0s;
    -webkit-transition : all 0.1s linear 0s;
    -ms-transition : all 0.1s linear 0s;
    -o-transition : all 0.1s linear 0s;
  }
  #tetew:hover {
    -webkit-transform : scale(1.01,1.01);
    -o-transform : scale(1.01,1.01);
    -ms-transform : scale(1.01,1.01);
    -moz-transform : scale(1.01,1.01);

  }



  .slidesXXX:before {
    content: "";
    background: rgba(128, 73, 28, 0.2);
    position: absolute;
    bottom: 0;
    top: 0;
    left: 0;
    right: 0;
    border-radius: 12px;
  }

  /* Absolute Center Spinner */
    .loading {
      position: fixed;
      z-index: 999;
      height: 2em;
      width: 2em;
      overflow: visible;
      margin: auto;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
    }

    /* Transparent Overlay */
    .loading:before {
      content: '';
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.8);
    }

    /* :not(:required) hides these rules from IE9 and below */
    .loading:not(:required) {
      /* hide "loading..." text */
      font: 0/0 a;
      color: transparent;
      text-shadow: none;
      background-color: transparent;
      border: 0;
    }

    .loading:not(:required):after {
      content: '';
      display: block;
      font-size: 10px;
      width: 1em;
      height: 1em;
      margin-top: -0.5em;
      -webkit-animation: spinner 1500ms infinite linear;
      -moz-animation: spinner 1500ms infinite linear;
      -ms-animation: spinner 1500ms infinite linear;
      -o-animation: spinner 1500ms infinite linear;
      animation: spinner 1500ms infinite linear;
      border-radius: 0.5em;
      -webkit-box-shadow: rgba(0, 0, 0, 0.75) 1.5em 0 0 0, rgba(0, 0, 0, 0.75) 1.1em 1.1em 0 0, rgba(0, 0, 0, 0.75) 0 1.5em 0 0, rgba(0, 0, 0, 0.75) -1.1em 1.1em 0 0, rgba(0, 0, 0, 0.5) -1.5em 0 0 0, rgba(0, 0, 0, 0.5) -1.1em -1.1em 0 0, rgba(0, 0, 0, 0.75) 0 -1.5em 0 0, rgba(0, 0, 0, 0.75) 1.1em -1.1em 0 0;
      box-shadow: rgba(255, 255, 255, 0.75) 1.5em 0 0 0, rgba(255, 255, 255, 0.75) 1.1em 1.1em 0 0, rgba(255, 255, 255, 0.75) 0 1.5em 0 0, rgba(255, 255, 255, 0.75) -1.1em 1.1em 0 0, rgba(255, 255, 255, 0.75) -1.5em 0 0 0, rgba(255, 255, 255, 0.75) -1.1em -1.1em 0 0, rgba(255, 255, 255, 0.75) 0 -1.5em 0 0, rgba(255, 255, 255, 0.75) 1.1em -1.1em 0 0;

    }

    /* Animation */

    @-webkit-keyframes spinner {
      0% {
        -webkit-transform: rotate(0deg);
        -moz-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        -o-transform: rotate(0deg);
        transform: rotate(0deg);
      }
      100% {
        -webkit-transform: rotate(360deg);
        -moz-transform: rotate(360deg);
        -ms-transform: rotate(360deg);
        -o-transform: rotate(360deg);
        transform: rotate(360deg);
      }
    }
    @-moz-keyframes spinner {
      0% {
        -webkit-transform: rotate(0deg);
        -moz-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        -o-transform: rotate(0deg);
        transform: rotate(0deg);
      }
      100% {
        -webkit-transform: rotate(360deg);
        -moz-transform: rotate(360deg);
        -ms-transform: rotate(360deg);
        -o-transform: rotate(360deg);
        transform: rotate(360deg);
      }
    }
    @-o-keyframes spinner {
      0% {
        -webkit-transform: rotate(0deg);
        -moz-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        -o-transform: rotate(0deg);
        transform: rotate(0deg);
      }
      100% {
        -webkit-transform: rotate(360deg);
        -moz-transform: rotate(360deg);
        -ms-transform: rotate(360deg);
        -o-transform: rotate(360deg);
        transform: rotate(360deg);
      }
    }
    @keyframes spinner {
      0% {
        -webkit-transform: rotate(0deg);
        -moz-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        -o-transform: rotate(0deg);
        transform: rotate(0deg);
      }
      100% {
        -webkit-transform: rotate(360deg);
        -moz-transform: rotate(360deg);
        -ms-transform: rotate(360deg);
        -o-transform: rotate(360deg);
        transform: rotate(360deg);
      }
    }




  @-webkit-keyframes 
  check {  50% {
   outline-color: #fcfcfc;
   box-shadow: 0 0 0 12px #fcfcfc, 0 0 0 36px rgba(51, 51, 51, 0.2);
 }
 100% {
   outline-color: #fcfcfc;
   box-shadow: 0 0 0 0 #fcfcfc, 0 0 0 0 rgba(51, 51, 51, 0);
 }
}

@keyframes 
check {  50% {
 outline-color: #fcfcfc;
 box-shadow: 0 0 0 12px #fcfcfc, 0 0 0 36px rgba(51, 51, 51, 0.2);
}
100% {
 outline-color: #fcfcfc;
 box-shadow: 0 0 0 0 #fcfcfc, 0 0 0 0 rgba(51, 51, 51, 0);
}
}
</style>
</head>

<body>

  <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#quote-carousel').carousel({
        pause: true,
        interval: 4000,
      });
    });
  </script>

  <style type="text/css">

  </style>
  <!--==========================
  Header
  ============================-->
  <header id="header">
    <div class="container">




    </div>
  </header><!-- #header -->

  <!--==========================
    Hero Section
    ============================-->


    <main id="main">

    <!--==========================
      About Us Section
      ============================-->
      

    <!--==========================
      Facts Section
     

    Call To Action Section
    ============================-->
    <header id="header">
      <div class="container">

        <div id="logo" class="pull-left">
          <a href="#hero" style="color: white;font-weight: bold;">NIDA UTAMA SEJAHTERA</a>
          <!-- Uncomment below if you prefer to use a text logo -->
          <!--<h1><a href="#hero">Regna</a></h1>-->
        </div>

        <nav id="nav-menu-container">
          <ul class="nav-menu">
            <li ><a href="<?php echo site_url('Welcome');?>">Home</a></li>
            <?php if(!$levelUser) { ?>
              <li><a href="<?php echo site_url('login');?>">Login</a></li>
              <li><a href="<?php echo site_url('register');?>">Register</a></li>
            <?php } elseif ($levelUser==10) {

              ?>
              <li class="menu-has-children"><a href=""><?php echo $namaUserGiven;?></a>
                <ul>
                  <div class="dropdown-header text-center" style="background-color: #fff;padding-top: 15px; padding-bottom: 20px;">
                    <div class="square2 img-md rounded-circle" style="background-image: url(<?php echo base_url(); ?><?php
                      if(!$pictureUserGiven){
                        echo '/assets/img/pictprofile/nidautamauser_default.png';
                      }else {echo $pictureUserGiven;};?>); "></div>

                      <p class="mb-1 mt-3"><?php echo $namaUserGiven;?></p>
                      <p class="font-weight-light text-muted mb-0">
                        <?php if ($levelUser==10) { echo 'Administrator';}else { echo 'Normal User';}?>
                      </p>
                    </div>
                    <li> <a href="<?php echo site_url('Managements/index');?>"><i class="fa fa-dashboard mr-2"></i> Dashboard</a></li>
                    <li><a href="#"><i class="fa fa-user mr-2"></i> Profil Saya</a></li>
                    <hr/>
                    <li><a href="#"><i class="fa fa-sign-out mr-2"></i> Logout</a></li>

                  </ul>
                </li>
              <?php }elseif ($levelUser==2) { ?>
               <li class="menu-has-children"><a href=""><?php echo $namaUserGiven;?></a>
                <ul>
                  <div class="dropdown-header text-center" style="background-color: #fff;padding-top: 15px; padding-bottom: 20px;">
                    <div class="square2 img-md rounded-circle" style="background-image: url(<?php echo base_url(); ?><?php
                      if(!$pictureUserGiven){
                        echo '/assets/img/pictprofile/nidautamauser_default.png';
                      }else {echo $pictureUserGiven;};?>); "></div>

                      <p class="mb-1 mt-3"><?php echo $namaUserGiven;?></p>
                      <p class="font-weight-light text-muted mb-0">
                        <?php if ($levelUser==10) { echo 'Administrator';}else { echo 'Normal User';}?>
                      </p>
                    </div>
                    <li> <a href="<?php echo site_url('User/index');?>"><i class="fa fa-dashboard mr-2"></i> Dashboard</a></li>
                    <li><a href="#"><i class="fa fa-user mr-2"></i> Profil Saya</a></li>
                    <hr/>
                    <li><a href="<?php echo site_url('Login/logoutUser');?>"><i class="fa fa-sign-out mr-2"></i> Logout</a></li>

                  </ul>
                </li>
              <?php }?>
            </ul>
          </nav><!-- #nav-menu-container -->
        </div>
      </header><!-- #header -->

      
      <?php
      $no=0;
      if(!$listPaketTour->result() and !$idUser){ ?>



      <?php }else {
        foreach ($listPaketTour->result() as $row) {

          ?>
          <section id="call-to-action">
            <div class="container wow fadeIn">
              <div class="col-md-12" style="z-index: 109;">
                <h1 style="z-index: 99999; font-size: 50px; font-weight: 800; color: white; padding-top: 100px; text-shadow: 3px 0px 3px #30b309"><?php echo $row->judulArtikel;?></h1>

              </div>
              <div class="col-md-6">

              </div>

            </div>
          </section><!-- #call-to-action -->

    <!--==========================
      Portfolio Section
      ============================-->
      <section id="portfolio">
        <div class="container wow fadeInUp" style="margin-top: -150px;">



          <div class="row" id="portfolio-wrapper">
            <div class="col-md-8">
              <div class="square d-block mb-3" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureArtikel){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureArtikel;}?>"></div>
              <div class="row">
                <div class="col-md-12">
                  <div class="card" style="border: 0; border-radius: 10px;">
                    <div class="card-body" style="padding: 20px; width: 100%;">
                      <p><?php echo nl2br($row->konten);?></p>

                    </div>
                    <div class="card-footer text-muted" style="background-color: #ebebeb; border-bottom-right-radius: 10px; border-bottom-left-radius: 10px; font-size: 11px;">
                      Publikasi pada <b>20 May 2020 12:12:00 WIB</b> <font class="ml-3">Oleh : <b>Administrator</b></font> <font class="ml-3">Kategori : <b>Umroh, Haji, Mekkah, Madinah</b></font>
                    </div>
                  </div>
                </div>

              </div>

              <div class="row" id="komentar">
                <div class="col-md-12 mt-5">
                  <div class="card" style="border: 0; border-radius: 10px;">
                    <div class="card-header" style="background-color: #ebebeb; border-top-right-radius: 10px; border-top-left-radius: 10px; font-size: 15px; font-weight: bold;">
                      Komentar Sebelumnya
                    </div>
                    <div class="card-body" style="padding: 20px; width: 100%;">
                      

                        <?php
                        $no=0;
                        if(!$listKomentar->result()){ ?>

                          <p>Tidak ada komentar.</p>

                        <?php }else {
                          foreach ($listKomentar->result() as $row2) {

                            ?>
                        <div class="col-md-12 mb-5">
                          <div class="row">
                            <div class="col-md-1">
                                                  <div class="square5 img-md rounded-circle" style="background-image: url(<?php echo base_url(); ?><?php echo '/assets/img/pictprofile/as.png';?>); "></div>
                            </div>
                            <div class="col-md-11">
                              <font style="text-muted"><small> <?php echo $row2->nama;?></small></font> <font class="pull-right" style="font-size: 11px;"><?php echo $row2->jamPembuatan;?> WIB<br/><?php echo $row2->tglPembuatan;?></font><br/>
                              <span><?php echo nl2br($row2->komentar);?></span>

                            </div>
                          </div>
                        </div>

                          <?php } } ?>
                      

                    </div>
                    
                  </div>
                </div>

              </div>
              
            </div>



            <div class="col-md-4" id="firstSlide">
              <div class="col-md-12 follow-scroll" style="">
                <div class="card" style="border: 0; border-radius: 10px;box-shadow: 0px 3px 4px #969696; ">
                  <div class="card-header" style="background: rgb(34,193,195);
                  background: linear-gradient(135deg, rgba(34,193,195,1) 0%, rgba(253,187,45,1) 100%); border-top-left-radius: 10px; border-top-right-radius: 10px; color: white">
                  <h3 class="h6" style="font-weight: bold; font-size: 15px;"><i class="fa fa-comment mr-3"></i> BILIK KOMENTAR</h3>
                </div>
                <div class="card-body" style="width: 100%;">
                  <form role="form" method="post" id="formBerzakat" class="forms-sample" action="<?php echo site_url('Welcome/prosAddComment');?>" enctype="multipart/form-data">
                    <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" name="nama" id="nama" placeholder="Ketik nama Anda" class="form-control">
                    <input type="hidden" name="idArtikel" id="idArtikel" value="<?php echo $row->idArtikel;?>">
                    </div>
                    <div class="form-group">
                    <label for="Komentar">Komentar Anda</label>
                    <textarea name="komentar" id="Komentar" placeholder="Ketik komentar Anda" class="form-control"></textarea>
                    </div>
                    <input type="submit" name="submit" value="Kirim" class="btn btn-sm btn-success pull-right" style="padding-left: 25px; padding-right: 25px;">
                  </form>
                </div>
              </div>
            </div>
            
    </div>


    
    
  </section><!-- #portfolio -->
<?php } } ?>


</main>

  <!--==========================
    Footer
    ============================-->
    <footer id="footer">
      <div class="footer-top">
        <div class="container">

        </div>
      </div>

      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong>Nida Tour & Travel</strong>. All Rights Reserved
        </div>
        <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Regna
        -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/easing/easing.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/wow/wow.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/waypoints/waypoints.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/superfish/hoverIntent.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/js/main.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
  <script type="text/javascript">
    (function($) {
      var element = $('.follow-scroll'),
      originalY = element.offset().top;

    // Space between element and top of screen (when scrolling)
    var topMargin = 100;
    
    // Should probably be set in CSS; but here just for emphasis
    element.css('position', 'relative');
    
    $(window).on('scroll', function(event) {
      var scrollTop = $(window).scrollTop();

      element.stop(false, false).animate({
        top: scrollTop < originalY
        ? 0
        : scrollTop - originalY + topMargin
      }, 300);
    });
  })(jQuery);
</script>

<script type="text/javascript">
 $(window).on('load',function(){
  document.getElementById("secondSlide").style.display = "none";
});
</script>

<script type="text/javascript">
  $(document).ready(function() {

    //NUMBER FORMAT number_format function in js---------------------------------------
    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }

    $('select').selectpicker();
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    var pivot = 1;

    $('#btnEditNow').on('click', function(){
      if (pivot == 1) {
        document.getElementById("firstSlide").style.display = "none";
        document.getElementById("secondSlide").style.display = "block";
        pivot = 0;
      }else {
        document.getElementById("firstSlide").style.display = "block";
        document.getElementById("secondSlide").style.display = "none";
        pivot = 1;
      }


    });

    $('#btnMinus').on('click', function(){
      var x = document.getElementById("jmlJemaahID").value;
      if (x=='2') {
        document.getElementById("trJemaahTambahan").style.display = "none";
      }
      if (x>1) {
        
        
        var result = x-1;
        $('#jmlJemaahID').val(result);


        var jmlJemaah = 0;
        jmlJemaah = +x-1;
        var hargaTourAwal = $('#hargaHiddenID').val();
        var hrgTour = hargaTourAwal;
        var resultHarga = jmlJemaah*hargaTourAwal;
        document.getElementById("totalHargaID").value = resultHarga;
        document.getElementById("hargaTourText").innerHTML = "Rp "+numberWithCommas(resultHarga)+",-" ;
        
        document.getElementById("ttlJemaahTerpilih").innerHTML = result;

        var ttp =document.getElementById("currJemaahTerpilih").innerHTML;
      var ttx =document.getElementById("ttlJemaahTerpilih").innerHTML;

      if (ttp/ttx == 1) {
        document.getElementById("selectBox").disabled = true;
        document.getElementById("btnSubmit").disabled = false;
      }else {
          document.getElementById("selectBox").disabled = false;
          document.getElementById("btnSubmit").disabled = true;

        }

        


      }
      
    });
    $('#btnPlus').on('click', function(){
      var x = document.getElementById("jmlJemaahID").value;
      var y = document.getElementById("jumlahDataID").value;
      

      if (x <= y) {
        var result = +x+1;
        $('#jmlJemaahID').val(result);

        document.getElementById("ttlJemaahTerpilih").innerHTML = result;
        var ttp =document.getElementById("currJemaahTerpilih").innerHTML;
        var ttx =document.getElementById("ttlJemaahTerpilih").innerHTML;
        document.getElementById("trJemaahTambahan").style.display = "block";

        var jmlJemaah = 0;
        jmlJemaah = +x+1;
        var hargaTourAwal = $('#hargaHiddenID').val();
        var hrgTour = hargaTourAwal;
        var resultHarga = jmlJemaah*hargaTourAwal;
        document.getElementById("totalHargaID").value = resultHarga;
        document.getElementById("hargaTourText").innerHTML = "Rp "+numberWithCommas(resultHarga)+",-" ;
        
        if (ttp/ttx == 1) {
          document.getElementById("selectBox").disabled = true;
          document.getElementById("btnSubmit").disabled = false;
        }else {

          document.getElementById("selectBox").disabled = false;
          document.getElementById("btnSubmit").disabled = true;

        }
      }
      
    

      

    });

    $('#kosongkanPilihan').on('click', function(){
      document.getElementById("currJemaahTerpilih").innerHTML = 1;
      document.getElementById("ttlJemaahTerpilih").innerHTML = 1;
      document.getElementById("selectBox").disabled = false;
      $('#idUserSelectedID').val("");
      $('#jmlJemaahID').val(1);
      document.getElementById("trJemaahTambahan").style.display = "none";
      document.getElementById("btnSubmit").disabled = true;

      var elements = document.getElementById("selectBox").options;


 
      for(var i = 0; i < elements.length; i++){
        if(elements[i].selected)
          elements[i].selected = false;
      }

      
        var hargaTourAwal = $('#hargaHiddenID').val();
        var hrgTour = hargaTourAwal;
        var resultHarga = 1*hargaTourAwal;
        document.getElementById("totalHargaID").value = resultHarga;
        document.getElementById("hargaTourText").innerHTML = "Rp "+numberWithCommas(resultHarga)+",-" ;

    });

    $('#selectBox').on('change', function(){
      var values = $('#selectBox').val();
      $('#idUserSelectedID').val(values);
      var parsing = values.toString().split(',');
      if (parsing.length > 0) {
        document.getElementById("currJemaahTerpilih").innerHTML = parsing.length+1;
      }else {
        document.getElementById("currJemaahTerpilih").innerHTML = 0;
      }

      var ttp =document.getElementById("currJemaahTerpilih").innerHTML;
      var ttx =document.getElementById("ttlJemaahTerpilih").innerHTML;
      if (ttp/ttx == 1) {
        document.getElementById("selectBox").disabled = true;
        document.getElementById("btnSubmit").disabled = false;
      }else {
          document.getElementById("selectBox").disabled = false;
          document.getElementById("btnSubmit").disabled = true;
        }
      
        // document.getElementById("selectBox").disabled;

    });

                $('#btnSubmit').on('click', function(){
                  var idUserTambahan = document.getElementById("idUserSelectedID").value;
                  var kodePaketTour = document.getElementById("kodePaketTour").value;
                  var idPaket = document.getElementById("idPaketHiddenID").value;
                  var hargaSatuanPaket = document.getElementById("hargaHiddenID").value;
                  var hargaTotalPaket = document.getElementById("totalHargaID").value;

                  // document.getElementById("loaderPutHere").innerHTML = "<div class='loading'></div>";

                  jQuery.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>"+"User/prosAddNewPaketRequest",
                        dataType: 'json',
                    //mengirim data dengan type post
                    data: {idUserTambahan: idUserTambahan, kodePaketTour: kodePaketTour, idPaket: idPaket, hargaSatuanPaket:hargaSatuanPaket, hargaTotalPaket:hargaTotalPaket},
                    //menerima result dari controller
                    success: function(data) {
                       if (data.statsupdatenya== "berhasil") {
                        location.href = "<?php echo site_url('Welcome/invoice/');?>"+data.kodePaketTour;
                       }
                    }
                  });
              

                });


  });
</script>

</body>
</html>
