
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Kelola Gudang</title>

  <link href="<?php echo base_url(); ?>/assets/img/icons/logo.png" rel="icon" type="image/png">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/dist/css/adminlte.min.css">
  <style type="text/css">
    .square {
      width: 100%;
      height: 130px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      border-radius: 10px;
      margin-bottom: 15px;
    }
    .square2 {
      width: 60%;
      height: 110px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      margin-bottom: 15px;
    }
  </style>
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to to the body tag
to get the desired effect
|---------------------------------------------------------|
|LAYOUT OPTIONS | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition sidebar-mini">
  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/demo.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/pages/dashboard3.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>


  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="<?php echo site_url('Welcome/index');?>" class="nav-link">Home</a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="#" class="nav-link" data-toggle="modal" id="btnTambahBarang" data-target="#modal-xl">Tambah Barang</a>
        </li>
        
      </ul>

      <!-- SEARCH FORM -->
    <!-- <form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form> -->

    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
          class="fas fa-ellipsis-h"></i></a>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="<?php echo site_url('Welcome/index');?>" class="brand-link">
        <img src="<?php echo base_url(); ?>/assets/img/icons/logo.png" alt="Dabalpro Logo" class="brand-image img-circle elevation-3"
        style="opacity: .8">
        <span class="brand-text font-weight-light"><b>Dabal</b>pro</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="<?php echo base_url(); ?><?php echo $pictureUserGiven;?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block"><?php echo $namaUserGiven;?></a>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->

           <li class="nav-item">
            <a href="<?php echo site_url('Welcome/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          

          <li class="nav-header">TRANSAKSI</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/index');?>" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Transaksi Baru
                
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/history');?>" class="nav-link">
              <i class="nav-icon far fa-file"></i>
              <p>
                Riwayat Transaksi
               
              </p>
            </a>
          </li>
          
          
          
          <li class="nav-header">GUDANG</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/index');?>" class="nav-link active">
              <i class="nav-icon fas fa-boxes"></i>
              <p>Lihat Gudang</p>
            </a>
          </li>

          <li class="nav-header">AKUN</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/akun');?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Kelola Akun</p>
            </a>
          </li>
          <?php
            if ($levelUser=='10') { ?>
            <li class="nav-item">
            <a href="<?php echo site_url('Managements/akunKaryawan');?>" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Kelola Karyawan</p>
            </a>
          </li>

          <?php } ?>
          
          
          <!-- <li class="nav-header">LABEL</li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-danger"></i>
              <p class="text">Penting</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Perhatian</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Informasi</p>
            </a>
          </li> -->

          <li class="nav-item " style="position: fixed; bottom: 0px;width: 235px;">
            <a href="<?php echo site_url('Login/logoutUser');?>" class="nav-link " >
              <i class="nav-icon fas fa-power-off text-danger"></i>
              <p class="text-danger">
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Gudang</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo site_url('Welcome/index');?>">Home</a></li>
              <li class="breadcrumb-item active">Gudang</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-info"><i class="far fa-hourglass"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Jenis Barang</span>
                <span class="info-box-number">56</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-success"><i class="fa fa-align-left"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Total Stok</span>
                <span class="info-box-number">1.405</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-warning"><i class="fa fa-boxes" style="color: #fff;"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Stok Hampir Habis</span>
                <span class="info-box-number">234</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-3 col-sm-6 col-12">
            <div class="info-box">
              <span class="info-box-icon bg-danger"><i class="far fa-heart"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Favorited</span>
                <span class="info-box-number">224</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Daftar barang dalam gudang</h3>
              <div class="float-right">
                <div class="btn-group btn-group-sm">
                          <a href="#" class="btn btn-dark" id="listx"><i class="fas fa-list"></i></a>
                          <a href="#" class="btn btn-secondary" id="gridx"><i class="fas fa-th-large"></i></a>
                        </div>
              </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div id="showtablemode" >
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Nama Barang</th>
                    <th>Merk</th>
                    <th>Tipe</th>
                    <th>Stok</th>
                    <th width="100">Pilihan</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                        $no=0;
                      if(!$listBarang->result()){ ?>
                        <tr><td colspan="8" class="text-center text-muted pb-5">
                          <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                        Tidak ada data untuk saat ini.</td></tr>
                      <?php }else {
                        foreach ($listBarang->result() as $row) {
                          $no++;
                          
                        
                      ?>
                      <tr>
                        <td><?php echo $row->namaKlasifikasi." ".$row->merk;?></td>
                        <td><?php echo $row->merk;?></td>
                        <td><?php echo $row->ukuran;?></td>
                        <td> <?php echo $row->stok;?></td>
                        <td class="text-right py-0 align-middle text-center">
                          <div class="btn-group btn-group-sm">
                            <a href="#" class="btn btn-info" data-toggle="modal" id="btnShowDetailAndEdit" data-target="#modal<?php echo $row->idBarang;?>"><i class="fas fa-eye"></i></a>
                            <a href="#" class="btn btn-danger" data-toggle="modal" id="btnShowDeleteBox" data-target="#modaldelete<?php echo $row->idBarang;?>"><i class="fas fa-trash"></i></a>
                          </div>
                        </td>
                      </tr>

                      <div class="modal fade" id="modal<?php echo $row->idBarang;?>" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog modal-normal">
                          <form id="showForm<?php echo $row->idBarang;?>" action="<?php echo site_url('Managements/editHargaStokBarang');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="idBarang" value="<?php echo $row->idBarang;?>">
                          <div class="modal-content ">
                            <div class="modal-header">
                              <h6 class="modal-title">Detail Barang</h6>
                              <button type="button" class="close" data-dismiss="modal" id="btnCloseModal<?php echo $row->idBarang;?>" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              
                              <div class="row">
                                <div class="col-md-12" style="border-bottom: 1px solid #f2f2f2; padding-top: 5px; padding-bottom: 5px; margin-bottom: 5px;">
                                  <small class="text-muted" style="display: block;">Nama barang</small>
                                  <?php echo $row->namaKlasifikasi." ".$row->merk;?>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-12" style="border-bottom: 1px solid #f2f2f2; padding-top: 5px; padding-bottom: 5px; margin-bottom: 5px;">
                                  <small class="text-muted" style="display: block;">Kategori barang</small>
                                  <?php echo $row->namaKlasifikasi;?>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-12" style="border-bottom: 1px solid #f2f2f2; padding-top: 5px; padding-bottom: 5px; margin-bottom: 5px;">
                                  <small class="text-muted" style="display: block;">Ukuran</small>
                                  <?php echo $row->ukuran;?>
                                  
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-12" style="border-bottom: 1px solid #f2f2f2; padding-top: 5px; padding-bottom: 5px; margin-bottom: 5px;">
                                  <div id="stokBarang<?php echo $row->idBarang;?>">
                                  <small class="text-muted" style="display: block;">Stok</small>
                                    <?php echo $row->stok;?> buah
                                  </div>

                                  <div class="form-group" id="divNewStokBarang<?php echo $row->idBarang;?>">
                                    <label for="inputNewUkuran">Stok baru</label>
                                    <font class="text-sm text-muted" style="float: right;">Stok saat ini : <?php echo $row->stok;?> buah </font>
                                    <input type="number" class="form-control" placeholder="Masukkan stok baru" name="stokedit">
                                  </div>
                                  <div class="float-right" style="margin-top: -10px; font-size: 9px;" id="divEditStok<?php echo $row->idBarang;?>">
                                    <a href="#" class="btn btn-sm btn-light" style="font-size: 10px;" id="editStok<?php echo $row->idBarang;?>"><i class="fas fa-edit"></i></a>
                                  </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-12" style="padding-top: 5px; padding-bottom: 5px; margin-bottom: 15px;">
                                  
                                  <div id="hargaSatuanBarang<?php echo $row->idBarang;?>">
                                    <small class="text-muted" style="display: block;">Harga satuan</small>
                                    <?php echo "Rp " . number_format($row->harga,0,',','.');?>,-
                                  </div>

                                  <div class="form-group" id="divNewHargaBarang<?php echo $row->idBarang;?>">
                                    <label for="inputNewUkuran">Harga baru </label> <font class="text-sm text-muted" style="float: right;">Harga saat ini : <?php echo "Rp " . number_format($row->harga,0,',','.');?>,- </font>
                                    <input type="number" class="form-control" placeholder="Masukkan harga baru" name="hargaedit">
                                  </div>
                                  <div class="float-right" style="margin-top: -10px; font-size: 9px;" id="divEditBarang<?php echo $row->idBarang;?>">
                                    <a href="#" class="btn btn-sm btn-light" style="font-size: 10px;" id="editHarga<?php echo $row->idBarang;?>"><i class="fas fa-edit"></i></a>
                                  </div>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-md-12" style="padding-top: 5px; padding-bottom: 5px; margin-bottom: 5px;">
                                  <div class="square" style="background-image: url(<?php echo base_url(); ?><?php echo $row->pictureBarang;?>); "></div>
                                  <small class="text-center" style="margin: auto; text-align: center;display: block;">Preview image</small>
                                  
                                </div>
                              </div>
                            </div>

                            <div class="modal-footer" id="sideBtnSave<?php echo $row->idBarang;?>">
                              <button type="submit" class="btn btn-success" id="submitBtnEditForm<?php echo $row->idBarang;?>" style="float: right;display: block;"><i class="fas fa-check" style="margin-right: 10px;"></i> Simpan</button>
                            </div>
                    </div>
                    </form>
                    <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                    </div>


                    <div class="modal fade" id="modaldelete<?php echo $row->idBarang;?>" data-keyboard="false" data-backdrop="static">
                        <div class="modal-dialog modal-normal modal-dialog-centered">
                          <form id="showForm<?php echo $row->idBarang;?>" action="<?php echo site_url('Managements/deleteBarang');?>" class="m-t-40" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="idBarangDelete" value="<?php echo $row->idBarang;?>">
                          <div class="modal-content ">
                            
                            <div class="modal-body text-center">
                              <h3>Konfirmasi</h3>
                              Apakah anda yakin ingin menghapus barang ini?
                            </div>

                            <div class="modal-footer" id="sideBtnSave<?php echo $row->idBarang;?>">
                              <button type="submit" class="btn btn-primary" data-dismiss="modal" aria-label="Close"  id="cancelDelete<?php echo $row->idBarang;?>" style="float: left;"><i class="fas fa-times" style="margin-right: 10px;"></i> Batal</button>
                              <button type="submit" class="btn btn-outline-danger" id="confirmDelete<?php echo $row->idBarang;?>" style="float: right;display: block;"><i class="fas fa-check" style="margin-right: 10px;"></i> Ya, Hapus Sekarang</button>
                            </div>
                    </div>
                    </form>
                    <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                    </div>

                      <script type="text/javascript">
                       $(window).on('load',function(){
                        document.getElementById("divNewStokBarang<?php echo $row->idBarang;?>").style.display = "none";
                        document.getElementById("divNewHargaBarang<?php echo $row->idBarang;?>").style.display = "none";
                        document.getElementById("sideBtnSave<?php echo $row->idBarang;?>").style.display = "none";
                        
                      });
                      </script>

                      <script type="text/javascript">
                        $(document).ready(function() {

                          $('#submitBtnEditForm<?php echo $row->idBarang;?>').on('click', function(){

                            document.getElementById("myForm").submit();
                            
                            $("#btnCloseModal<?php echo $row->idBarang;?>").trigger("click");

                          });


                          
                          $('#editHarga<?php echo $row->idBarang;?>').on('click', function(){
                            
                              document.getElementById("divEditBarang<?php echo $row->idBarang;?>").style.display = "none";
                              document.getElementById("hargaSatuanBarang<?php echo $row->idBarang;?>").style.display = "none";
                              document.getElementById("divNewHargaBarang<?php echo $row->idBarang;?>").style.display = "block";
                              document.getElementById("sideBtnSave<?php echo $row->idBarang;?>").style.display = "block";

                          });

                          $('#editStok<?php echo $row->idBarang;?>').on('click', function(){
                            
                              document.getElementById("divEditStok<?php echo $row->idBarang;?>").style.display = "none";
                              document.getElementById("stokBarang<?php echo $row->idBarang;?>").style.display = "none";
                              document.getElementById("divNewStokBarang<?php echo $row->idBarang;?>").style.display = "block";
                              document.getElementById("sideBtnSave<?php echo $row->idBarang;?>").style.display = "block";

                          });

                          $('#btnCloseModal<?php echo $row->idBarang;?>').on('click', function(){
                            
                              document.getElementById("divEditBarang<?php echo $row->idBarang;?>").style.display = "block";
                              document.getElementById("divEditStok<?php echo $row->idBarang;?>").style.display = "block";
                              document.getElementById("hargaSatuanBarang<?php echo $row->idBarang;?>").style.display = "block";
                              document.getElementById("stokBarang<?php echo $row->idBarang;?>").style.display = "block";
                              document.getElementById("divNewHargaBarang<?php echo $row->idBarang;?>").style.display = "none";
                              document.getElementById("divNewStokBarang<?php echo $row->idBarang;?>").style.display = "none";
                              document.getElementById("sideBtnSave<?php echo $row->idBarang;?>").style.display = "none";

                          });

                        });
                    </script>

                    <?php }} ?>
                  
                </tbody>
              </table>
            </div>
            <div id="showgridmode" style="display: none;">
              <input type="text" class="form-control mb-3" id="cariBarangID" placeholder="Ketikkan nama barang...">
              <div class="card card-solid">
                <div class="card-body pb-0">
                  <div class="row d-flex align-items-stretch" id="bagianResultRetrieve">

                    <?php
                        $no=0;
                      if(!$listBarang->result()){ ?>
                        
                          <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;"><br/>
                        
                      <?php }else {
                        foreach ($listBarang->result() as $row) {
                          $no++;
                          
                        
                      ?>

                    <div class="col-12 col-sm-6 col-md-4">
                      <div class="card bg-light">
                        <div class="card-header text-muted border-bottom-0">
                          <?php echo $row->namaKlasifikasi;?>
                        </div>
                        <div class="card-body pt-0">
                          <div class="row">
                            <div class="col-7">
                              <h2 class="lead"><b><?php echo $row->namaKlasifikasi." ".$row->merk;?></b></h2>
                              <p class="text-muted text-sm"><b>Deskripsi: </b> <?php echo $row->deskripsi;?> </p>
                              <ul class="ml-4 mb-0 fa-ul text-muted">
                                <li class="small"><span class="fa-li"><i class="fas fa-lg fa-cubes"></i></span> <?php echo $row->stok;?> buah</li>
                                
                              </ul>
                            </div>
                            <div class="col-5 text-center">
                              
                              <div class="img-circle square2" style="background-image: url(<?php echo base_url(); ?><?php echo $row->pictureBarang;?>); "></div>
                            </div>
                          </div>
                        </div>
                        <div class="card-footer">
                          <div class="float-left text-primary" style="font-weight: bold;">
                            <?php echo "Rp " . number_format($row->harga,0,',','.');?>,-
                          </div>
                          <!-- <div class="text-right">
                            <a href="#" class="btn btn-sm bg-teal" data-toggle="modal" id="btnShowDetailAndEdits" data-target="#modal<?php echo $row->idBarang;?>">
                              <i class="fas fa-cog"></i>
                            </a>
                            <a href="#" class="btn btn-sm btn-primary">
                              <i class="fas fa-user"></i> View Profile
                            </a>
                          </div> -->
                        </div>
                      </div>
                    </div>

                    <?php } } ?>

                  </div>
                </div>
                <!-- /.card-body -->
                <!-- <div class="card-footer">
                  <nav aria-label="Contacts Page Navigation">
                    <ul class="pagination justify-content-center m-0">
                      <li class="page-item active"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">4</a></li>
                      <li class="page-item"><a class="page-link" href="#">5</a></li>
                      <li class="page-item"><a class="page-link" href="#">6</a></li>
                      <li class="page-item"><a class="page-link" href="#">7</a></li>
                      <li class="page-item"><a class="page-link" href="#">8</a></li>
                    </ul>
                  </nav>
                </div> -->
                <!-- /.card-footer -->
              </div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <div class="modal fade" id="modal-xl">
    <div class="modal-dialog modal-xl">
      <form id="example-form" action="<?php echo site_url('Managements/insertNewBarang');?>" class="m-t-40" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Formulir Penambahan Barang</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          
          <div class="row">
            <div class="col-md-6">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Informasi Standar</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-circle"></i></button>
                  </div>
                </div>

                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12">
                     <div class="form-group">
                      <label for="inputNamaBarang">Nama Barang</label>
                      <input type="text" class="form-control" id="inputNamaBarang" placeholder="Masukkan nama barang" name="namaBarangX">
                    </div>
                  </div>
                  <!-- /.col -->
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-8 col-sm-12 col-12">
                        <div class="form-group" id="divSelectKategori">
                          <label for="selectKategoriBarang">Kategori Barang</label>
                          <select class="form-control select2" id="selectKategoriBarang" style="width: 100%;" name="kategoriBarangX">
                            <?php if ($listKlasifikasi->result()) {
                              foreach ($listKlasifikasi->result() as $row) {
                              ?>
                              <option value="<?php echo $row->idKlasifikasi;?>"><?php echo $row->namaKlasifikasi;?></option>
                            <?php } } ?>

                          </select>
                        </div>
                        <div class="form-group" id="divNewInputKategori">
                          <label for="inputNewKategori">Kategori Baru</label>
                          <input type="text" class="form-control" id="inputNewKategori" placeholder="Masukkan kategori baru" name="kategoriBarangY">
                        </div>
                      </div>
                      <div class="col-md-4 col-sm-12 col-12">
                        <label> </label>
                        <button type="button" id="addKategoriBtn" class="btn btn-block btn-default" style="margin-top: 8px;">Kategori Lain</button>
                      </div>
                    </div>
                  </div>
                  <!-- /.col -->
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-8 col-sm-12 col-12">
                        <div class="form-group" id="divSelectMerk">
                          <label for="selectMerkBarang">Merk</label>
                          <select class="form-control select2" id="selectMerkBarang" style="width: 100%;" name="merkBarangX">
                            <?php if ($listMerk->result()) {
                              foreach ($listMerk->result() as $row) {
                              ?>
                              <option value="<?php echo $row->merk;?>"><?php echo $row->merk;?></option>
                            <?php } } ?>

                          </select>
                        </div>
                        <div class="form-group" id="divNewInputMerk">
                          <label for="inputNewMerk">Merk Baru</label>
                          <input type="text" class="form-control" id="inputNewMerk" placeholder="Masukkan merk baru" name="merkBarangY">
                        </div>
                      </div>
                      <div class="col-md-4 col-sm-12 col-12">
                        <label> </label>
                        <button type="button" id="addMerkBtn" class="btn btn-block btn-default" style="margin-top: 8px;">Merk Lain</button>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-8 col-sm-12 col-12">
                        <div class="form-group" id="divSelectUkuran">
                          <label for="selectUkuranBarang">Ukuran</label>
                          <select class="form-control select2" id="selectUkuranBarang" style="width: 100%;" name="ukuranBarangX">
                            <?php if ($listUkuran->result()) {
                              foreach ($listUkuran->result() as $row) {
                              ?>
                              <option value="<?php echo $row->ukuran;?>"><?php echo $row->ukuran;?></option>
                            <?php } } ?>
                          </select>
                        </div>
                        <div class="form-group" id="divNewInputUkuran">
                          <label for="inputNewUkuran">Ukuran Baru</label>
                          <input type="text" class="form-control" id="inputNewUkuran" placeholder="Masukkan ukuran baru" name="ukuranBarangY">
                        </div>
                      </div>
                      <div class="col-md-4 col-sm-12 col-12">
                        <label> </label>
                        <button type="button" id="addUkuranBtn" class="btn btn-block btn-default" style="margin-top: 8px;">Ukuran Lain</button>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-12 col-sm-12 col-12">
                        <div class="form-group">
                          <label for="desk">Deskripsi</label>
                          <textarea name="deskripsiBarangX" class="form-control" id="desk" placeholder="Masukkan deskripsi singkat" style="min-height: 143px;"></textarea>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
                <!-- /.row -->

                <!-- /.row -->
              </div>
              <!-- /.card-body -->

            </div>
          </div>


          <div class="col-md-6">
            <div class="row">
              <div class="col-md-12">
                <div class="card card-success">
                  <div class="card-header">
                    <h3 class="card-title">Gambar Barang</h3>

                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-circle"></i></button>
                    </div>
                  </div>
                  
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-6" style="margin: auto;">
                       <div id="image_preview"><img id="previewing" src="<?php echo base_url(); ?>/assets/img/images.png" width="250" height="154" /></div>
                     </div>
                     <!-- /.col -->
                   </div>
                   <div class="row">
                    <div class="col-md-6" style="margin: auto; margin-top: 15px">
                     <div class="form-group">
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" name="pictureBarangX" class="custom-file-input tripleh" id="exampleInputFile">
                          <label class="custom-file-label" for="exampleInputFile">Cari gambar...</label>
                        </div>

                      </div>
                    </div>
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->

                <!-- /.row -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer text-muted">
                <small>Direkomendasikan mengupload gambar dengan resolusi 250px x 200px (landscape)</small>
              </div>
            </div>
          </div>

          <div class="col-md-12">
            <div class="card card-warning">
              <div class="card-header">
                <h3 class="card-title">Harga & Stok</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-circle"></i></button>
                </div>
              </div>

              <div class="card-body">

                <div class="row">
                  <div class="col-md-12" style="margin: auto;">
                   <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text" style="font-weight: bold; font-size: 13px;">Rp</span>
                    </div>
                    <input type="number" class="form-control" placeholder="Harga satuan" name="hargaBarangX">
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <div class="row">
                <div class="col-md-12" style="margin: auto;">
                 <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text" style="font-weight: bold;"><i class="fas fa-circle"></i></span>
                  </div>
                  <input type="number" class="form-control" placeholder="Stok barang" name="stokBarangX">
                </div>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- /.row -->
          </div>
          <!-- /.card-body -->
          <div class="card-footer text-muted">
            <small>Harap <b>diisi seluruh informasi</b> diatas untuk kelengkapan data pada barang tersebut.</small>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

</div>
<div class="modal-footer justify-content-between">
  <button type="button" class="btn btn-default" data-dismiss="modal">Batal dan tutup jendela</button>
  <button type="submit" class="btn btn-primary" id="btnSubmitForm">Setuju, tambah barang</button>
</div>
</div>
</form>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>


<!-- Main Footer -->
<footer class="main-footer">
  <strong>Copyright &copy; Dabalpro - <?php echo date('Y');?>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0.0
  </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->




<script type="text/javascript">
 $(window).on('load',function(){
  document.getElementById("divNewInputUkuran").style.display = "none";
  document.getElementById("divNewInputMerk").style.display = "none";
  document.getElementById("divNewInputKategori").style.display = "none";
  
 
});
</script>

<!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
          <script type="text/javascript">
              function getUrlVars() {
                  var vars = {};
                  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                      vars[key] = value;
                  });
                  return vars;
              }


                  var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                  if (mytext=='klasifikasiduplicated') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'warning',
                                      title: 'Maaf kategori dengan nama tersebut sudah ada. Silahkan cek kembali.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
                  if (mytext=='success_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil diupdate.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil dihapuskan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='failed_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'danger',
                                      title: 'Maaf isian tidak boleh kosong',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
          </script>


<script type="text/javascript">
    $(document).ready(function() {

            // Function to preview image after validation
              
              $(".tripleh").change(function() {
              var file = this.files[0];
              var imagefile = file.type;
              var match= ["image/jpeg","image/png","image/jpg"];
              if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
              {
              return false;
              }
              else
              {
              var reader = new FileReader();
              reader.onload = imageIsLoaded;
              reader.readAsDataURL(this.files[0]);
              }
              });
              
              function imageIsLoaded(e) {
              $("#file").css("color","green");
              $('#image_preview').css("display", "block");
              $('#previewing').attr('src', e.target.result);
              $('#previewing').attr('width', '250px');
              $('#previewing').attr('height', '154px');
              };

      var kategoriBtnPivot = 1;
      var merkBtnPivot = 1;
      var ukuranBtnPivot = 1;

      $('#gridx').on('click', function(){
          document.getElementById("showgridmode").style.display = "block";
          document.getElementById("showtablemode").style.display = "none";
          $("#listx").attr('class', 'btn btn-secondary');
          $("#gridx").attr('class', 'btn btn-dark');
      });

      $('#listx').on('click', function(){
          document.getElementById("showgridmode").style.display = "none";
          document.getElementById("showtablemode").style.display = "block";
          $("#listx").attr('class', 'btn btn-dark');
          $("#gridx").attr('class', 'btn btn-secondary');
      });

      $('#addKategoriBtn').on('click', function(){
        if (kategoriBtnPivot == 1) {
          document.getElementById("divNewInputKategori").style.display = "block";
          document.getElementById("divSelectKategori").style.display = "none";

           document.getElementById("addKategoriBtn").innerHTML = 'Kembali';
           kategoriBtnPivot = 0;
        }else {
          document.getElementById("divNewInputKategori").style.display = "none";
          document.getElementById("divSelectKategori").style.display = "block";

           document.getElementById("addKategoriBtn").innerHTML = 'Kategori Lain';
           kategoriBtnPivot = 1;
        }
      });

      $('#addMerkBtn').on('click', function(){
        if (merkBtnPivot == 1) {
          document.getElementById("divNewInputMerk").style.display = "block";
          document.getElementById("divSelectMerk").style.display = "none";

           document.getElementById("addMerkBtn").innerHTML = 'Kembali';
           merkBtnPivot = 0;
        }else {
          document.getElementById("divNewInputMerk").style.display = "none";
          document.getElementById("divSelectMerk").style.display = "block";

           document.getElementById("addMerkBtn").innerHTML = 'Merk Lain';
           merkBtnPivot = 1;
        }
      });

      $('#addUkuranBtn').on('click', function(){
        if (ukuranBtnPivot == 1) {
          document.getElementById("divNewInputUkuran").style.display = "block";
          document.getElementById("divSelectUkuran").style.display = "none";

           document.getElementById("addUkuranBtn").innerHTML = 'Kembali';
           ukuranBtnPivot = 0;
        }else {
          document.getElementById("divNewInputUkuran").style.display = "none";
          document.getElementById("divSelectUkuran").style.display = "block";

           document.getElementById("addUkuranBtn").innerHTML = 'Merk Lain';
           ukuranBtnPivot = 1;
        }
      });

                $('#cariBarangID').on('keyup', function(){
                  var pilihannya2 = "";
                  pilihannya2 = $(this).val();
                  jQuery.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>"+"Managements/searchBarangJquery",
                        dataType: 'json',
                    //mengirim data dengan type post
                    data: {namaItemDiketikkan: pilihannya2},
                    //menerima result dari controller
                    success: function(data) {
                        $('#bagianResultRetrieve').html(data);

                        

                        
                       
                    }
                  });
              

                 });

  

    });
</script>

<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    $('[data-mask]').inputmask()

    
  })
</script>

<script type="text/javascript">
  $(document).ready(function () {
    bsCustomFileInput.init();
  });
</script>

          

</body>
</html>
