<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>PT. Nida Utama Sejahtera  Travel Haji & Umrah</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/animate/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link href="<?php echo base_url(); ?>/assets_nidautama/css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: Regna
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
    ======================================================= -->

    <style type="text/css">
      .floating-btn {
        width: 50px;
        height: 50px;
        background: #1cb821;
        text-decoration: none;
        border-radius: 50%;
        color: #ffffff;
        font-size: 40px;
        box-shadow: 0 1px 3px 0 rgba(0,0,0,.2), 0 1px 1px 0 rgba(0,0,0,.14), 0 2px 1px -1px rgba(0,0,0,.12);
        display: flex;
        align-items: center;
        justify-content: center;
        position: fixed;
        right: 50px;
        bottom: 80px;
        transition: background-color 0.25s ease-out, box-shadow 0.25s ease-out;
        border: none;
        cursor: pointer;
        outline: none;
        z-index: 19291919;
        outline: none;
      }
      .floating-btn:hover {
        box-shadow: 0 4px 5px -2px rgba(0,0,0,.2), 0 7px 10px 1px rgba(0,0,0,.14), 0 2px 16px 1px rgba(0,0,0,.12);
        outline: none;
      }


      .floating-btn.clicked {
        background-color: #4169cc;
        outline: none;
      }

      .floating-btn i {
        transition: transform 0.25s cubic-bezier(.4, 0, .2, 1);
        outline: none;
      }

      .floating-btn.clicked i {
        transform: rotate(360deg);
        bottom: 30px;
        outline: none;
      }

      #labelFile{
        color: white;
        height: 30px;
        width: 125px;
        background-color: #f5af09;
        position: absolute;
        margin: auto;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        font-size: 12px;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        font-weight: bold;
        border-radius: 5px;
      }

      #legal{
        margin: 16px auto;
        text-align: center;
        color: #ccc;
        font-size: 10px;
        max-width: 25em;
        line-height: 1.0;
        letter-spacing: .2px;
      }

      #inputFile{
        border: 0 !important;
        margin-bottom: 10px;
      }

      .icon{
        margin-right: 8px;
        opacity: 0.5;
        font-size: 21px;
        z-index: 1950201;
      }

      #iconPhoto{
        margin-right: 8px;
        opacity: 0.7;
        font-size: 18px;
      }

      .form-box {
        margin: 16px auto;
        font-size: 16px;
        border-radius: 9px;
        position: fixed;
        opacity: 0;
        overflow: hidden;
        bottom: 0;
        right: 80px;
        transform: translate(-50%,-50%);
        width: 30px;
        height: 30px;
        background: #fff;
        border: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 5px 10px rgba(0,0,0,0.2);
        box-sizing: border-box;
        background-color: #f5f5f7;
        transition: all .25s ease-in-out;
        z-index: 192929;
        outline: none;
      }

      .form-box.open {
        transform: translate(10px, -70px);
        height: 400px;
        width: 366px;
        opacity: 1;
      }

      .test{
        background-color: #fff;
        padding-top: 25px;
        padding-left: 20px;
        padding-right: 20px;
        padding-bottom: 27px;
        margin-left: 37px;
        margin-right: 37px;
        margin-top: 20px;
        margin-bottom: 20px;
        border-radius: 10px;

      }

      .login-header {
        border-top-left-radius: 9px;
        border-top-right-radius: 9px;
        background: #4169cc;
        padding: 23px;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        color: #fff;
        text-align: center;
        margin-top: 0;
        margin-bottom: 0;
        z-index: 1029291;
      }

      .form-box input{
        padding: 10px 0;
        margin-bottom: 10px;
        font-size: 12px;

      }
      .form-box textarea{
        height: 100px;
        padding: 10px 0;
        margin-bottom: 20px;
      }

      .form-box input,.form-box textarea{
        width: 100%;
        box-shadow: none;
        outline: none;
        box-sizing: border-box;
        border: none;
        cursor: text;
        border-bottom: 1px solid #dcdcdc;
        transition: .3s width ease-in-out;
        margin: none;

      }

      .ehehehe{
        border-bottom: none;
        cursor: pointer;
        background: #4169cc;
        color: #fff;
        margin-bottom: 0;
        padding: 10px;
        border-radius: 10px;
        margin-top: 10px;
        display: block;
        text-align: center;
      }
      .ehehehe a {
        color: #fff;
      }
      .ehehehe a:hover {
        color: #fff;
      }
      

      .form-box form div{
        position: relative;
      }

    

      .active{
        opacity: 0.7 !important;
      }

      .form-box form div .inputLabel{
        position: absolute;
        left: -1px;
        top: 8px;
        pointer-events: none;
        color: #999;
        transition: .2s ease-in-out;
        font-size: 14px;
      }

      .form-box input:focus ~ .inputLabel,
      .form-box textarea:focus ~ .inputLabel,
      .form-box input:valid ~ .inputLabel,
      .form-box textarea:valid ~ .inputLabel{
        top: -12px;
        left: 0;
        color: #4169cc;
        font-size: 10px;
        font-weight: bold;
        transition: .2s ease-in-out;
      }

      .form-box input:focus,
      .form-box textarea:focus,
      .form-box textarea:valid,
      .form-box input:valid{
        width: 100%;
        border-bottom: 2px solid rgb(76, 118, 224);
      }

      .footer{
        margin-bottom: 0;
        min-height: 25px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        width: 100%;
        background: #fff;
        margin-bottom: 0px;
        border-radius: 0 0 6px 6px;
      }

      /*style diatas utk floating button*/





      .square {
        width: 100px;
        height: 100px;
        text-align: center;
        margin: auto;
        background-size: cover;
        background-position: center;
        border-radius: 10px;

      }
      .square2 {
        width: 60%;
        height: 110px;
        padding-bottom: 50%;
        background-size: cover;
        background-position: center;
        float: right;
        margin-bottom: 15px;
      }

      #quote-carousel {
        padding: 0 10px 30px 10px;
        margin-top: 30px;
      }

      #quote-carousel .carousel-control {
        background: none;
        color: #222;
        font-size: 2.3em;
        text-shadow: none;
        margin-top: 30px;
      }

      #quote-carousel .carousel-control.left {
        left: -12px;
      }

      #quote-carousel .carousel-control.right {
        right: -12px !important;
      }

      #quote-carousel .carousel-indicators {
        right: 50%;
        top: auto;
        bottom: 0px;
        margin-right: -19px;
      }

      #quote-carousel .carousel-indicators li {
        background: #c0c0c0;
      }
      #quote-carousel .carousel-indicators .active {
        background: #333333;
      }
      #quote-carousel img {
        width: 250px;
        height: 100px
      }

      .item blockquote {
        border-left: none;
        margin: 0;
      }
      .item blockquote img {
        margin-bottom: 10px;
      }
      .item blockquote p:before {
        content: "\f10d";
        font-family: 'Fontawesome';
        float: left;
        margin-right: 10px;
      }
      @media (min-width: 768px) {
        #quote-carousel {
         margin-bottom: 0;
         padding: 0 40px 30px 40px;
       }
     }

     @media (max-width: 768px) {

      #quote-carousel .carousel-indicators {
       bottom: -20px !important;
     }
     #quote-carousel .carousel-indicators li {
       display: inline-block;
       margin: 0px 5px;
       width: 15px;
       height: 15px;
     }
     #quote-carousel .carousel-indicators li.active {
       margin: 0px 5px;
       width: 20px;
       height: 20px;
     }
   }


   .slider {
    width: 100%;
    height: 430px;
    position: relative;
    overflow: hidden;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-flow: row nowrap;
    -ms-flex-flow: row nowrap;
    flex-flow: row nowrap;
    -webkit-box-align: end;
    -webkit-align-items: flex-end;
    -ms-flex-align: end;
    align-items: flex-end;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
  }

  .slider__nav {
    width: 17px;
    height: 17px;
    margin: 2rem 12px;
    border-radius: 50%;
    z-index: 10;
    outline: 6px solid #53e615;
    outline-offset: -6px;
    box-shadow: 0 0 0 0 #333, 0 0 0 0 rgba(51, 51, 51, 0);
    cursor: pointer;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    -webkit-backface-visibility: hidden;
    padding-bottom: 20px;
    backface-visibility: hidden;
  }

  .slider__nav:checked {
    -webkit-animation: check 0.5s linear forwards;
    animation: check 0.5s linear forwards;
  }

  .slider__nav:checked:nth-of-type(1) ~ .slider__inner {
    -webkit-transform: translateX(0%);
    transform: translateX(0%);
  }

  .slider__nav:checked:nth-of-type(2) ~ .slider__inner {
    -webkit-transform: translateX(-40%);
    transform: translateX(-40%);
  }

  .eachItems {
    position: relative;
    transition: all 0.07s linear 0s;
  }
  .eachItems:hover {
    transform: scale(1.02,1.02);

  }



  .slider__inner {
    position: absolute;
    top: 0;
    left: 0;
    width: 1000px;
    height: 100%;
    -webkit-transition: all 1s ease-out;
    transition: all 1.2s ease-out;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-flow: row nowrap;
    -ms-flex-flow: row nowrap;
    flex-flow: row nowrap;
  }

  .slider__contents {
    width: 100%;
    height: 100%;
    padding: 2rem;
    text-align: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    -webkit-flex-flow: column nowrap;
    -ms-flex-flow: column nowrap;
    flex-flow: column nowrap;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;

  }

  .slider__image { font-size: 2.7rem; }

  .slider__caption {
    font-weight: 700;
    margin: 2rem 0 1rem;
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
    text-transform: uppercase;
  }

  .slider__txt {
    color: #999;
    margin-bottom: 3rem;
    max-width: 300px;
  }

  .slidesXXX {
    width: 100%;
    height: 100%;

    background-repeat:  no-repeat;
    background-size: cover;
    position: relative;
    box-shadow: 3px 10px 13px #1c1c1c ;
    border-radius: 12px;
    min-height: 350px;
    padding: 0px;
    border: none;
    color: white;

  }
  #tetew {
    position: relative;
    -moz-transition : all 0.1s linear 0s;
    -webkit-transition : all 0.1s linear 0s;
    -ms-transition : all 0.1s linear 0s;
    -o-transition : all 0.1s linear 0s;
  }

  #tetew:hover .slidesXXX:before {
    background: rgba(54, 54, 54, 0.5);

  }



  .slidesXXX:before {
    content: "";
    background: rgba(128, 73, 28, 0.2);
    position: absolute;
    bottom: 0;
    top: 0;
    left: 0;
    right: 0;
    border-radius: 12px;
  }



  /* The flip card container - set the width and height to whatever you want. We have added the border property to demonstrate that the flip itself goes out of the box on hover (remove perspective if you don't want the 3D effect */
  .flip-card {
    background-color: transparent;
    perspective: 1000px; /* Remove this if you don't want the 3D effect */
  }

  /* This container is needed to position the front and back side */
  .flip-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    transition: transform 0.5s;
    transform-style: preserve-3d;
  }

  /* Do an horizontal flip when you move the mouse over the flip box container */
  .flip-card:hover .flip-card-inner {
    transform: rotateY(180deg);
  }

  /* Position the front and back side */
  .flip-card-front, .flip-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    backface-visibility: hidden;
  }

  /* Style the front side (fallback if image is missing) */
  .flip-card-front {
    background-color: transparent;
    color: black;
  }

  /* Style the back side */
  .flip-card-back {
    background-color: transparent;
    color: white;
    margin-left: -13px;
    transform: rotateY(180deg);
  }

  .squarePaket {
    width: 100%;
    height: 260px;

    background-size: cover;
    background-position: center;


    display: block;

    text-align: center;


  }

  .box {
    position: relative;
    max-width: 600px;
    width: 90%;
    height: 400px;
    background: #fff;
    box-shadow: 0 0 15px rgba(0,0,0,.1);
  }

  /* common */
  .ribbon {
    width: 150px;
    height: 150px;
    overflow: hidden;
    position: absolute;
  }
  .ribbon::before,
  .ribbon::after {
    position: absolute;
    z-index: 2;
    content: '';
    display: block;
    border: 5px solid #308e2b;
  }
  .ribbon span {
    position: absolute;
    display: block;
    width: 225px;
    padding: 15px 0;
    background-color: #1ce011;
    box-shadow: 0 5px 10px rgba(0,0,0,.1);
    color: #fff;
    font: 700 18px/1 'Lato', sans-serif;
    text-shadow: 0 1px 1px rgba(0,0,0,.2);
    text-transform: uppercase;
    text-align: center;
  }

  .ribbon2::before,
  .ribbon2::after {
    position: absolute;
    z-index: 2;
    content: '';
    display: block;
    border: 5px solid #bf9319;
  }
  .ribbon2 span {
    position: absolute;
    display: block;
    width: 225px;
    padding: 15px 0;
    background-color: #fcba03;
    box-shadow: 0 5px 10px rgba(0,0,0,.1);
    color: #fff;
    font: 700 18px/1 'Lato', sans-serif;
    text-shadow: 0 1px 1px rgba(0,0,0,.2);
    text-transform: uppercase;
    text-align: center;
  }


  /* top left*/
  .ribbon-top-left {
    top: -10px;
    left: -10px;
  }
  .ribbon-top-left::before,
  .ribbon-top-left::after {
    border-top-color: transparent;
    border-left-color: transparent;
  }
  .ribbon-top-left::before {
    top: 0;
    right: 0;
  }
  .ribbon-top-left::after {
    bottom: 0;
    left: 0;
  }
  .ribbon-top-left span {
    right: -25px;
    top: 30px;
    transform: rotate(-45deg);
  }

  /* top right*/
  .ribbon-top-right {
    top: -10px;
    right: -10px;
  }
  .ribbon-top-right::before,
  .ribbon-top-right::after {
    border-top-color: transparent;
    border-right-color: transparent;
  }
  .ribbon-top-right::before {
    top: 0;
    left: 0;
  }
  .ribbon-top-right::after {
    bottom: 0;
    right: 0;
  }
  .ribbon-top-right span {
    left: -25px;
    top: 30px;
    transform: rotate(45deg);
  }

  /* bottom left*/
  .ribbon-bottom-left {
    bottom: -10px;
    left: -10px;
  }
  .ribbon-bottom-left::before,
  .ribbon-bottom-left::after {
    border-bottom-color: transparent;
    border-left-color: transparent;
  }
  .ribbon-bottom-left::before {
    bottom: 0;
    right: 0;
  }
  .ribbon-bottom-left::after {
    top: 0;
    left: 0;
  }
  .ribbon-bottom-left span {
    right: -25px;
    bottom: 30px;
    transform: rotate(225deg);
  }

  /* bottom right*/
  .ribbon-bottom-right {
    bottom: -10px;
    right: -10px;
  }
  .ribbon-bottom-right::before,
  .ribbon-bottom-right::after {
    border-bottom-color: transparent;
    border-right-color: transparent;
  }
  .ribbon-bottom-right::before {
    bottom: 0;
    left: 0;
  }
  .ribbon-bottom-right::after {
    top: 0;
    right: 0;
  }
  .ribbon-bottom-right span {
    left: -25px;
    bottom: 30px;
    transform: rotate(-225deg);
  }

  .modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 10000; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
  }

  /* Modal Content (Image) */
  .modal-content {
    margin: auto;
    display: block;
    width: 80%;
    max-width: 700px;
  }

  /* Caption of Modal Image (Image Text) - Same Width as the Image */
  .caption {
    margin: auto;
    display: block;
    width: 80%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
    height: 150px;
  }

  /* Add Animation - Zoom in the Modal */
  .modal-content, .caption {
    animation-name: zoom;
    animation-duration: 0.6s;
  }

  @keyframes zoom {
    from {transform:scale(0)}
    to {transform:scale(1)}
  }

  /* The Close Button */
  .close {
    position: absolute;
    top: 15px;
    right: 35px;
    color: #f1f1f1;
    font-size: 40px;
    font-weight: bold;
    transition: 0.3s;
  }

  .close:hover,
  .close:focus {
    color: #bbb;
    text-decoration: none;
    cursor: pointer;
  }

  /* 100% Image Width on Smaller Screens */
  @media only screen and (max-width: 700px){
    .modal-content {
      width: 100%;
    }
  }


  @-webkit-keyframes 
  check {  50% {
   outline-color: #fcfcfc;
   box-shadow: 0 0 0 12px #fcfcfc, 0 0 0 36px rgba(51, 51, 51, 0.2);
 }
 100% {
   outline-color: #fcfcfc;
   box-shadow: 0 0 0 0 #fcfcfc, 0 0 0 0 rgba(51, 51, 51, 0);
 }
}

@keyframes 
check {  50% {
 outline-color: #fcfcfc;
 box-shadow: 0 0 0 12px #fcfcfc, 0 0 0 36px rgba(51, 51, 51, 0.2);
}
100% {
 outline-color: #fcfcfc;
 box-shadow: 0 0 0 0 #fcfcfc, 0 0 0 0 rgba(51, 51, 51, 0);
}
}
</style>
</head>

<body>

  <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
        $('#quote-carousel').carousel({
          pause: true,
          interval: 4000,
        });
      });
    </script>

  <!-- div floating button -->

  <div class="form-box " id="myDIV">
    <h2 class="login-header">Ada yang dapat kami bantu?</h2>
      <div class="test">
        <form class="formInput">
          <div>
            <input type="text"  required id="fillComments">
            <label class="inputLabel">Ketik pesan anda disini</label>
          </div>
          
      
      <p id="legal">Anda perlu menggunakan aplikasi Whatsapp web untuk melakukan komunikasi dan berkirim pesan melalui fitur ini.</p>
      <a href="https://api.whatsapp.com/send?phone=51955081075&text=sss" id="submitButt" class="float ehehehe" target="_blank">
        <i class="fa fa-whatsapp my-float"></i> Kirim via Whatsapp
        </a>

    </form>
      </div>
    </div>
    <button class="floating-btn" onclick="myFunction()">
      <i id="iconTag" class="fa fa-comments float-left"></i>
    </button>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
      $('#submitButt').click(function() {
        $(this).toggleClass('active');
        var isi = document.getElementById("fillComments").value;
        var tes = encodeURIComponent(isi);
        $('#submitButt').attr({'href' : 'https://api.whatsapp.com/send?phone=6282376112218&text='+tes});
      });
      $(function() {
        $("#test").focus();
      });
      document.querySelector('.floating-btn').addEventListener('click', function(e) {
        e.target.closest('button').classList.toggle('clicked');
      });

      function myFunction() {
        var x = document.getElementById("myDIV");

        console.log(x);
        console.log(x.classList.contains('open'));
        if (x.classList.contains('open')) {
          $('#iconTag').attr({'class' : 'fa fa-comments float-left'});
          x.classList.remove("open");
        } else {
          $('#iconTag').attr({'class' : 'fa fa-close float-left'});
          x.classList.add("open");
          document.getElementById("test").focus();


        }
      }
    </script>
    <!-- div floating button -->

    


  <!--==========================
  Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#hero" style="color: white;font-weight: bold;">NIDA UTAMA SEJAHTERA</a>
        <!-- Uncomment below if you prefer to use a text logo -->
        <!--<h1><a href="#hero">Regna</a></h1>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#hero">Home</a></li>
          <li><a href="#paket">Paket Tersedia</a></li>
          <li><a href="#about">Tentang Kami</a></li>
          <li><a href="#services">Pelayanan</a></li>
          <li><a href="#portfolio">Galeri Foto</a></li>
          
          <li><a href="#contact">Hubungi Segera</a></li>
          

          <?php if(!$levelUser) { ?>
            <li><a href="<?php echo site_url('login');?>">Login</a></li>
            <li><a href="<?php echo site_url('register');?>">Register</a></li>
          <?php } elseif ($levelUser==10) {

            ?>
            <li class="menu-has-children"><a href=""><?php echo $namaUserGiven;?></a>
              <ul>
                <div class="dropdown-header text-center" style="background-color: #fff;padding-top: 15px; padding-bottom: 20px;">
                  <div class="square img-md rounded-circle" style="background-image: url(<?php echo base_url(); ?><?php
                    if(!$pictureUserGiven){
                      echo '/assets/img/pictprofile/nidautamauser_default.png';
                    }else {echo $pictureUserGiven;};?>); "></div>

                    <p class="mb-1 mt-3"><?php echo $namaUserGiven;?></p>
                    <p class="font-weight-light text-muted mb-0">
                      <?php if ($levelUser==10) { echo 'Administrator';}else { echo 'Normal User';}?>
                    </p>
                  </div>
                  <li> <a href="<?php echo site_url('Managements/index');?>"><i class="fa fa-dashboard mr-2"></i> Dashboard</a></li>
                  <li><a href="#"><i class="fa fa-user mr-2"></i> Profil Saya</a></li>
                  <hr/>
                  <li><a href="#"><i class="fa fa-sign-out mr-2"></i> Logout</a></li>

                </ul>
              </li>
            <?php }elseif ($levelUser==2) { ?>
             <li class="menu-has-children"><a href=""><?php echo $namaUserGiven;?></a>
              <ul>
                <div class="dropdown-header text-center" style="background-color: #fff;padding-top: 15px; padding-bottom: 20px;">
                  <div class="square img-md rounded-circle" style="background-image: url(<?php echo base_url(); ?><?php
                    if(!$pictureUserGiven){
                      echo '/assets/img/pictprofile/nidautamauser_default.png';
                    }else {echo $pictureUserGiven;};?>); "></div>

                    <p class="mb-1 mt-3"><?php echo $namaUserGiven;?></p>
                    <p class="font-weight-light text-muted mb-0">
                      <?php if ($levelUser==10) { echo 'Administrator';}else { echo 'User';}?>
                    </p>
                  </div>
                  <li> <a href="<?php echo site_url('User/index');?>"><i class="fa fa-dashboard mr-2"></i> Dashboard</a></li>
                  <li><a href="<?php echo site_url('User/editProfile');?>"><i class="fa fa-user mr-2"></i> Profil Saya</a></li>
                  <hr/>
                  <li><a href="<?php echo site_url('Login/logoutUser');?>"><i class="fa fa-sign-out mr-2"></i> Logout</a></li>

                </ul>
              </li>
            <?php }?>
          </ul>
        </nav><!-- #nav-menu-container -->
      </div>
    </header><!-- #header -->

  <!--==========================
    Hero Section
    ============================-->
    <section id="hero">
      <div class="row ">
        <div class="col-md-4 hero-container col-md-offset-2">
          <div class="">

             <?php
                      $no=0;
                      if(!$tampilHeadline->result()){ ?>

                        <h1 style="text-align: left;" class="wow fadeInUp" data-wow-delay="0s">SELAMAT DATANG</h1>
                        <h2 style="text-align: left;" class="wow fadeInDown" data-wow-delay="0.2s">Kami siap melayani perjalanan Anda dengan maksimal.</h2>

                      <?php }else {
                        foreach ($tampilHeadline->result() as $row) {
                         
                          ?>

                      <h1 style="text-align: left;" class="wow fadeInUp" data-wow-delay="0s"><?php echo nl2br($row->headline);?></h1>
                      <h2 style="text-align: left;" class="wow fadeInDown" data-wow-delay="0.2s"><?php echo nl2br($row->subheadline);?></h2>

                <?php } } ?>

            <a href="#about" class="btn-get-started" style="text-align: left;">GABUNG SEKARANG</a>
          </div>
        </div>
        <div class="col-md-4 hero-container col-md-offset-6">
          <div class="">

            <object style="border-radius: 10px; border: 3px solid #fff; box-shadow: 3px 3px 20px #000" width="100%" height="350" data="https://www.youtube.com/v/QCNA3GwQ1DM" type="application/x-shockwave-flash"><param name="src" value="https://www.youtube.com/v/QCNA3GwQ1DM" /></object>

            <!-- <div class="slider">
              <input type="radio" name="slider" title="slide1" checked="checked" class="slider__nav"/>
              <input type="radio" name="slider" title="slide2" class="slider__nav"/>
              
              <div class="slider__inner">
                <div class="slider__contents">
                  <div class="col-md-12">
                    <div class="row" >

                      <?php
                      $no=0;
                      if(!$listPaketTour->result()){ ?>



                      <?php }else {
                        $delay = 0.6;
                        $bgRandom=array("/assets_nidautama/img/hero-bg-2.jpg","/assets_nidautama/img/hero-bg.jpg","/assets_nidautama/img/hero-bg-4.jpg");

                        foreach ($listPaketTour->result() as $row) {
                          $k = array_rand($bgRandom);
                          $v = $bgRandom[$k];
                          $delay += 0.2;

                          ?>
                          <div class="col-md-3 flip-card wow fadeInLeft" id="tetew" data-wow-delay="<?php echo $delay;?>s">
                            <div class="card slidesXXX" style="border-radius: 12px; background: url(<?php echo base_url(); ?>.<?php echo $v;?>) center center; background-size: cover;">
                              <div class="card-body text-left flip-card-inner" style="z-index: 16000;">
                                <div class="flip-card-front">
                                  <h1 style="font-size: 20px;line-height: 28px; color: #53e615; text-transform: none; font-weight: 500; margin-top: 0; padding-right: 20px;">
                                   <br/>
                                   <font style="color: #fff; font-size: 20px; font-weight: bold;  text-transform: capitalize;"><?php echo $row->namaPaket;?></font>
                                 </h1>
                                 <h1 style="font-size: 25px;line-height: 28px; color: #fff; text-transform: none; text-align: left; margin-top: 20px; font-weight: normal;">
                                  Hanya <br/>
                                  <font style="color: #53e615; font-size: 35px; letter-spacing: 2px; font-weight: bold;">
                                    <?php echo $row->hargaTour/1000000;?>JT

                                  </font>

                                  <font style="color: #fff; font-size: 12px; font-weight: 800; padding: 3px; border-radius: 3px; background-color: #53e615; margin-top: -5px;"> IDR</font>
                                </h1>
                                <div class="mt-3" style="padding: 4px; padding-left: 10px; background: rgb(59,44,69);
                                background: linear-gradient(201deg, rgba(59,44,69,0.88) 0%, rgba(23,16,6,0.77) 100%);; border-radius: 5px; color: #53e615; width: 90%; background-repeat: no-repeat;">
                                <i class="fa fa-plane float-left mt-4"></i>
                                <p class="" style="margin: 0; line-height: 20px;color:white; margin-left: 20px;">Berangkat pada</p>
                                <b style="color: #fff; margin-left: 8px;"><?php echo $row->tglMulai;?></b>

                              </div>

                              <div class="mt-3" style="padding: 4px; padding-left: 10px; background: rgb(59,44,69);
                              background: linear-gradient(201deg, rgba(59,44,69,0.88) 0%, rgba(23,16,6,0.77) 100%);; border-radius: 5px; color: #53e615; width: 90%; background-repeat: no-repeat;">
                              <i class="fa fa-plane float-left mt-4 text-secondary" style=""></i>
                              <p class="" style="margin: 0; line-height: 20px;color:white; margin-left: 20px;">Kembali pada</p>
                              <b style="color: #fff; margin-left: 8px;"><?php echo $row->tglSelesai;?></b>
                            </div>


                          </div>
                          <div class="flip-card-back" style="padding: 20px;">
                            <h5 style="font-weight: 800">Info Tambahan</h5>
                            <div class="mt-3" style="padding: 4px; background: rgba(54, 54, 54, 0.5); border-radius: 5px; color: #53e615;">
                              <p class="" style="margin: 0; line-height: 20px">Kuota Saat Ini</p>
                              <b><?php echo $row->currentMember;?> / <?php echo $row->maxMember;?></b>
                            </div>
                            <p class="mt-3" style="margin: 0; line-height: 20px">Lama Aktifitas</p>
                            <b><?php echo $row->rentangWaktu;?> hari</b>

                            <div class="mt-3" style="padding: 4px; background: rgba(54, 54, 54, 0.5); border-radius: 5px; color: #53e615;">
                              <p class="" style="margin: 0; line-height: 20px">Rute</p>
                              <b><?php echo $row->tujuanPaket;?></b>
                            </div>


                            <a href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>" class="btn btn-sm btn-success" style="position: absolute;bottom: 20px;left: 60px;">
                              Lihat Paket
                            </a>
                          </div>

                        </div>
                      </div>
                    </div>

                  <?php } } ?>
                  
                  <div class="col-md-3 wow fadeInLeft" id="tetew" data-wow-delay="1.2s">
                    <a href="#paket">
                      <div class="card slidesXXX" style="border-radius: 12px; background-size: cover;">
                        <div class="card-body text-left flip-card-inner" style="z-index: 16000; height: 100%;">
                          <div class="flip-card-front">

                           <h1 style="font-size: 25px;line-height: 28px; color: #000; text-transform: none; text-align: left; margin-top: 130px; font-weight: bold; margin-left: 15px;">
                            Lihat Semua Paket <br/>


                          </h1>


                        </div>

                      </div>
                    </div>
                  </a>
                </div>




              </div>
            </div>
          </div>


        </div>
      </div> -->

    </div>
  </div>



</div>


</section><!-- #hero -->

<main id="main">

    <!--==========================
      About Us Section
      ============================-->
      <section id="facts">
        <div class="container wow fadeIn">
          <div class="section-header">
            <h3 class="section-title">FAKTANYA</h3>
            <p class="section-description">Ada beberapa fakta yang harus Anda ketahui tentang kami</p>
          </div>
          <div class="row counters">

            <div class="col-lg-3 col-6 text-center">
              <span data-toggle="counter-up">
                <?php
                $no=0;
                if(!$countMemberAktif->result()){ ?>

                  0

                <?php }else { ?>

                  <?php echo $countMemberAktif->num_rows(); ?> 

                <?php } ?>
              </span>
              <p>Member Aktif</p>
            </div>

            <div class="col-lg-3 col-6 text-center">
              <span data-toggle="counter-up">

                <?php
                $no=0;
                if(!$countCalonJemaahBerangkat->result()){ ?>

                  0

                <?php }else {

                  foreach ($countCalonJemaahBerangkat->result() as $row) {

                    ?>

                    <?php echo $row->jmlJemaahBerangkat;?>

                  <?php } } ?>

                </span>
                <p>Calon Jemaah Berangkat</p>
              </div>

              <div class="col-lg-3 col-6 text-center">
                <span data-toggle="counter-up">

                  <?php
                  $no=0;
                  if(!$countNextPerjalanan->result()){ ?>

                    0

                  <?php }else {


                    ?>

                    <?php echo $countNextPerjalanan->num_rows();?>

                  <?php }  ?>

                </span>
                <p>Perjalanan Umrah Kedepan</p>
              </div>

              <div class="col-lg-3 col-6 text-center">
                <span data-toggle="counter-up">

                  <?php
                  $no=0;
                  if(!$countTestimony->result()){ ?>

                    0

                  <?php }else {


                    ?>

                    <?php echo $countTestimony->num_rows();?>

                  <?php }  ?>

                </span>
                <p>Member Berikan Penilaian</p>
              </div>

            </div>

          </div>
        </section><!-- #facts -->

        <section id="about">
          <div class="container">
            <div class="row about-container">

              <div class="col-lg-6 content order-lg-1 order-2">
                <h2 class="title">Sepatah kata tentang kami</h2>
                <p>
                  Nida Utama (PT. Nida Utama Sejahtera) atau yang familiar dikenal dengan Nida Tour & Travel merupakan perusahaan swasta nasional yang bergerak di bidang Tour dan Travel. Menjadi Penyelenggara ibadah haji Khusus dan umroh yang terpercaya.  
                </p>

                <div class="icon-box wow fadeInUp">
                  <div class="icon"><i class="fa fa-info"></i></div>
                  <h4 class="title"><a href="">Legal berbadan hukum</a></h4>
                  <p class="description">Dengan memiliki izin umroh No. 435 Tahun 2017<br/>dan izin Kemenag Provinsi Riau 74/2019</p>
                </div>

                <div class="icon-box wow fadeInUp" data-wow-delay="0.2s">
                  <div class="icon"><i class="fa fa-bullseye"></i></div>
                  <h4 class="title"><a href="">Komitmen kami</a></h4>
                  <p class="description">Berkomitmen menjalankan ibadah dengan meneladani Sunnah Nabi Muhammad Shallallahu ‘alaihi wa Sallam.</p>
                </div>

                <div class="icon-box wow fadeInUp" data-wow-delay="0.4s">
                  <div class="icon"><i class="fa fa-bar-chart"></i></div>
                  <h4 class="title"><a href="">Produk jasa</a></h4>
                  <p class="description">Yaitu meliputi program Umroh Reguler, Plus Turki, Plus Aqso, Muqobalah, Wisata Halal & Promo serta program Haji khusus. Juga menyediakan berbagai oleh-oleh Umroh dan lain-lain.</p>
                </div>

              </div>

              <div class="col-lg-6 background order-lg-2 order-1 wow fadeInRight" style="margin-top: 100px;"></div>
            </div>

          </div>
        </section><!-- #about -->

    <!--==========================
      Facts Section
      ============================-->
      <section id="paket" class="wow fadeInUp" style="background-color: #fafafa; padding-top: 100px; padding-bottom: 100px;">
        <div class="container wow fadeIn">
          <div class="section-header">
            <h3 class="section-title">PAKET TOUR TERSEDIA</h3>
            <p class="section-description">Ada beberapa paket menarik yang dapat Anda lihat dan Ambil! Buruan!!!</p>
          </div>
          <div class="row">
            <?php
            $no=0;
            if(!$listPaketTourAll->result()){ ?>



            <?php }else {
              $delay = 0.6;
              $bgRandom=array("/assets_nidautama/img/hero-bg-2.jpg","/assets_nidautama/img/hero-bg.jpg","/assets_nidautama/img/hero-bg-4.jpg");

              foreach ($listPaketTourAll->result() as $row) {
                $k = array_rand($bgRandom);
                $v = $bgRandom[$k];
                $delay += 0.2;

                ?>

                <div class="col-md-3 col-lg-3 col-sm-12 mb-4 wow fadeInUp eachItems" data-wow-delay="<?php echo $delay;?>s">

                  <div class="card" style="border: none;">
                    <?php
                    if ($row->newestItems < 10) { ?>

                      <div class="ribbon ribbon-top-right"><span>BARU</span></div>
                    <?php } ?>
                    <?php
                      if ($row->tglMulaiTour < date("Y-m-d")) {
                      ?>
                      <div class="ribbon ribbon-top-right ribbon2"><span>TELAH USAI</span></div>
                    <?php } ?>
                    <div class="card-header" style="padding: 0">
                      <div class="squarePaket" id="previewing" style="display:block;background-image: url('<?php echo base_url(); ?><?php echo $row->picturePaket;?>')"></div>
                    </div>
                    <div class="card-body">
                      <a href="<?php echo site_url('Welcome/detailPaketTour/'.$row->idPaket.'/'.$row->namaPaket);?>" class="text-secondary">
                        <h4 class="h4" style="font-weight: bold;"><?php echo $row->namaPaket;?></h4>
                      </a>
                      <h6><i class="fa fa-calendar text-success mr-3" style=""></i> <?php echo $row->rentangWaktu;?> Hari Perjalanan</h6>
                      <hr/>
                      <div class="row" style="padding-bottom: 0">
                        <div class="col-2 text-center">

                          <i class="fa fa-plane text-light mr-3" style="z-index: 3; padding: 4px; background-color: grey; border-radius: 50px; color: #fff; padding-left: 5px; padding-right: 5px; transform: rotate(-45deg)"></i>
                          <i class="fa fa-plane text-light mr-3" style="z-index: 3; padding: 4px; margin-top: 20px; background-color: grey;transform: rotate(135deg); border-radius: 50px; color: #fff; padding-left: 5px; padding-right: 5px;"></i>
                          <div style="border-left: 2px dashed grey; height: 20px; position: absolute; left: 25px;z-index: 1;top: 22px;"></div>
                        </div>
                        <div class="col-10">
                          <h5 class="mt-1" style="margin: 0">Berangkat <font class="text-success" style="font-weight: bold;"><?php echo $row->tglMulai;?></font></h5>
                          <small class="text-muted"><i>Bandara Sultan Syarif Kasim II</i></small>
                          <h5 class="mt-3" style="margin: 0">Kembali <font class="text-success" style="font-weight: bold;"><?php echo $row->tglSelesai;?></font></h5>
                          <small class="text-muted"><i>Abdul King Airport</i></small>
                        </div>
                      </div>
                      <hr/>
                      <div class="row" style="padding-bottom: 0">
                        <div class="col-2 text-center">

                          <i class="fa fa-wheelchair text-secondary mr-3" style="z-index: 3; padding: 4px; background-color: #fafafa; border: 1px solid grey; border-radius: 50px; color: grey; padding-left: 5px; padding-right: 5px;"></i>

                        </div>
                        <div class="col-10">
                          <h5 class="mt-1" style="margin: 0">Kursi Tersedia</h5>
                          <font class="text-success" style="font-weight: bold;"><?php echo $row->maxMember-$row->currentMember;?> Kursi</font>

                        </div>
                      </div>
                      <div class="row mt-3" style="padding-bottom: 0">
                        <div class="col-2 text-center">

                          <i class="fa fa-money text-secondary mr-3" style="z-index: 3; padding: 4px; background-color: #fafafa; border: 1px solid grey; border-radius: 50px; color: grey; padding-left: 5px; padding-right: 5px;"></i>

                        </div>
                        <div class="col-10">
                          <h5 class="mt-1" style="margin: 0">Biaya</h5>
                          <font class="text-success" style="font-weight: bold;"><?php echo "Rp " . number_format($row->hargaTour,0,',','.');?>,- / org</font>

                        </div>
                      </div>
                      <hr/>
                      <div class="row" style="padding-bottom: 0">
                        <div class="col-3 col-md-3 col-lg-3 col-sm-3 text-center">
                          <i class="fa fa-cutlery text-secondary mr-3" style="z-index: 3; padding: 5px; background-color: #fafafa; border: 1px solid grey; border-radius: 50px; color: grey; font-size: 20px;" data-toggle="tooltip" data-placement="top" title="Dilengkapi dengan kebutuhan makanan dari Indonesia"></i>
                        </div>
                        <div class="col-3 col-md-3  col-lg-3 col-sm-3 text-center">
                          <i class="fa fa-hotel text-secondary mr-3" style="z-index: 3; padding: 5px; background-color: #fafafa; border: 1px solid grey; border-radius: 50px; color: grey; font-size: 20px;" data-toggle="tooltip" data-placement="top" title="Dapatkan fasilitas penginapan yang berkualitas"></i>
                        </div>
                        <div class="col-3 col-md-3 col-lg-3 col-sm-3 text-center">
                          <i class="fa fa-glide-g text-secondary mr-3" style="z-index: 3; padding: 5px; background-color: #fafafa; border: 1px solid grey; border-radius: 50px; color: grey; font-size: 20px;" data-toggle="tooltip" data-placement="top" title="Mendapatkan fasilitas tour-guide dari Ustadz yang berpengalaman"></i>
                        </div>
                        <div class="col-3 col-md-3 col-lg-3 col-sm-3 text-center">
                          <i class="fa fa-money text-secondary mr-3" style="z-index: 3; padding: 5px; background-color: #fafafa; border: 1px solid grey; border-radius: 50px; color: grey; font-size: 20px;" data-toggle="tooltip" data-placement="top" title="Dapat menghemat uang Anda"></i>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>

              <?php } } ?>

            </div>

          </div>
        </section><!-- #facts -->

    <!--==========================
      Services Section
      ============================-->
      <section id="services">
        <div class="container wow fadeIn">
          <div class="section-header">
            <h3 class="section-title">Yang Kami Berikan</h3>
            <p class="section-description">Berikut adalah yang akan kami berikan bagi para jemaah yang tergabung bersama kami</p>
          </div>
          <div class="row">
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
              <div class="box">
                <div class="icon"><a href=""><i class="fa fa-check"></i></a></div>
                <h4 class="title"><a href="">Legal & Terpercaya</a></h4>
                <p class="description">Travel Nida Utama Sejahtera telah Berizin IZIN UMROH. 435 TAHUN 2017 IZIN KEMENAG PROV RIAU 74/2019 Insyaa Allah dapat dipercaya</p>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
              <div class="box">
                <div class="icon"><a href=""><i class="fa fa-users"></i></a></div>
                <h4 class="title"><a href="">Pembimbing Berpengalaman</a></h4>
                <p class="description">Pelaksanaan Ibadah sesuai dengan Al-Qur'an dan As-Sunnah dibimbing oleh Ustadz yang berpengalaman

                </p>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
              <div class="box">
                <div class="icon"><a href=""><i class="fa fa-heart"></i></a></div>
                <h4 class="title"><a href="">Melayani dengan Hati</a></h4>
                <p class="description">Travel Dengan Pelayanan Maksimal Insyaa Allah dan memanjakan para jamaah Umroh, diantaranya manasik Umroh, air zamzam, dll.

                </p>
              </div>
            </div>

            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
              <div class="box">
                <div class="icon"><a href=""><i class="fa fa-hotel"></i></a></div>
                <h4 class="title"><a href="">Hotel yang Nyaman</a></h4>
                <p class="description">Layanan Hotel Bintang 5 (Lima) di Makkah Layanan Hotel Bintang 3 (Tiga) di Madinah Insyaa Allah

                </p>
              </div>
            </div>
            
            
          </div>

        </div>
      </section><!-- #services -->

    <!--==========================
    Call To Action Section
    ============================-->
    <section id="call-to-action">
      <div class="container wow fadeIn">
        <div class='col-md-offset-2 col-md-8'>

          <div class="carousel slide" data-ride="carousel" id="quote-carousel" style="color: #fff">
            <ol class="carousel-indicators">
              <li data-target="#quote-carousel" data-slide-to="0" style="padding: 5px; margin-left: 5px; margin-right: 5px;" ></li>
              <?php
              $no=0;
              if(!$listTestimoni->result()){ ?>

                <p class="card-description">.</p>                                            

              <?php }else {
                foreach ($listTestimoni->result() as $row) {
                  $no++;

                  ?>
                  <li data-target="#quote-carousel" data-slide-to="<?php echo $no;?>" style="padding: 5px; margin-left: 5px; margin-right: 5px;" ></li>

                <?php } } ?>
              </ol>

              <div class="carousel-inner">
                <div class="item active">
                  <blockquote>
                    <div class="row">
                      <div class="col-sm-3 text-center">
                        <img class="img-circle" src="<?php echo base_url(); ?>/assets_adminuser/images/faces/no-image2.png" style="width: 100px;height:100px;">
                      </div>
                      <div class="col-sm-9">
                        <p>Assalamualaikum warahmatullahi wabarakatuh, terimakasih atas kunjungannya dan kami akan memberikan pelayanan perjalanan terbaik bagi jemaah yang tergabung bersama kami.</p>
                        <small style="color:#fcd000; font-size:14px; text-transform: uppercase; font-weight: bold; font-style:italic">Admin Nida Utama</small>
                      </div>
                    </div>
                  </blockquote>
                </div>

                <?php
                $no=0;
                if(!$listTestimoni->result()){ ?>

                  <p class="card-description">.</p>                                            

                <?php }else {
                  foreach ($listTestimoni->result() as $row) {
                    $no++;

                    ?>
                    <div class="item">
                      <blockquote>
                        <div class="row">
                          <div class="col-sm-3 text-center">
                           <div class="square img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image2.png";}else { echo $row->pictureProfile;}?>');"></div>
                         </div>
                         <div class="col-sm-9">
                          <p><?php echo $row->testimoni;?></p>
                          <small style="color:#fcd000; font-size:14px; text-transform: uppercase; font-weight: bold; font-style:italic"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></small>
                        </div>
                      </div>
                    </blockquote>
                  </div>

                <?php } } ?>


              </div>

            </div>
          </div>

        </div>
      </section><!-- #call-to-action -->

      <section id="blog" style="padding-top: 100px; padding-bottom: 100px;">
        <div class="container wow fadeIn">
          <div class="section-header">
            <h3 class="section-title">Blog & Artikel</h3>
            <p class="section-description">Beberapa informasi yang kami update setiap saat</p>
          </div>
          <div class="row">
            <?php
            $no=0;
            if(!$listArtikel->result()){ ?>



            <?php }else {
              $delay = 0.6;
              $bgRandom=array("/assets_nidautama/img/hero-bg-2.jpg","/assets_nidautama/img/hero-bg.jpg","/assets_nidautama/img/hero-bg-4.jpg");

              foreach ($listArtikel->result() as $row) {
                $k = array_rand($bgRandom);
                $v = $bgRandom[$k];
                $delay += 0.2;
                $jdlUrl = $row->judulArtikel;
                $cleanStr = preg_replace('/[^A-Za-z0-9 ]/', '', $jdlUrl);

                ?>
                <div class="col-lg-3 col-md-6 wow fadeInUp eachItems" data-wow-delay="<?php echo $delay;?>s">


                  <div class="squarePaket" id="previewing" style="display:block;background-image: url('<?php echo base_url(); ?><?php echo $row->pictureArtikel;?>')"></div>
                  <div class="card-body" style="background-color: #fafafa">
                    <h4 class="title"><a href="<?php echo site_url('Welcome/detailArtikel/'.$row->idArtikel.'/'.$cleanStr);?>"><?php echo $row->judulArtikel;?></a></h4>
                    <h6><i class="mr-2 fa fa-user"></i> Administrator </h6>
                    <h6><i class="mr-1 fa fa-calendar"></i> <?php echo $row->tglPublikasi;?><i class="mr-2 ml-4 fa fa-eye text-warning"></i> <a href="<?php echo site_url('Welcome/detailArtikel/'.$row->idArtikel.'/'.$cleanStr.'/#komentar');?>"> <?php echo $row->readCount;?> dibaca</a></h6>
                    <hr>
                    <a href="<?php echo site_url('Welcome/detailArtikel/'.$row->idArtikel.'/'.$cleanStr);?>" class="btn btn-sm btn-secondary m-auto text-center" style="border:2px solid #34c984;margin: auto; display: block; padding: 10px; border-radius: 0; color: #34c984; background-color: transparent;">Selengkapnya</a>
                  </div>


                </div>

              <?php } } ?>

            </div>

          </div>
        </section><!-- #services -->
    <!--==========================
      Portfolio Section
      ============================-->
      <section id="portfolio">
        <div class="container wow fadeInUp">
          <div class="section-header">
            <h3 class="section-title">Galeri Foto</h3>
            <p class="section-description">Beberapa Foto Kami dan Para Jemaah</p>
          </div>
          <div class="row">

            <div class="col-lg-12">
              <ul id="portfolio-flters">
                <li data-filter=".filter-all" class="filter-active">All</li>
                <?php
                $no=0;
                if(!$listGaleri->result()){ ?>

                <?php }else {
                  $delay = 0.6;

                  foreach ($listGaleri->result() as $row) {
                    $delay += 0.2;

                    $stringKategori = str_replace(' ', '_', $row->kategori);

                    ?>

                    <li data-filter=".<?php echo $stringKategori;?>"><?php echo $row->kategori;?></li>

                  <?php } } ?>


                </ul>
              </div>
            </div>

            <div class="row" id="portfolio-wrapper">
              <?php
              $no=0;
              if(!$listGaleri->result()){ ?>
                <div class="col-lg-12 col-md-12 filter-all wow fadeInDown text-center" data-wow-delay="0">
                  <img src="<?php echo base_url(); ?>/assets/img/icons/notfound4.png" width="250" height="250" style="display: block; margin: auto; opacity: 0.2">
                  <font class="text-center">Tidak ada data galeri.</font>
                </div>
              <?php }else {
                $delay = 0.6;

                foreach ($listGaleri->result() as $row) {
                  $delay += 0.2;

                  $stringKategori = str_replace(' ', '_', $row->kategori);

                  ?>

                  <div class="col-lg-3 col-md-6 portfolio-item <?php echo $stringKategori;?> filter-all wow fadeInDown" data-wow-delay="<?php echo $delay;?>s">
                    <a href="#portfolio">
                      <img id="myImg<?php echo $row->idGaleri;?>"  src="<?php echo base_url(); ?><?php if(!$row->item){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->item;}?>" alt="">
                      <div class="details">
                        <h4><?php echo $row->keterangan;?></h4>
                        <span><?php echo $stringKategori;?></span>
                      </div>
                    </a>
                  </div>

                  <div id="myModal<?php echo $row->idGaleri;?>" class="modal">

                    <!-- The Close Button -->
                    <span class="close" id="closeShadow<?php echo $row->idGaleri;?>">&times;</span>

                    <!-- Modal Content (The Image) -->
                    <img class="modal-content" id="img01<?php echo $row->idGaleri;?>">

                    <!-- Modal Caption (Image Text) -->
                    <div id="caption<?php echo $row->idGaleri;?>" class="caption"></div>
                  </div>

                  <script type="text/javascript">
                        // Get the modal
                        var modal = document.getElementById("myModal<?php echo $row->idGaleri;?>");

                        // Get the image and insert it inside the modal - use its "alt" text as a caption
                        var img = document.getElementById("myImg<?php echo $row->idGaleri;?>");
                        var modalImg = document.getElementById("img01<?php echo $row->idGaleri;?>");
                        var captionText = document.getElementById("caption<?php echo $row->idGaleri;?>");
                        img.onclick = function(){
                          modal.style.display = "block";
                          modalImg.src = '<?php echo base_url(); ?><?php if(!$row->item){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->item;}?>';
                          captionText.innerHTML = "<?php echo nl2br($row->keterangan);?><br/><small class='text-muted'>Copyright &copy; nidautama.com</small>";
                        }

                        // Get the <span> element that closes the modal
                        var span = document.getElementById("closeShadow<?php echo $row->idGaleri;?>");

                        // When the user clicks on <span> (x), close the modal
                        span.onclick = function() {
                          modal.style.display = "none";
                        }
                      </script>

                    <?php } } ?>



                  </div>


                </div>
              </section><!-- #portfolio -->

    <!--==========================
      Team Section
      ============================-->
      <!-- <section id="team">
        <div class="container wow fadeInUp">
          <div class="section-header">
            <h3 class="section-title">Team</h3>
            <p class="section-description">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
          </div>
          <div class="row">
            <div class="col-lg-3 col-md-6">
              <div class="member">
                <div class="pic"><img src="<?php echo base_url(); ?>/assets_nidautama/img/team-1.jpg" alt=""></div>
                <h4>Walter White</h4>
                <span>Chief Executive Officer</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="member">
                <div class="pic"><img src="<?php echo base_url(); ?>/assets_nidautama/img/team-2.jpg" alt=""></div>
                <h4>Sarah Jhinson</h4>
                <span>Product Manager</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="member">
                <div class="pic"><img src="<?php echo base_url(); ?>/assets_nidautama/img/team-3.jpg" alt=""></div>
                <h4>William Anderson</h4>
                <span>CTO</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="member">
                <div class="pic"><img src="<?php echo base_url(); ?>/assets_nidautama/img/team-4.jpg" alt=""></div>
                <h4>Amanda Jepson</h4>
                <span>Accountant</span>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section> --><!-- #team -->

    <!--==========================
      Contact Section
      ============================-->
      <section id="contact">
        <div class="container wow fadeInUp">
          <div class="section-header">
            <h3 class="section-title">KONTAK KAMI</h3>
            <p class="section-description">Berikut informasi yang dapat Anda ketahui dan pastikan kami mengetahui pesan, keluhan, dan pengalaman Anda selama bersama kami.</p>
          </div>
        </div>

        <!-- Uncomment below if you wan to use dynamic maps -->
        <iframe src="https://maps.google.com/maps?width=100&amp;height=600&amp;hl=en&amp;coord=0.479089, 101.404782&amp;q=Samping%20SD%20IT%20Ibnu%20Abbas%2C%20Jl.%20Melati%20Indah%20No.C5%2C%20Delima%2C%20Kec.%20Tampan%2C%20Kota%20Pekanbaru%2C%20Riau%2028292+(Nida%20Utama%20Sejahtera)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"" width="100%" height="380" frameborder="0" style="border:0" allowfullscreen></iframe>

        <div class="container wow fadeInUp mt-5">
          <div class="row justify-content-center">

            <div class="col-lg-3 col-md-4">

              <div class="info">
                <div>
                  <i class="fa fa-map-marker"></i>
                  <p>Samping SD IT Ibnu Abbas,<br>Jl. Melati Indah No.C5, Delima, Kec. Tampan,Kota Pekanbaru, Riau, 28292</p>
                  <p><a href="https://goo.gl/maps/kDtzQkp7r8p5p1no9" class="btn btn-warning" target="_blank">Lihat Lokasi</a></p>
                </div>

                <div>
                  <i class="fa fa-envelope"></i>
                  <p style="padding-bottom: 0; margin-bottom: 0">abuabdillah.az@gmail.com <small class="text-muted">or</small></p>
                  <p style="padding-top: 0; margin-top: 0">customers@nidautama.com</p>
                </div>

                <div>
                  <i class="fa fa-phone"></i>
                  <p><a target="_blank" href="https://api.whatsapp.com/send?phone=6282376112218&text=Assalamualaikum warahmatullahi wabarakatuh">+62 823 7611 2218</a></p>
                </div>
              </div>

              <div class="social-links">
                <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
                <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
                <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
              </div>

            </div>

            <!-- <div class="col-lg-5 col-md-8">
              <div class="section-header">
                <h4 class="section-title" style="font-size: 18px;">Kami Siap Menjawab</h4>
                <p class="section-description">Silahkan hubungi kami di whatsapp berikut ini</p>
              </div>
              <div class="row " style="text-align: center; margin-top: -50px;">
                <div class="col-md-4">
                  <img class="img-circle text-center" src="http://www.reactiongifs.com/r/overbite.gif" style="width: 120px;height:120px;margin: 10px;">
                  <font style="text-align: center;">Ridho</font>
                </div>
                <div class="col-md-4">
                  <img class="img-circle text-center" src="<?php echo base_url(); ?>/assets_nidautama/img/portfolio/web1.jpg" style="width: 120px;height:120px;margin: 10px;">
                  <font style="text-align: center;">Renggi</font>
                </div>
                <div class="col-md-4">
                  <img class="img-circle text-center" src="<?php echo base_url(); ?>/assets_nidautama/img/portfolio/logo2.jpg" style="width: 120px;height:120px;margin: 10px;">
                  <font style="text-align: center;">Mochan</font>
                </div>

                
              </div>
              
              
            </div> -->

          </div>

        </div>
      </section><!-- #contact -->

    </main>

  <!--==========================
    Footer
    ============================-->
    <footer id="footer">
      <div class="footer-top">
        <div class="container">

        </div>
      </div>

      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong>Nida Tour & Travel</strong>. All Rights Reserved
        </div>
        <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Regna
        -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top" style="margin-right: 37px"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/easing/easing.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/wow/wow.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/waypoints/waypoints.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/superfish/hoverIntent.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/js/main.js"></script>
  <script type="text/javascript">
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
  </script>
</body>
</html>
