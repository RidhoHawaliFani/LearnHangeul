<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>PT. Nida Utama Sejahtera  Travel Haji & Umrah</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <link href="<?php echo base_url(); ?>/assets_nidautama/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Poppins:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets_nidautama/lib/animate/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link href="<?php echo base_url(); ?>/assets_nidautama/css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />

  <!-- =======================================================
    Theme Name: Regna
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
    ======================================================= -->

    <style type="text/css">
      .floating-btn {
        width: 50px;
        height: 50px;
        background: #1cb821;
        text-decoration: none;
        border-radius: 50%;
        color: #ffffff;
        font-size: 40px;
        box-shadow: 0 1px 3px 0 rgba(0,0,0,.2), 0 1px 1px 0 rgba(0,0,0,.14), 0 2px 1px -1px rgba(0,0,0,.12);
        display: flex;
        align-items: center;
        justify-content: center;
        position: fixed;
        right: 50px;
        bottom: 80px;
        transition: background-color 0.25s ease-out, box-shadow 0.25s ease-out;
        border: none;
        cursor: pointer;
        outline: none;
        z-index: 19291919;
        outline: none;
      }
      .floating-btn:hover {
        box-shadow: 0 4px 5px -2px rgba(0,0,0,.2), 0 7px 10px 1px rgba(0,0,0,.14), 0 2px 16px 1px rgba(0,0,0,.12);
        outline: none;
      }


      .floating-btn.clicked {
        background-color: #4169cc;
        outline: none;
      }

      .floating-btn i {
        transition: transform 0.25s cubic-bezier(.4, 0, .2, 1);
        outline: none;
      }

      .floating-btn.clicked i {
        transform: rotate(360deg);
        bottom: 30px;
        outline: none;
      }

      #labelFile{
        color: white;
        height: 30px;
        width: 125px;
        background-color: #f5af09;
        position: absolute;
        margin: auto;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        font-size: 12px;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        font-weight: bold;
        border-radius: 5px;
      }

      #legal{
        margin: 16px auto;
        text-align: center;
        color: #ccc;
        font-size: 10px;
        max-width: 25em;
        line-height: 1.0;
        letter-spacing: .2px;
      }

      #inputFile{
        border: 0 !important;
        margin-bottom: 10px;
      }

      .icon{
        margin-right: 8px;
        opacity: 0.5;
        font-size: 21px;
        z-index: 1950201;
      }

      #iconPhoto{
        margin-right: 8px;
        opacity: 0.7;
        font-size: 18px;
      }

      .form-box {
        margin: 16px auto;
        font-size: 16px;
        border-radius: 9px;
        position: fixed;
        opacity: 0;
        overflow: hidden;
        bottom: 0;
        right: 80px;
        transform: translate(-50%,-50%);
        width: 30px;
        height: 30px;
        background: #fff;
        border: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 5px 10px rgba(0,0,0,0.2);
        box-sizing: border-box;
        background-color: #f5f5f7;
        transition: all .25s ease-in-out;
        z-index: 192929;
        outline: none;
      }

      .form-box.open {
        transform: translate(10px, -70px);
        height: 400px;
        width: 366px;
        opacity: 1;
      }

      .test{
        background-color: #fff;
        padding-top: 25px;
        padding-left: 20px;
        padding-right: 20px;
        padding-bottom: 27px;
        margin-left: 37px;
        margin-right: 37px;
        margin-top: 20px;
        margin-bottom: 20px;
        border-radius: 10px;

      }

      .login-header {
        border-top-left-radius: 9px;
        border-top-right-radius: 9px;
        background: #4169cc;
        padding: 23px;
        font-size: 16px;
        font-weight: bold;
        text-align: center;
        color: #fff;
        text-align: center;
        margin-top: 0;
        margin-bottom: 0;
        z-index: 1029291;
      }

      .form-box input{
        padding: 10px 0;
        margin-bottom: 10px;
        font-size: 12px;

      }
      .form-box textarea{
        height: 100px;
        padding: 10px 0;
        margin-bottom: 20px;
      }

      .form-box input,.form-box textarea{
        width: 100%;
        box-shadow: none;
        outline: none;
        box-sizing: border-box;
        border: none;
        cursor: text;
        border-bottom: 1px solid #dcdcdc;
        transition: .3s width ease-in-out;
        margin: none;

      }

      .ehehehe{
        border-bottom: none;
        cursor: pointer;
        background: #4169cc;
        color: #fff;
        margin-bottom: 0;
        padding: 10px;
        border-radius: 10px;
        margin-top: 10px;
        display: block;
        text-align: center;
      }
      .ehehehe a {
        color: #fff;
      }
      .ehehehe a:hover {
        color: #fff;
      }
      

      .form-box form div{
        position: relative;
      }

    

      .active{
        opacity: 0.7 !important;
      }

      .form-box form div .inputLabel{
        position: absolute;
        left: -1px;
        top: 8px;
        pointer-events: none;
        color: #999;
        transition: .2s ease-in-out;
        font-size: 14px;
      }

      .form-box input:focus ~ .inputLabel,
      .form-box textarea:focus ~ .inputLabel,
      .form-box input:valid ~ .inputLabel,
      .form-box textarea:valid ~ .inputLabel{
        top: -12px;
        left: 0;
        color: #4169cc;
        font-size: 10px;
        font-weight: bold;
        transition: .2s ease-in-out;
      }

      .form-box input:focus,
      .form-box textarea:focus,
      .form-box textarea:valid,
      .form-box input:valid{
        width: 100%;
        border-bottom: 2px solid rgb(76, 118, 224);
      }

      .footer{
        margin-bottom: 0;
        min-height: 25px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        width: 100%;
        background: #fff;
        margin-bottom: 0px;
        border-radius: 0 0 6px 6px;
      }

      .height {
        min-height: 200px;
      }

      .icon {
        font-size: 47px;
        color: #5CB85C;
      }

      .iconbig {
        font-size: 77px;
        color: #5CB85C;
      }

      .table > tbody > tr > .emptyrow {
        border-top: none;
      }

      .table > thead > tr > .emptyrow {
        border-bottom: none;
      }

      .table > tbody > tr > .highrow {
        border-top: 3px solid;
      }

      .upload-btn-wrapper {
          position: relative;
          overflow: hidden;
          display: inline-block;
        }

        .btnX {
          border: 2px solid grey;
          color: gray;
          background-color: white;
          padding: 8px 20px;
          border-radius: 8px;
          font-size: 20px;
          font-weight: bold;
        }

        .upload-btn-wrapper input[type=file] {
          font-size: 100px;
          position: absolute;
          left: 0;
          top: 0;
          opacity: 0;
        }
        .btnX:hover {
          cursor: pointer;
        }
      /* Animation */

      @-webkit-keyframes spinner {
        0% {
          -webkit-transform: rotate(0deg);
          -moz-transform: rotate(0deg);
          -ms-transform: rotate(0deg);
          -o-transform: rotate(0deg);
          transform: rotate(0deg);
        }
        100% {
          -webkit-transform: rotate(360deg);
          -moz-transform: rotate(360deg);
          -ms-transform: rotate(360deg);
          -o-transform: rotate(360deg);
          transform: rotate(360deg);
        }
      }
      @-moz-keyframes spinner {
        0% {
          -webkit-transform: rotate(0deg);
          -moz-transform: rotate(0deg);
          -ms-transform: rotate(0deg);
          -o-transform: rotate(0deg);
          transform: rotate(0deg);
        }
        100% {
          -webkit-transform: rotate(360deg);
          -moz-transform: rotate(360deg);
          -ms-transform: rotate(360deg);
          -o-transform: rotate(360deg);
          transform: rotate(360deg);
        }
      }
      @-o-keyframes spinner {
        0% {
          -webkit-transform: rotate(0deg);
          -moz-transform: rotate(0deg);
          -ms-transform: rotate(0deg);
          -o-transform: rotate(0deg);
          transform: rotate(0deg);
        }
        100% {
          -webkit-transform: rotate(360deg);
          -moz-transform: rotate(360deg);
          -ms-transform: rotate(360deg);
          -o-transform: rotate(360deg);
          transform: rotate(360deg);
        }
      }
      @keyframes spinner {
        0% {
          -webkit-transform: rotate(0deg);
          -moz-transform: rotate(0deg);
          -ms-transform: rotate(0deg);
          -o-transform: rotate(0deg);
          transform: rotate(0deg);
        }
        100% {
          -webkit-transform: rotate(360deg);
          -moz-transform: rotate(360deg);
          -ms-transform: rotate(360deg);
          -o-transform: rotate(360deg);
          transform: rotate(360deg);
        }
      }




      @-webkit-keyframes 
      check {  50% {
       outline-color: #fcfcfc;
       box-shadow: 0 0 0 12px #fcfcfc, 0 0 0 36px rgba(51, 51, 51, 0.2);
     }
     100% {
       outline-color: #fcfcfc;
       box-shadow: 0 0 0 0 #fcfcfc, 0 0 0 0 rgba(51, 51, 51, 0);
     }
   }

   @keyframes 
   check {  50% {
     outline-color: #fcfcfc;
     box-shadow: 0 0 0 12px #fcfcfc, 0 0 0 36px rgba(51, 51, 51, 0.2);
   }
   100% {
     outline-color: #fcfcfc;
     box-shadow: 0 0 0 0 #fcfcfc, 0 0 0 0 rgba(51, 51, 51, 0);
   }
 }
</style>
</head>

<body>

  <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#quote-carousel').carousel({
        pause: true,
        interval: 4000,
      });
    });
  </script>

  <div class="form-box " id="myDIV">
    <h2 class="login-header">Ada yang dapat kami bantu?</h2>
      <div class="test">
        <form class="formInput">
          <div>
            <input type="text"  required id="fillComments">
            <label class="inputLabel">Ketik pesan anda disini</label>
          </div>
          
      
      <p id="legal">Anda perlu menggunakan aplikasi Whatsapp web untuk melakukan komunikasi dan berkirim pesan melalui fitur ini.</p>
      <a href="https://api.whatsapp.com/send?phone=51955081075&text=sss" id="submitButt" class="float ehehehe" target="_blank">
        <i class="fa fa-whatsapp my-float"></i> Kirim via Whatsapp
        </a>

    </form>
      </div>
    </div>
    <button class="floating-btn" onclick="myFunction()">
      <i id="iconTag" class="fa fa-comments float-left"></i>
    </button>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
      $('#submitButt').click(function() {
        $(this).toggleClass('active');
        var isi = document.getElementById("fillComments").value;
        var tes = encodeURIComponent(isi);
        $('#submitButt').attr({'href' : 'https://api.whatsapp.com/send?phone=6285264397615&text='+tes});
      });
      $(function() {
        $("#test").focus();
      });
      document.querySelector('.floating-btn').addEventListener('click', function(e) {
        e.target.closest('button').classList.toggle('clicked');
      });

      function myFunction() {
        var x = document.getElementById("myDIV");

        console.log(x);
        console.log(x.classList.contains('open'));
        if (x.classList.contains('open')) {
          $('#iconTag').attr({'class' : 'fa fa-comments float-left'});
          x.classList.remove("open");
        } else {
          $('#iconTag').attr({'class' : 'fa fa-close float-left'});
          x.classList.add("open");
          document.getElementById("test").focus();


        }
      }
    </script>

  <style type="text/css">

  </style>
  <!--==========================
  Header
  ============================-->
  <header id="header">
    <div class="container">




    </div>
  </header><!-- #header -->

  <!--==========================
    Hero Section
    ============================-->


    <main id="main">

    <!--==========================
      About Us Section
      ============================-->
      

    <!--==========================
      Facts Section
     

    Call To Action Section
    ============================-->
    <header id="header">
      <div class="container">

        <div id="logo" class="col-md-offset-2">
          <a href="<?php echo site_url('Welcome');?>" style="color: white;font-weight: bold;"><i class="fa fa-arrow-left mr-3"></i> Kembali</a>
          <!-- Uncomment below if you prefer to use a text logo -->
          <!--<h1><a href="#hero">Regna</a></h1>-->
        </div>

        
      </div>
    </header><!-- #header -->

    

    <section id="call-to-action2" >
      <div class="container wow fadeIn text-center">
        <div class="col-md-12" style="z-index: 109; margin: auto;">
          <h1 style="z-index: 99999; font-size:60px; font-weight: 800; color: white; padding-top: 50px; letter-spacing: 3.3px ">INVOICE </h1>
          <h1 class="mt-2 mb-5" style="z-index: 99999; font-size:20px; font-weight: 800; color: white;text-transform: uppercase; letter-spacing: 10px;">#<?php echo $kodePesanan;?> </h1>

        </div>


      </div>
    </section><!-- #call-to-action -->

    <!--==========================
      Portfolio Section
      ============================-->
      <section id="portfolio">
        <div class="container wow fadeInUp" style="margin-top: -150px;">



          <div class="row" id="portfolio-wrapper">
            <div class=" col-md-9" style="margin: auto;">


              <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="panel panel-default height">
                  <div class="panel-heading">Bayar Ke</div>
                  <div class="panel-body">
                    <strong>Tujuan Rekening</strong><font class="pull-right">Mandiri</font> <br>
                    <strong>Nomor Rekening</strong><font class="pull-right">(21)19283</font> <br>
                    <strong>Atas Nama</strong><font class="pull-right">PT. Nida Utama Sejahtera</font> <br>
                    <strong>Tujuan Rekening</strong><font class="pull-right">Mandiri</font> <br>
                    <strong>Pesanan dibuat pada</strong><font class="pull-right"><?php echo $tglPembuatan;?><small class="text-sm text-muted"> <?php echo $jamPembuatan;?> WIB</small></font> <br>

                  </div>
                  <div class="panel-footer">
                    Atau kirim langsung ke kantor kami di <br/>
                    <b>Teluk Kuantan, Kuantan Singingi, 91182, +1928</b>
                  </div>
                </div>
              </div>
              <div class="col-xs-12 col-md-6 col-lg-6" style="padding-right: 0">
                <div class="panel panel-default height">
                  <div class="panel-heading">Status Tagihan</div>
                  <div class="panel-body">
                    <?php if ($statusPembayaran=='Menunggu Pembayaran') {?>
                      <strong>Status Terkini</strong><font class="pull-right text-warning">Menunggu Pembayaran</font>
                    <?php }elseif($statusPembayaran=='Menunggu Konfirmasi'){?>
                      <strong>Status Terkini</strong><font class="pull-right text-secondary">Menunggu Konfirmasi</font>
                    <?php }else { ?>
                      <strong>Status Terkini</strong><font class="pull-right text-success">LUNAS</font>
                    <?php } ?>
                    <br>
                    <strong></strong><font class="pull-right"></font> <br>
                    <strong>Jangka Waktu Sampai</strong><font class="pull-right"><?php echo $getExpiredDate;?> <small>WIB</small>)</font> <br>
                    <strong></strong><font class="pull-right"></font> <br>
                    <strong></strong><font class="pull-right"></font><br/>
                    <strong></strong><font class="pull-right"></font><br/>

                  </div>
                  <div class="panel-footer">

                    <?php
                    if ($getExpiredDate > date("Y-m-d")) {
                    ?>
                      Sisa Waktu <font class="pull-right"><b>kurang dari <?php echo $sisaWaktu;?> hari lagi</b></font>
                    <?php }elseif ($statusPembayaran=='Lunas') {
                     ?>
                      Tagihan telah dibayar lunas
                    <?php }else { ?>
                      Tagihan Kadaluarsa
                    <?php } ?>

                  </div>
                </div>
              </div>


            </div>
          </div>
          <div class="row">
            <div class=" col-md-9" style="margin: auto;">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3 class="text-center mt-4"><strong>Rincian Tagihan</strong></h3>
                  <h6 class="text-center mt-4"><strong>Paket Umroh Murah dan ke Turki</strong></h6>

                </div>
                <div class="panel-body">
                  <div class="table-responsive">

                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <td colspan="3"><strong style="">Daftar Jemaah</strong></td>
                        </tr>
                        <tr>
                          <td colspan=""><strong>No</strong></td>
                          <td colspan=""><strong>Nama Jemaah</strong></td>
                          <td colspan=""><strong>KTP</strong></td>
                          <td colspan=""><strong>Alamat</strong></td>
                        </tr>
                      </thead>   
                      <?php
                        $no=0;
                        if(!$getDataUsers->result()){ ?>



                        <?php }else {
                          $no =0;
                          foreach ($getDataUsers->result() as $row) {
                            $no++;

                            ?>   
                      <tr>
                        <td width="20"><?php echo $no;?></td> 
                        <td width="400"><?php echo $row->namaLengkap;?>
                          <?php if($row->idUserRegistering==0){?>
                            <div class="badge bg-success ml-3" style="font-weight: normal; border-radius: 4px; font-size: 9px; float: right;">Penanggungjawab</div> 
                          <?php } ?>
                        </td>
                        <td class=""><?php echo $row->noKTP;?></td>
                        <td class=""><?php echo $row->alamat;?></td>
                      </tr>

                                 

                      <?php } } ?>
                    </table>
                  </div>
                </div>
                <div class="panel-footer" style="padding-bottom: 35px;">
                  Jumlah Tagihan <font class="pull-right" style="font-size: 20px; font-weight: bold;"><?php echo "Rp " . number_format($totalHarga,0,',','.');?>,-</font>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class=" col-md-9" style="margin: auto;">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3 class="mt-4" style="font-size: 15px;font-weight: normal; text-align: left;">Ketentuan & Penjelasan Pembayaran</h3>

                </div>
                <div class="panel-body">
                  <div class="table-responsive">
                    <ol>
                      <li>Harap melakukan pembayaran sebelum tanggal 23 January 2020, pesanan akan otomatis dibatalkan apabila pembayaran melampaui batas waktu yang telah ditentukan.</li>
                      <li>Pembayaran dapat dilakukan melalui transfer ke Bank Mandiri, informasi lengkap alamat pengiriman juga dapat dilihat pada panel diatas.</li>
                      <li>Apabila telah melakukan pembayaran, harap melakukan konfirmasi melalui sistem atau dapat langsung menghubungi Call Center kami di +62 8172 2771 1728.</li>
                      <li style="font-weight: bold;">Hati hati atas segala macam bentuk penipuan.</li>
                    </ol>

                  </div>
                </div>
                
              </div>
            </div>
          </div>

        

        </section><!-- #portfolio -->

      </main>

                                
  <!--==========================
    Footer
    ============================-->
    <footer id="footer">
      <div class="footer-top">
        <div class="container">

        </div>
      </div>

      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong>Nida Tour & Travel</strong>. All Rights Reserved
        </div>
        <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Regna
        -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top" style="margin-right: 37px"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/easing/easing.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/wow/wow.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/waypoints/waypoints.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/superfish/hoverIntent.js"></script>
  <script src="<?php echo base_url(); ?>/assets_nidautama/lib/superfish/superfish.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url(); ?>/assets_nidautama/js/main.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
  <script type="text/javascript">
    (function($) {
      var element = $('.follow-scroll'),
      originalY = element.offset().top;

    // Space between element and top of screen (when scrolling)
    var topMargin = 100;
    
    // Should probably be set in CSS; but here just for emphasis
    element.css('position', 'relative');
    
    $(window).on('scroll', function(event) {
      var scrollTop = $(window).scrollTop();

      element.stop(false, false).animate({
        top: scrollTop < originalY
        ? 0
        : scrollTop - originalY + topMargin
      }, 300);
    });
  })(jQuery);
</script>

<script type="text/javascript">
 $(window).on('load',function(){
  document.getElementById("firstSlide").style.display = "none";
});
</script>

<script type="text/javascript">
  $(document).ready(function() {

    //NUMBER FORMAT number_format function in js---------------------------------------
    function numberWithCommas(x) {
      return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }

    $('select').selectpicker();
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })

    var pivot = 1;

    $('#btnEditNow').on('click', function(){
      if (pivot == 1) {
        document.getElementById("firstSlide").style.display = "none";
        document.getElementById("secondSlide").style.display = "block";
        pivot = 0;
      }else {
        document.getElementById("firstSlide").style.display = "block";
        document.getElementById("secondSlide").style.display = "none";
        pivot = 1;
      }


    });

    $('#btnMinus').on('click', function(){
      var x = document.getElementById("jmlJemaahID").value;
      if (x=='2') {
        document.getElementById("trJemaahTambahan").style.display = "none";
      }
      if (x>1) {


        var result = x-1;
        $('#jmlJemaahID').val(result);


        var jmlJemaah = 0;
        jmlJemaah = +x-1;
        var hargaTourAwal = $('#hargaHiddenID').val();
        var hrgTour = hargaTourAwal;
        var resultHarga = jmlJemaah*hargaTourAwal;
        document.getElementById("totalHargaID").value = resultHarga;
        document.getElementById("hargaTourText").innerHTML = "Rp "+numberWithCommas(resultHarga)+",-" ;
        
        document.getElementById("ttlJemaahTerpilih").innerHTML = result;

        var ttp =document.getElementById("currJemaahTerpilih").innerHTML;
        var ttx =document.getElementById("ttlJemaahTerpilih").innerHTML;

        if (ttp/ttx == 1) {
          document.getElementById("selectBox").disabled = true;
          document.getElementById("btnSubmit").disabled = false;
        }else {
          document.getElementById("selectBox").disabled = false;
          document.getElementById("btnSubmit").disabled = true;

        }

        


      }
      
    });
    $('#btnPlus').on('click', function(){
      var x = document.getElementById("jmlJemaahID").value;
      var y = document.getElementById("jumlahDataID").value;
      

      if (x <= y) {
        var result = +x+1;
        $('#jmlJemaahID').val(result);

        document.getElementById("ttlJemaahTerpilih").innerHTML = result;
        var ttp =document.getElementById("currJemaahTerpilih").innerHTML;
        var ttx =document.getElementById("ttlJemaahTerpilih").innerHTML;
        document.getElementById("trJemaahTambahan").style.display = "block";

        var jmlJemaah = 0;
        jmlJemaah = +x+1;
        var hargaTourAwal = $('#hargaHiddenID').val();
        var hrgTour = hargaTourAwal;
        var resultHarga = jmlJemaah*hargaTourAwal;
        document.getElementById("totalHargaID").value = resultHarga;
        document.getElementById("hargaTourText").innerHTML = "Rp "+numberWithCommas(resultHarga)+",-" ;
        
        if (ttp/ttx == 1) {
          document.getElementById("selectBox").disabled = true;
          document.getElementById("btnSubmit").disabled = false;
        }else {

          document.getElementById("selectBox").disabled = false;
          document.getElementById("btnSubmit").disabled = true;

        }
      }
      


      

    });

    $('#kosongkanPilihan').on('click', function(){
      document.getElementById("currJemaahTerpilih").innerHTML = 1;
      document.getElementById("ttlJemaahTerpilih").innerHTML = 1;
      document.getElementById("selectBox").disabled = false;
      $('#idUserSelectedID').val("");
      $('#jmlJemaahID').val(1);
      document.getElementById("trJemaahTambahan").style.display = "none";
      document.getElementById("btnSubmit").disabled = true;

      var elements = document.getElementById("selectBox").options;



      for(var i = 0; i < elements.length; i++){
        if(elements[i].selected)
          elements[i].selected = false;
      }

      
      var hargaTourAwal = $('#hargaHiddenID').val();
      var hrgTour = hargaTourAwal;
      var resultHarga = 1*hargaTourAwal;
      document.getElementById("totalHargaID").value = resultHarga;
      document.getElementById("hargaTourText").innerHTML = "Rp "+numberWithCommas(resultHarga)+",-" ;

    });

    $('#selectBox').on('change', function(){
      var values = $('#selectBox').val();
      $('#idUserSelectedID').val(values);
      var parsing = values.toString().split(',');
      if (parsing.length > 0) {
        document.getElementById("currJemaahTerpilih").innerHTML = parsing.length+1;
      }else {
        document.getElementById("currJemaahTerpilih").innerHTML = 0;
      }

      var ttp =document.getElementById("currJemaahTerpilih").innerHTML;
      var ttx =document.getElementById("ttlJemaahTerpilih").innerHTML;
      if (ttp/ttx == 1) {
        document.getElementById("selectBox").disabled = true;
        document.getElementById("btnSubmit").disabled = false;
      }else {
        document.getElementById("selectBox").disabled = false;
        document.getElementById("btnSubmit").disabled = true;
      }
      
        // document.getElementById("selectBox").disabled;

      });

    $('#btnSubmit').on('click', function(){
      var idUserTambahan = document.getElementById("idUserSelectedID").value;
      var kodePaketTour = document.getElementById("kodePaketTour").value;
      var idPaket = document.getElementById("idPaketHiddenID").value;
      var hargaSatuanPaket = document.getElementById("hargaHiddenID").value;
      var hargaTotalPaket = document.getElementById("totalHargaID").value;

                  // document.getElementById("loaderPutHere").innerHTML = "<div class='loading'></div>";

                  jQuery.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>"+"User/prosAddNewPaketRequest",
                    dataType: 'json',
                    //mengirim data dengan type post
                    data: {idUserTambahan: idUserTambahan, kodePaketTour: kodePaketTour, idPaket: idPaket, hargaSatuanPaket:hargaSatuanPaket, hargaTotalPaket:hargaTotalPaket},
                    //menerima result dari controller
                    success: function(data) {
                     if (data.statsupdatenya== "berhasil") {
                      location.href = "<?php echo site_url('Welcome/invoice/');?>"+data.kodePaketTour;
                    }
                  }
                });


                });


  });
</script>

</body>
</html>
