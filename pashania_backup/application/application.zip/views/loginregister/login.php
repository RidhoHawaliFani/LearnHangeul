<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman Login</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_login/fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_login/css/style.css">
</head>
<body style="background-image: url(<?php echo base_url(); ?>/assets_nidautama/img/bg_login.jpg); background-position: center; padding: 0; margin: 0; background-repeat: repeat;">

    <div class="main" style="background: rgb(255,255,255);
background: linear-gradient(0deg, rgba(255,255,255,0) 0%, rgba(171,171,171,0.7) 66%, rgba(129,129,129,0.7) 100%);">


        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="<?php echo base_url(); ?>/assets_login/images/haj2.jpg" alt="sing up image" style="border-radius: 25px;"></figure>
                        <a href="<?php echo site_url('register');?>" class="signup-image-link">Buat akun baru</a>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title" style="line-height: 40px;">Login
                          <font style="font-size: 12px; font-weight: normal; display: block;line-height: 16px;">Silahkan masuk menggunakan akun Anda.</font>
                        </h2>
                        
                        
                          <form action="<?php echo site_url('Login/selectLogin');?>" method="post" class="register-form" id="login-form">
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="username" id="your_name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="your_pass" placeholder="Password"/>
                            </div>
                            <!-- <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div> -->
                            <div class="form-group form-button">
                                <input type="submit" name="signin" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>
                        <div class="text-center p-t-100" style="margin-top: 20px; ">
                                  <?php 
                                  if (!empty($greet)) { 
                                      if ($greet != "a") {?>
                                          <div class="alert alert-success" style="text-align: center; font-size: 10px; margin-left: 20px; margin-right: 20px; color: green">
                                              <strong>Selamat! </strong><?php echo $greet; ?>
                                          </div>
                                      <?php
                                      }
                                      ?>
                                  <?php
                                  }?>
                                  <?php 
                                      if (!empty($this->session->flashdata('gagalmasuk'))) {?>
                                          <div class="alert alert-danger" style="text-align: center; font-size: 10px; margin-left: 20px; margin-right: 20px; color: red">
                                              <strong>Oops! </strong><?php echo $this->session->flashdata('gagalmasuk');?>
                                          </div>
                                  <?php
                                      }
                                  ?>

                        </div>

                        <div class="social-login">
                            <span class="social-label">Lupa password? Klik <a href="<?php echo site_url('forgot');?>" class="signup-image-link" style="display: inline;">disini</a></span>
                            
                        </div>

                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="<?php echo base_url(); ?>/assets_login/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets_login/js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>