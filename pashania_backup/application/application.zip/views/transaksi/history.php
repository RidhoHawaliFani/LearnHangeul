
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Semua Riwayat Transaksi</title>

  <link href="<?php echo base_url(); ?>/assets/img/icons/logo.png" rel="icon" type="image/png">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/dist/css/adminlte.min.css">
  <style type="text/css">
        /*
         *  STYLE 3
         */
.item-show-up {
          box-shadow: 0px;
          border-radius: 0px;
          background: rgba(255,31,31,1);
background: -moz-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -webkit-gradient(left bottom, right top, color-stop(0%, rgba(255,31,31,1)), color-stop(100%, rgba(227,200,102,1)));
background: -webkit-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -o-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -ms-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff1f1f', endColorstr='#e3c866', GradientType=1 );
          -moz-transition: all 0.2s linear 0s;
          -webkit-transition: all 0.2s linear 0s;
          -o-transition: all 0.2s linear 0s;
          -ms-transition: all 0.2s linear 0s;
          color: #fff;
          
        }
        .item-show-up:hover {
          transform: scale(1.03,1.03);
          box-shadow: 0px 12px 12px #bfbfbf;

        }
        #style-3::-webkit-scrollbar-track
        {
          -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar
        {
          width: 6px;
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar-thumb
        {
          background-color: #000000;
          border-radius: 3px;
        }

        .boxing {
          position: relative;
          -webkit-transition:all 0.1s linear 0s;
          -moz-transition:all 0.1s linear 0s;
          -o-transition:all 0.1s linear 0s;
        }
        .boxing:hover {
          -webkit-transform: translateY(-5px);
          -moz-transform: translateY(-5px);
          -o-transform: translateY(-5px);
          z-index:100;
        }


    .square {
      width: 100%;
      height: 130px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      border-radius: 10px;
      margin-bottom: 15px;
    }
    .square2 {
      width: 60%;
      height: 110px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      margin-bottom: 15px;
    }

    /* input number stylish */
       input[type=number] {
          float: left;
          width: 70px;
          height: 35px;
          padding: 0;
          font-size: 1.2em;
          text-transform: uppercase;
          text-align: center;
          color: #93504C;
          border: 2px #93504C solid;
          background: none;
          outline: none;
          pointer-events: none;
        }

        span.spinner {
          position: absolute;
          height: 40px;
          user-select: none;
          -ms-user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -webkit-touch-callout: none;
        }

        span.spinner > .sub,
        span.spinner > .add {
          float: left;
          display: block;
          width: 35px;
          height: 35px;
          text-align: center;
          font-family: Lato;
          font-weight: 700;
          font-size: 1.2em;
          line-height: 33px;
          color: #93504C;
          border: 2px #93504C solid;
          border-right: 0;
          border-radius: 2px 0 0 2px;
          cursor: pointer;
          transition: 0.1s linear;
          -o-transition: 0.1s linear;
          -ms-transition: 0.1s linear;
          -moz-transition: 0.1s linear;
          -webkit-transition: 0.1s linear;
        }

        span.spinner > .add {
          top: 0;
          border: 2px #93504C solid;
          border-left: 0;
          border-radius: 0 2px 2px 0;
        }

        span.spinner > .sub:hover,
        span.spinner > .add:hover {
          background: #93504C;
          color: #25323B;
        }
         input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
         -webkit-appearance: none;
        }
        .selecteds {
          background-color: #999;
        }

   
  </style>
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to to the body tag
to get the desired effect
|---------------------------------------------------------|
|LAYOUT OPTIONS | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/demo.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/pages/dashboard3.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

<script>
  $(document).on('click', '.number-spinner span', function () {    
    var btn = $(this),
      oldValue = btn.closest('.number-spinner').find('input').val().trim(),
      newVal = 0;

      btn.closest('.number-spinner').find('input').focus();
    
    if (btn.attr('data-dir') == 'up') {
      newVal = parseInt(oldValue) + 1;
      btn.closest('.number-spinner').find('input').val(newVal);
      btn.closest('.number-spinner').find('input').trigger("change");
    } else {
      if (oldValue > 1) {
        newVal = parseInt(oldValue) - 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      } else {
        newVal = 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      }
    }
    btn.closest('.number-spinner').find('input').val(newVal);
    btn.closest('.number-spinner').find('input').trigger("change");
  });
  </script>

  


  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-black  navbar-dark">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="<?php echo site_url('Welcome/index');?>" class="nav-link">Home</a>
        </li>
      
      </ul>

    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
          class="fas fa-ellipsis-h"></i></a>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="<?php echo site_url('Welcome/index');?>" class="brand-link">
        <img src="<?php echo base_url(); ?>/assets/img/icons/logo.png" alt="Dabalpro Logo" class="brand-image img-circle elevation-3"
        style="opacity: .8">
        <span class="brand-text font-weight-light"><b>Dabal</b>pro</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="<?php echo base_url(); ?><?php echo $pictureUserGiven;?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block"><?php echo $namaUserGiven;?></a>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->

           <li class="nav-item">
            <a href="<?php echo site_url('Welcome/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          

          <li class="nav-header">TRANSAKSI</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/index');?>" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Transaksi Baru
                
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/history');?>" class="nav-link active">
              <i class="nav-icon far fa-file"></i>
              <p>
                Riwayat Transaksi
                
              </p>
            </a>
          </li>
          
          
          
          <li class="nav-header">GUDANG</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/index');?>" class="nav-link">
              <i class="nav-icon fas fa-boxes"></i>
              <p>Lihat Gudang</p>
            </a>
          </li>
          
          <li class="nav-header">AKUN</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/akun');?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Kelola Akun</p>
            </a>
          </li>
          <?php
            if ($levelUser=='10') { ?>
            <li class="nav-item">
            <a href="<?php echo site_url('Managements/akunKaryawan');?>" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Kelola Karyawan</p>
            </a>
          </li>

          <?php } ?>
          <!-- <li class="nav-header">LABEL</li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-danger"></i>
              <p class="text">Penting</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Perhatian</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Informasi</p>
            </a>
          </li> -->

          <li class="nav-item " style="position: fixed; bottom: 0px;width: 235px;">
            <a href="<?php echo site_url('Login/logoutUser');?>" class="nav-link " >
              <i class="nav-icon fas fa-power-off text-danger"></i>
              <p class="text-danger">
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        
        <!-- /.row -->

        <div class="col-lg-12 col-md-12">
            
            <div class="row">
                    

                    <div class="col-md-12 col-sm-12">
                        <div class="card" style="border-top-left-radius: 0px; border-top-right-radius: 0px;">
                          <div class="card-header card-header-danger card-header-icon">
                            <div class="card-icon float-left mr-3">
                              <i class="fas fa-history"></i>
                            </div>
                            
                            <h3 class="card-title" style="margin-top: 2px;">Riwayat Transaksi</h3>
                            
                          </div>
                          <div class="card-body">
                            <div class="row">
                              <div class="col-md-12">
                                <div class="row">
                                  <div class="card-body">
                                    <!----- isi body open------>
                                      <div class="tab-pane" id="timeline">
                                        <!-- The timeline -->
                                        <div class="timeline timeline-inverse">

                                          <?php
                                            $no=0;
                                          if(!$listTimeTransaction->result()){ ?>
                                            
                                              <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                Tidak ada data untuk saat ini.
                                          <?php }else {
                                            foreach ($listTimeTransaction->result() as $row) {
                                             
                                          ?>

                                          <!-- timeline time label -->
                                          <div class="time-label">
                                            <span class="bg-danger">
                                                  <?php
                                                    $date=date_create($row->timeTransaction);
                                                    echo date_format($date,"d M, Y");
                                                  ?>
                                            </span>
                                          </div>

                                          <div>
                                            <i class="fas fa-check"></i>

                                            <div class="timeline-item" style="background: transparent; border: none;">
                                              <h3 class="timeline-header border-0">Total pemasukan : <b><?php echo "Rp " . number_format($row->ttlHargaAll,0,',','.');?>,-</b>
                                              </h3>
                                            </div>
                                          </div>
                                          <!-- /.timeline-label -->
                                          <!-- timeline item -->
                                          <div>
                                            
                                           
                                              <div class="timeline-item" style="background: transparent; border: none;">
                                              
                                                  
                                                  <div class="timeline-body">
                                                    <div class="row">
                                                      <?php
                                                          $no=0;
                                                        if(!$listCodeTransaction->result()){ ?>
                                                          
                                                            <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                              Tidak ada data untuk saat ini.
                                                        <?php }else {
                                                          foreach ($listCodeTransaction->result() as $row2) {
                                                            if ($row2->tglTrans==$row->tglTrans) {

                                                            
                                                        ?>
                                                        <div class="col-md-3">
                                                          <div class="card">
                                                            <div class="card-header card-header-danger card-header-icon">
                                                              <div class="float-left" style="font-size: 12px;">
                                                                ID Transaksi : <b><?php echo $row2->codeTransaction;?></b>
                                                              </div>
                                                              <small class="float-right">
                                                              <div class="card-icon float-left mr-2">
                                                                <i class="fas fa-clock"></i>
                                                              </div>
                                                              
                                                              <h3 class="card-title" style="margin-top: 2px; font-size: 12px">
                                                                <?php
                                                                  $date2=date_create($row2->timeTransaction);
                                                                  echo date_format($date2,"H:i")." WIB";
                                                                ?>
                                                              </h3>
                                                              </small>
                                                            </div>
                                                            <div class="card-body">
                                                              <?php
                                                                
                                                              if(!$listItemTransaction->result()){ ?>
                                                                
                                                                  <img alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound2.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                                                    Tidak ada data untuk saat ini.
                                                              <?php }else {
                                                                foreach ($listItemTransaction->result() as $row3) {
                                                                  if ($row3->codeTransaction==$row2->codeTransaction) {
                                                                  ?>
                                                                  <div class="d-flex justify-content-between align-items-center border-bottom mb-3">
                                                                  <p class="float-left text-sm">
                                                                    <?php echo $row3->namaKlasifikasi.' '.$row3->merk.'<br/><small class="text-muted">ukuran : '.$row3->ukuran."</small>";?>
                                                                  </p>
                                                                  <p class="float-right text-sm">
                                                                    <?php echo $row3->jumlahPesanan;?> buah
                                                                  </p>
                                                                </div>
                                                              <?php } } }?>

                                                              <button type="button" class="btn btn-sm btn-outline-secondary float-left" style="border-color: #9f9f9f; font-size: 10px;" data-toggle="modal" data-target="#exampleModal<?php echo $row2->codeTransaction;?>"><i class="fas fa-trash"  style="border-color: #9f9f9f;"></i></button>

                                                              <small class="float-right">Total : <?php echo "Rp " . number_format($row2->ttlEachCodeTransaction,0,',','.');?>,-</small>



                                                              <div class="modal fade" id="exampleModal<?php echo $row2->codeTransaction;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                                                                <div class="modal-dialog" role="document">
                                                                  <div class="modal-content">
                                                                    
                                                                    <div class="modal-body text-center">
                                                                      <h2>Konfirmasi</h2>
                                                                      Apakah anda yakin akan menghapus<br/>transaksi dengan ID Transaksi : <b><?php echo $row2->codeTransaction;?></b> ?
                                                                      <hr/>
                                                                      <small class="text-muted" style="font-size: 10px; line-height: 5px;"><b>Peringatan!</b> Data transaksi yang terkait dengan ID tersebut akan dihapus dan tidak dapat dikembalikan lagi.</small>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                                      <form action="<?php echo site_url('Transaksi/hapusRiwayatTransaksi');?>" class="m-t-40" method="post">
                                                                        <input type="hidden" name="codeTransactionSent" value="<?php echo $row2->codeTransaction;?>">
                                                                        <button type="submit" class="btn btn-outline-danger">Ya, tetap hapus.</button>
                                                                      </form>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>


                                                            </div>
                                                          </div>
                                                        </div>
                                                      <?php } } } ?>

                                                    </div>
                                                  </div>
                                                  
                                                </div>
                                          </div>
                                         
                                          <?php } } ?>
                                          
                                          <!-- END timeline item -->
                                        <div>
                                          <i class="far fa-strip bg-gray"></i>
                                        </div>
                                        </div>
                                      </div>
                                    <!----- isi body close------>
                                  </div>
                              </div>
                              
                              </div>

                              
                              
                            </div>

                          </div>
                        </div>
                      </div>

            </div>

            


            
          </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->




<!-- Main Footer -->
<footer class="main-footer " id="onlinehulp">
   <strong>Copyright &copy; Dabalpro - <?php echo date('Y');?>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
          <script type="text/javascript">
              function getUrlVars() {
                  var vars = {};
                  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                      vars[key] = value;
                  });
                  return vars;
              }


                  var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                  if (mytext=='klasifikasiduplicated') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'warning',
                                      title: 'Maaf kategori dengan nama tersebut sudah ada. Silahkan cek kembali.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
                  if (mytext=='success_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil diupdate.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Transaksi berhasil dihapus.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='failed_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'danger',
                                      title: 'Maaf isian tidak boleh kosong',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
          </script>


<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });

     
  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    $('[data-mask]').inputmask()

    
  })
</script>

<script type="text/javascript">
  $(document).ready(function () {
    bsCustomFileInput.init();
  });
</script>

          

</body>
</html>
