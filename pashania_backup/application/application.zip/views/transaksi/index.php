
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Transaksi Sekarang!</title>

  <link href="<?php echo base_url(); ?>/assets/img/icons/logo.png" rel="icon" type="image/png">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_dabalpro/dist/css/adminlte.min.css">
  <style type="text/css">
        /*
         *  STYLE 3
         */
.item-show-up {
          box-shadow: 0px;
          border-radius: 0px;
          background: rgba(255,31,31,1);
background: -moz-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -webkit-gradient(left bottom, right top, color-stop(0%, rgba(255,31,31,1)), color-stop(100%, rgba(227,200,102,1)));
background: -webkit-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -o-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: -ms-linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
background: linear-gradient(45deg, rgba(255,31,31,1) 0%, rgba(227,200,102,1) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff1f1f', endColorstr='#e3c866', GradientType=1 );
          -moz-transition: all 0.2s linear 0s;
          -webkit-transition: all 0.2s linear 0s;
          -o-transition: all 0.2s linear 0s;
          -ms-transition: all 0.2s linear 0s;
          color: #fff;
          
        }
        .item-show-up:hover {
          transform: scale(1.03,1.03);
          box-shadow: 0px 12px 12px #bfbfbf;

        }
        #style-3::-webkit-scrollbar-track
        {
          -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar
        {
          width: 6px;
          background-color: #F5F5F5;
          border-radius: 3px;
        }

        #style-3::-webkit-scrollbar-thumb
        {
          background-color: #000000;
          border-radius: 3px;
        }

        .boxing {
          position: relative;
          -webkit-transition:all 0.1s linear 0s;
          -moz-transition:all 0.1s linear 0s;
          -o-transition:all 0.1s linear 0s;
        }
        .boxing:hover {
          -webkit-transform: translateY(-5px);
          -moz-transform: translateY(-5px);
          -o-transform: translateY(-5px);
          z-index:100;
        }


    .square {
      width: 100%;
      height: 130px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      border-radius: 10px;
      margin-bottom: 15px;
    }
    .square2 {
      width: 60%;
      height: 110px;
      padding-bottom: 50%;
      background-size: cover;
      background-position: center;
      float: right;
      margin-bottom: 15px;
    }

    /* input number stylish */
       input[type=number] {
          float: left;
          width: 70px;
          height: 35px;
          padding: 0;
          font-size: 1.2em;
          text-transform: uppercase;
          text-align: center;
          color: #93504C;
          border: 2px #93504C solid;
          background: none;
          outline: none;
          pointer-events: none;
        }

        span.spinner {
          position: absolute;
          height: 40px;
          user-select: none;
          -ms-user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -webkit-touch-callout: none;
        }

        span.spinner > .sub,
        span.spinner > .add {
          float: left;
          display: block;
          width: 35px;
          height: 35px;
          text-align: center;
          font-family: Lato;
          font-weight: 700;
          font-size: 1.2em;
          line-height: 33px;
          color: #93504C;
          border: 2px #93504C solid;
          border-right: 0;
          border-radius: 2px 0 0 2px;
          cursor: pointer;
          transition: 0.1s linear;
          -o-transition: 0.1s linear;
          -ms-transition: 0.1s linear;
          -moz-transition: 0.1s linear;
          -webkit-transition: 0.1s linear;
        }

        span.spinner > .add {
          top: 0;
          border: 2px #93504C solid;
          border-left: 0;
          border-radius: 0 2px 2px 0;
        }

        span.spinner > .sub:hover,
        span.spinner > .add:hover {
          background: #93504C;
          color: #25323B;
        }
         input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
         -webkit-appearance: none;
        }
        .selecteds {
          background-color: #999;
        }

   
  </style>
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to to the body tag
to get the desired effect
|---------------------------------------------------------|
|LAYOUT OPTIONS | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/chart.js/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/demo.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/dist/js/pages/dashboard3.js"></script>

<!-- DataTables -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- bs-custom-file-input -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/select2/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>/assets_dabalpro/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>

<script>
  $(document).on('click', '.number-spinner span', function () {    
    var btn = $(this),
      oldValue = btn.closest('.number-spinner').find('input').val().trim(),
      newVal = 0;

      btn.closest('.number-spinner').find('input').focus();
    
    if (btn.attr('data-dir') == 'up') {
      newVal = parseInt(oldValue) + 1;
      btn.closest('.number-spinner').find('input').val(newVal);
      btn.closest('.number-spinner').find('input').trigger("change");
    } else {
      if (oldValue > 1) {
        newVal = parseInt(oldValue) - 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      } else {
        newVal = 1;
        btn.closest('.number-spinner').find('input').val(newVal);
        btn.closest('.number-spinner').find('input').trigger("change");
      }
    }
    btn.closest('.number-spinner').find('input').val(newVal);
    btn.closest('.number-spinner').find('input').trigger("change");
  });
  </script>

  


  <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-black  navbar-dark">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="<?php echo site_url('Welcome/index');?>" class="nav-link">Home</a>
        </li>
      
      </ul>

    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
          class="fas fa-ellipsis-h"></i></a>
        </li>
      </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="<?php echo site_url('Welcome/index');?>" class="brand-link">
        <img src="<?php echo base_url(); ?>/assets/img/icons/logo.png" alt="Dabalpro Logo" class="brand-image img-circle elevation-3"
        style="opacity: .8">
        <span class="brand-text font-weight-light"><b>Dabal</b>pro</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="<?php echo base_url(); ?><?php echo $pictureUserGiven;?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block"><?php echo $namaUserGiven;?></a>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->

           <li class="nav-item">
            <a href="<?php echo site_url('Welcome/index');?>" class="nav-link ">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          

          <li class="nav-header">TRANSAKSI</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/index');?>" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Transaksi Baru
                
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo site_url('Transaksi/history');?>" class="nav-link">
              <i class="nav-icon far fa-file"></i>
              <p>
                Riwayat Transaksi
                
              </p>
            </a>
          </li>
          
          
          
          <li class="nav-header">GUDANG</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/index');?>" class="nav-link">
              <i class="nav-icon fas fa-boxes"></i>
              <p>Lihat Gudang</p>
            </a>
          </li>
          
          <li class="nav-header">AKUN</li>
          <li class="nav-item">
            <a href="<?php echo site_url('Managements/akun');?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>Kelola Akun</p>
            </a>
          </li>
          <?php
            if ($levelUser=='10') { ?>
            <li class="nav-item">
            <a href="<?php echo site_url('Managements/akunKaryawan');?>" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>Kelola Karyawan</p>
            </a>
          </li>

          <?php } ?>
          <!-- <li class="nav-header">LABEL</li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-danger"></i>
              <p class="text">Penting</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Perhatian</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Informasi</p>
            </a>
          </li> -->

          <li class="nav-item " style="position: fixed; bottom: 0px;width: 235px;">
            <a href="<?php echo site_url('Login/logoutUser');?>" class="nav-link " >
              <i class="nav-icon fas fa-power-off text-danger"></i>
              <p class="text-danger">
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        
        <!-- /.row -->

        <div class="col-lg-12 col-md-12">
            
            <div class="row">
                    <div class="col-md-7">
                      <div class="row">



                        <div class="card-body" >
                          <!----- isi body open------>
                            <form id="detailitemform" action="" class="m-t-40" method="post" enctype="multipart/form-data">
                            
                            <table width="100%">
                              <tr>

                                
                                <td width="100%" style="padding-top: 15px;">
                                
                                  
                                  <div class="input-group no-border" id="searchbyNameItem">
                                   
                                    <input type="text" name="searchbyNameItem" id="searchBoxItemByName" value="" class="form-control" placeholder="Ketikkan langsung nama item" >

                                    <!-- <button class="btn btn-warning btn-just-icon" name="btnAddNewClassification" id="btnAddAction">
                                      <i class="material-icons" >search</i>
                                      <div class="ripple-container" ></div>
                                    </button> -->
                                  </div>
                                  <span class="text-muted" style="display: block; font-size: 11px;">Ketik * untuk munculkan semua hasil.</span>
                                </td>
                                
                              </tr>

                              


                              
                            </table>

                      </form>
                          <!----- isi body close------>
                        </div>
                    </div>

                    

                  <div class="col-md-12 scrollbar mt-0" style="max-height: 720px; overflow-y:scroll;" id="style-3">
                      <div class="force-overflow">
                        <div class="row"  id="bagianItemRetrieveByDB">
                          
                            
                              
                            
                          

                      </div>
                    </div>
                    
                    </div>

                    
                    </div>

                    <div class="col-md-5 col-sm-12">
                        <div class="card" style="border-top-left-radius: 0px; border-top-right-radius: 0px;">
                          <div class="card-header card-header-danger card-header-icon">
                            <div class="card-icon float-left mr-3">
                              <i class="fas fa-shopping-cart"></i>
                            </div>
                            
                            <h3 class="card-title" style="margin-top: 2px;">Daftar Keranjang </h3>
                            <small class="badge badge-warning float-right" style="margin-left:80px;display:block;font-size: 12px; font-weight: bold;"> ID Transaction : <font id="idTransactionTag"><?php $text = random_string('alnum', 10); echo $text;?></font></small>
                          </div>
                          <div class="card-body">
                            <div class="row">
                              <div class="col-md-12">
                                <div class="row">
                                  <div class="card-body">
                                    <!----- isi body open------>
                                      <form id="detailitemforms" action="" class="m-t-40" method="post" enctype="multipart/form-data">
                                        <input type="hidden" id="idTokoHiddenS" name="idToko" value="">      

                                        <!-- <table width="100%">
                                          <tr>
                                            <th width="35%">Nama Item</th>

                                            <th width="20%">Jumlah</th>

                                            <th width="20%">Harga Satuan <small>(Rp)</small></th>

                                            <th width="20%">Total Harga <small>(Rp)</small></th>
                                            <th width="5%"></th>
                                          </tr>
                                         </table> -->

                                           <div class="row"  id="bagianItemTerpilihShopBasket" >

                                      
                                           </div>

                                            
                                          <img id="alertEmptyBasket" alt="Image placeholder" src="<?php echo base_url(); ?>/assets/img/icons/notfound3.png" style="width: 20%;display: block; padding-bottom:20px;text-align: center; margin: auto;">
                                          <span id="alertEmptyBasketText" class="text-muted text-center mb-3" style="display: block;font-size: 12px;">Tidak ada data dalam keranjang belanja.</span>
                                            
                                           <table width="50%" style="float: right;">

                                          <tr>
                                            <th width="70%"><p style="text-align:right;padding-right: 60px;">Total Harga</p></th>

                                            <th width="30%">
                                              
                                              <div class="row"  id="divTotalHargaNya" style="padding-left: 15px;">


                                               
                                                
                                              </div>
                                            </th>
                                            <th width="5%"></th>
                                          </tr>

                                          
                                         </table>

                                         <table width="100%" style="margin-top: 20px;" id="divTombolAcceptNya" style="border-top: solid 3px #000;">
                                          <tr>
                                            <th colspan="3"><p style="text-align:right;padding-right: 50px;"></p></th>

                                            <th>
                                              
                                            
                                                  <button class="btn btn-danger float-right" name="btnTombolAcceptNya" id="btnTombolAcceptNyaID" style="display: block; width: 50%;">
                                                          <i class="fas fa-check"></i> Pembayaran
                                                          
                                                  </button>
                                                
                                              
                                            </th>
                                            
                                          </tr>

                                          
                                         </table>



                                        
                                      

                                      </form>
                                    <!----- isi body close------>
                                  </div>
                              </div>
                              
                              </div>

                              
                              
                            </div>

                          </div>
                        </div>
                      </div>

            </div>

            


            
          </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->




<!-- Main Footer -->
<footer class="main-footer " id="onlinehulp">
   <strong>Copyright &copy; Dabalpro - <?php echo date('Y');?>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->




<script type="text/javascript">
 $(window).on('load',function(){
 
});
</script>

<script type="text/javascript">
    $(document).ready(function() {
                document.getElementById('bagianItemRetrieveByDB').style="visibility:hidden";
                document.getElementById('divTombolAcceptNya').style="visibility:hidden";
                


                var pilihannya2 = "allchoosen";

              
                jQuery.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>"+"Transaksi/searchItemByTappingFilter",
                        dataType: 'json',
                    //mengirim data dengan type post
                    data: {isi: pilihannya2},
                    //menerima result dari controller
                    success: function(data2) {
                      
                        $('#bagianItemRetrieveByDB').html(data2);
                        $('#bagianItemRetrieveByDB').fadeIn(400);
                        $('#bagianItemRetrieveByDB').attr({'style' : 'visibility:true'});
                        
                       
                    }
                  });


                $('#searchBoxItemByName').on('keyup', function(){
                      if($(this).val()==''){
                          $('#bagianItemRetrieveByDB').fadeOut(800);
                          
                          
                          
                      }

                      else{
                          $('#bagianItemRetrieveByDB').fadeIn(900);
                          $('#bagianItemRetrieveByDB').attr({'style' : 'visibility:true'});


                          
                          

                         
                      }
                    });

                $('#searchBoxItemByName').on('keyup', function(){
                  var pilihannya2 = "";
                  pilihannya2 = $(this).val();
                  jQuery.ajax({
                        type: "POST",
                        url: "<?php echo base_url(); ?>"+"Transaksi/searchItemByNameInShopPages",
                        dataType: 'json',
                    //mengirim data dengan type post
                    data: {namaItemDiketikkan: pilihannya2},
                    //menerima result dari controller
                    success: function(data) {
                        $('#bagianItemRetrieveByDB').html(data);

                        

                        
                       
                    }
                  });
              

                 });      

    });
</script>


<!-------- SCRIPT UNTUK MENGAMBIL VALUE PADA TAG DALAM URL ------->
          <script type="text/javascript">
              function getUrlVars() {
                  var vars = {};
                  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                      vars[key] = value;
                  });
                  return vars;
              }


                  var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                  if (mytext=='klasifikasiduplicated') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'warning',
                                      title: 'Maaf kategori dengan nama tersebut sudah ada. Silahkan cek kembali.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
                  if (mytext=='success_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil diupdate.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil dihapuskan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='failed_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'danger',
                                      title: 'Maaf isian tidak boleh kosong',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
          </script>




<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });

     
  });
</script>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    $('[data-mask]').inputmask()

    
  })
</script>

<script type="text/javascript">
  $(document).ready(function () {
    bsCustomFileInput.init();
  });
</script>

          

</body>
</html>
