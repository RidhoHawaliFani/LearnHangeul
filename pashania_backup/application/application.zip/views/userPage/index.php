<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Nida Utama Tour & Travel</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
    <style type="text/css">

    .square {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .previewing {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }
    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }
    
  </style>
  </head>
  <body>
    
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex align-items-center">
          <a class="navbar-brand brand-logo" href="<?php echo site_url('User/index');?>" style="color:#fff;font-weight: 800">
            <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
            nidautama
          </a>
        
          <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('User/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
          <h5 class="mb-0 font-weight-medium d-none d-lg-flex">Selamat datang di Aplikasi Nida Utama</h5>
          <ul class="navbar-nav navbar-nav-right ml-auto">
          

          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
                            <?php
                            $no=0;
                            if(!$dataUser->result()){ ?>

                              <p class="card-description">.</p>                                            

                            <?php }else {
                              foreach ($dataUser->result() as $row) {

                            ?>
                            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                               <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                              <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>
                            

              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                <div class="dropdown-header text-center">
                  <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                  <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                  <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                </div>
                <a href="<?php echo site_url('User/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
                <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
                <?php } } ?>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="icon-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav" style="">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="profile-image">
                  <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                  <div class="dot-indicator bg-success"></div>
                </div>
                <div class="text-wrapper">
                  <p class="profile-name" style="width: 100px"><?php if($namaUserGiven){echo $namaUserGiven;}else { echo "Belum Ditentukan";};?></p>
                  <p class="designation"><?php if($levelUser=='2'){ echo "User";};?></p>
                </div>

              </a>
            </li>
            <li class="nav-item nav-category">
              <span class="nav-link">Dashboard</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/index');?>">
                <span class="menu-title">Dashboard</span>
                <i class="icon-screen-desktop menu-icon"></i>
              </a>
            </li>
            <li class="nav-item nav-category"><span class="nav-link">Tagihan Pembayaran</span></li>
            <li class="nav-item">

              <a class="nav-link" href="<?php echo site_url('User/lihatTagihanPembayaran');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dibayar segera">
                <?php
            $no=0;
            if(!$dataPaymentBelumBayar->result()){ ?>
              <span class="menu-title">Pembayaran </span>
            <?php }else {
              
                ?>
                <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
                  <span class="wave"></span>
                  <span class="wave"></span>
                  <span class="wave"></span>
                </div>
                <span class="menu-title">Pembayaran 
                  <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentBelumBayar->num_rows();?>
                  </div>



                </span>

              <?php }  ?>
                <i class="icon-wallet menu-icon"></i>
              </a>
            </li>
            
            <li class="nav-item nav-category"><span class="nav-link">Pengaturan Akun</span></li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/editPassword');?>">
                <span class="menu-title ">Ganti Password</span>
                <i class="icon-key menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/lihatDataJemaahByUser');?>">
                <span class="menu-title">Lihat Akun</span>
                <i class="icon-user menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/tambahJemaahByUser');?>">
                <span class="menu-title">Tambah Jemaah</span>
                <i class="icon-user-follow menu-icon"></i>
              </a>
            </li>
            
            
            
            
            
            <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
              <span class="">
                <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
              </span>
            </li>
            
            <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
              <span class="">
                <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
              </span>
            </li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

                    <?php
                    $no=0;
                    if(!$dataUser->result()){ ?>

                      <p class="card-description"> Sorry, no data can be retrieve right now.</p>                                            

                    <?php }else {
                      foreach ($dataUser->result() as $row) {
                        if(empty($row->namaLengkap) or empty($row->noPassport) or empty($row->tempatLahir) or empty($row->birthday) or empty($row->tglAktifPassport) or empty($row->tglExpPassport) or empty($row->lokasiBuatPassport) or empty($row->gender) or empty($row->noTelp) or empty($row->alamat) or empty($row->rt) or empty($row->rw) or empty($row->kelurahan) or empty($row->kecamatan) or empty($row->kabupaten) or empty($row->provinsi) or empty($row->pendidikan) or empty($row->status) or empty($row->pekerjaan) or empty($row->namaAyah)){
                        ?>
            <div class="row purchace-popup">
              <div class="col-12 stretch-card grid-margin">
                <div class="card badge-danger">
                  <span class="card-body d-lg-flex align-items-center">
                    <p class="mb-lg-0">Sepertinya data diri Anda belum lengkap, lengkapi sekarang yuk!</p>
                    <a href="<?php echo site_url('User/editProfile');?>" class="btn ml-lg-auto download-button btn-success btn-sm my-1 my-sm-0">Lengkapi Sekarang</a>
                    
                  </span>
                </div>
              </div>
            </div>
            <?php }else { echo "";} } }?>
            
            <!-- Quick Action Toolbar Starts-->
            <div class="row quick-action-toolbar">
              <div class="col-md-12 grid-margin">
                <div class="card">
                  <div class="card-header d-block d-md-flex">
                    <h5 class="mb-0">Jalan Pintas</h5>
                    <p class="ml-auto mb-0">Beberapa menu yang sering Anda gunakan<i class="icon-bulb"></i></p>
                  </div>
                  <div class="d-md-flex row m-0 quick-action-btns" role="group" aria-label="Quick action buttons">
                    <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                      <a href="<?php echo site_url('User/tambahJemaahByUser');?>" type="button" class="btn px-0"> <i class="icon-user-follow mr-2"></i> Tambah Jemaah</a>
                    </div>
                    <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                      <a href="<?php echo site_url('User/lihatDataJemaahByUser');?>" type="button" class="btn px-0"><i class="icon-docs mr-2"></i> Lihat Data Jemaah</a>
                    </div>
                    <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                      <a href="<?php echo site_url('User/editProfile');?>" type="button" class="btn px-0"><i class="icon-user mr-2"></i> Ubah Profil</a>
                    </div>
                    <div class="col-sm-6 col-md-3 p-3 text-center btn-wrapper">
                      <a href="<?php echo site_url('User/editPassword');?>" type="button" class="btn px-0"><i class="icon-key mr-2"></i> Ubah Password</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Quick Action Toolbar Ends-->
            
            
            <div class="row">
              <div class="col-md-3 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class=" align-items-center mb-4">
                      <h4 class="card-title mb-sm-0">Rencana Perjalanan</h4>
                      <h6 class="mb-sm-0">Dalam Waktu Dekat</h6>
                    </div>

                    <?php
                            $no=0;
                            if(!$dataPaketConnected->result()){ ?>

                              <p class="card-description">Tidak ada perjalanan dalam waktu dekat ini.</p>                                            

                            <?php }else {
                              foreach ($dataPaketConnected->result() as $row) {

                            ?>
                            <div class=" border rounded p-4">
                              <h5><a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" target="_blank" class="text-dark"><?php echo $row->namaPaket;?></a></h5>

                              <div class="row mt-3 mb-4">
                                <div class="col-md-1">
                                  <div class="badge badge-success float-left p-1" style="margin-left: -5px; z-index: 192"><i class="icon-plane"></i></div>
                                  <div style="border-left: 2px dashed grey; height: 40px; position: relative; z-index: 190; margin-top: 23px; margin-left: 3px"></div>
                                  <div class="badge badge-danger float-left p-1" style="margin-left: -5px; z-index: 192; margin-top: 2px"><i class="icon-plane"></i></div>
                                </div>
                                <div class="col-md-11">
                                  Berangkat <font class="ml-3 float-right"><?php echo $row->tglMulai;?></font>
                                  <br/><br/><br/>
                                  <font class="mt-2">
                                  Kembali <font class="ml-3 float-right"><?php echo $row->tglSelesai;?></font>
                                  </font>
                                </div>
                              </div>
                            <div class="card-footer mt-4" style="margin: -25px;">
                              <i class="icon-clock mr-3"></i><?php echo $row->rentangWaktu;?> Hari Lagi
                            </div>
                            </div>

                    <?php } } ?>


                  </div>
                </div>
              </div>

              <div class="col-md-4 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="align-items-center mb-4">
                      <h4 class="card-title mb-sm-0">Informasi Penting</h4>
                      <h6 class="mb-sm-0">Telah Dirangkum</h6>
                    </div>
                    <?php
                    $no=0;
                    if(!$dataUser->result()){ ?>

                      <p class="card-description"> Sorry, no data can be retrieve right now.</p>                                            

                    <?php }else {
                      foreach ($dataUser->result() as $row) {
                        if(empty($row->namaLengkap) or empty($row->noPassport) or empty($row->tempatLahir) or empty($row->birthday) or empty($row->tglAktifPassport) or empty($row->tglExpPassport) or empty($row->lokasiBuatPassport) or empty($row->gender) or empty($row->noTelp) or empty($row->alamat) or empty($row->rt) or empty($row->rw) or empty($row->kelurahan) or empty($row->kecamatan) or empty($row->kabupaten) or empty($row->provinsi) or empty($row->pendidikan) or empty($row->status) or empty($row->pekerjaan) or empty($row->namaAyah)){
                        ?>
                    <div class="table-responsive border rounded p-1">
                      <table class="table">
                        <thead>
                          <tr>
                            <th class="font-weight-bold">Keterangan</th>
                            <th class="font-weight-bold">Tindakan</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            
                            <td width="500"><b>Data Profil Belum Lengkap</b><br/><br/>
                              <font class="text-muted">Lengkapi data profil kamu sekarang</font></td>
                            <td>
                              <a href="<?php echo site_url('User/editProfile');?>" class="badge ml-lg-auto download-button badge-success btn-sm my-1 my-sm-0 p-2">Lengkapi</a>
                            </td>
                          </tr>
                          
                        </tbody>
                      </table>
                    </div>

                    <?php } } }?>

                    <?php
                    $no=0;
                    if(!$dataPaymentBelumBayar->result()){ ?>

                    <?php }else {
                      
                        ?>
                    <div class="table-responsive border rounded p-1 mt-2">
                      <table class="table">
                        <thead>
                          <tr>
                            <th class="font-weight-bold">Keterangan</th>
                            <th class="font-weight-bold">Tindakan</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            
                            <td width="500"><b>Terdapat <?php echo $dataPaymentBelumBayar->num_rows();?> tagihan pembayaran</b><br/><br/>
                              <font class="text-muted">Lihat daftar tagihan sekarang</font></td>
                            <td>
                              <a href="<?php echo site_url('User/lihatTagihanPembayaran');?>" class="badge ml-lg-auto download-button badge-success btn-sm my-1 my-sm-0 p-2">Lihat</a>
                            </td>
                          </tr>
                          
                        </tbody>
                      </table>
                    </div>

                    <?php }?>

                    <div class="table-responsive border rounded p-1">
                      <table class="table">
                        <thead>
                          <tr>
                            <th class="font-weight-bold">Keterangan</th>
                            <th class="font-weight-bold">Tindakan</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            
                            <td width="500"><b>Lihat daftar paket terbaru</b><br/><br/>
                              <font class="text-muted">Lihat daftar paket sekarang</font></td>
                            <td>
                              <a href="<?php echo site_url('Welcome/');?>" target="_blank" class="badge ml-lg-auto download-button badge-success btn-sm my-1 my-sm-0 p-2">Lihat</a>
                            </td>
                          </tr>
                          
                        </tbody>
                      </table>
                    </div>


                  </div>
                </div>
              </div>

              <div class="col-md-5 grid-margin ">
                <div class="card"  style="border-left: 5px solid #fcaf32">
                  <div class="card-body">
                    <div class="d-sm-flex align-items-center mb-4">
                      <h4 class="card-title mb-sm-0">Testimoni</h4>
                      
                    </div>

                    <form role="form" method="post" id="formBerzakat" class="forms-sample" action="<?php echo site_url('User/prosesAddTestimoni');?>" enctype="multipart/form-data">
                    
                    <font style="font-size: 14px; ">Berikan testimoni Anda selama berkoneksi dengan kami.Baik itu dalam hal pelayanan sistem, pelayanan jemaah, dsb.</font>
                    <textarea name="testimoni" class="form-control mt-4" placeholder="Ketik disini. Maksimal 250 karakter." rows="5" style="line-height: 20px;" required=""></textarea>

                    <button type="submit" class="btn btn-lg btn-warning mt-3 float-right">Kirim</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright ©  <?php echo date('Y');?> <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap Dash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
    <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>
    <!-- End custom js for this page -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.4/dist/sweetalert2.all.min.js"></script>


     <script type="text/javascript">
              function getUrlVars() {
                  var vars = {};
                  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                      vars[key] = value;
                  });
                  return vars;
              }


                  var mytext = getUrlVars()["stats"]; //mengambil value dari tag STATS pada URL
                  
                  if (mytext=='success') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Testimoni berhasil dikirim.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='success_delete') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'success',
                                      title: 'Data berhasil dihapuskan.',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }if (mytext=='failed_update') {
                                    Swal.fire({
                                      position: 'top-center',
                                      icon: 'danger',
                                      title: 'Maaf isian tidak boleh kosong',
                                      showConfirmButton: true,
                                      timer: 3500
                                    });

                  }
          </script>

  </body>
</html>