<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Nida Utama Tour & Travel</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets_adminuser/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets_nidautama/img/logo1.png" />
  <style type="text/css">

    .square {
      width: 100px;
      height: 100px;
      margin: auto;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    
    .square2 {
      width: 30px;
      height: 30px;
      margin: auto;
      margin-right: 10px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .square3 {
      width: 100px;
      height: 100px;
      margin: auto;
      text-align: center;      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      
      
    }
    .previewing {
      width: 270px;
      height: 270px;
      
      background-size: cover;
      background-position: center;
      

      display: block;
      
      text-align: center;
      box-shadow: -2px 2px 4px #8f8f8f;
      border: 3px solid #fff;
      
      
    }
    td:second-child { width: 33% ;}
    .scaleUp {
      position: relative;
      -webkit-transition: all 0.1s linear 0s;
      -o-transition: all 0.1s linear 0s;
      -ms-transition: all 0.1s linear 0s;
      -moz-transition: all 0.1s linear 0s;
    }
    .scaleUp:hover {
      -webkit-transform: scale(1.01,1.01);
      -ms-transform: scale(1.01,1.01);
      -o-transform: scale(1.01,1.01);
      -moz-transform: scale(1.01,1.01);
    }

    .tetew {
      position: relative;
      padding-top: 20px;

    }

    .btnxxx {
      display: block;
      position: relative;
      margin: auto;
      width: 40%;
      border: 1px dashed;
      color: gray;
      background-color: white;
      padding: 8px 20px;
      border-radius: 8px;
      font-size: 20px;
      font-weight: bold;
    }
    .btnxxx:hover {
      cursor: pointer;
    }


    .tetew input[type=file] {
      font-size: 40px;
      position: absolute;
      left: 0;
      top: 0;
      opacity: 0;
    }

    @-webkit-keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }

    @keyframes echo {
      0% {
        padding: 0;
        margin: 0;
        opacity: 1;
      }

      100% {
        padding: 50px;
        margin: -50px;
        opacity: 0;
      }
    }
    .waves {
      position: absolute;
      
    }

    .wave {
      position: absolute;
      border: 2px solid #f4071b;
      border-radius: 50%;
      display: inline-block;
      padding: 0px;

      animation-name: echo;
      animation-duration: 2s;
      animation-iteration-count: infinite;
      animation-timing-function: ease-out;

      -webkit-animation-name: echo;
      -webkit-animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: ease-out;
    }

    .wave:nth-of-type(2) {
      animation-delay: 0.4s;
      -webkit-animation-delay: 0.4s;
    }

    .wave:nth-of-type(3) {
      animation-delay: 0.8s;
      -webkit-animation-delay: 0.8s;
    }
    
  </style>
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="navbar-brand-wrapper d-flex align-items-center">
        <a class="navbar-brand brand-logo" href="<?php echo site_url('User/index');?>" style="color:#fff;font-weight: 800">
          <img src="<?php echo base_url(); ?>/assets_nidautama/img/logo.jpg" alt="logo" class="logo-dark" style="width: 30px; border-radius: 100px;" />
          nidautama
        </a>
        
        <a class="navbar-brand brand-logo-mini" href="<?php echo site_url('User/index');?>"><img src="<?php echo base_url(); ?>/assets_nidautama/img/logo3.png" alt="logo" /></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center flex-grow-1">
        <h5 class="mb-0 font-weight-medium d-none d-lg-flex"></h5>
        <ul class="navbar-nav navbar-nav-right ml-auto">


          <li class="nav-item dropdown d-none d-xl-inline-flex user-dropdown">
            <?php
            $no=0;
            if(!$dataUser->result()){ ?>

              <p class="card-description">.</p>                                            

            <?php }else {
              foreach ($dataUser->result() as $row) {

                ?>
                <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                 <div class="square2 img-xs rounded-circle ml-2" id="previewing2" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                 <span class="font-weight-normal"> <?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?> </span></a>


                 <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                  <div class="dropdown-header text-center">
                    <div class="square3 img-xs rounded-circle" id="previewing2" style="background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                    <p class="mb-1 mt-3"><?php if(!$row->namaLengkap){ echo $row->username;}else { echo $row->namaLengkap;}?></p>
                    <p class="font-weight-light text-muted mb-0"><?php if(!$row->email){ echo '-';}else { echo $row->email;}?></p>
                  </div>
                  <a href="<?php echo site_url('User/editProfile');?>" class="dropdown-item"><i class="dropdown-item-icon icon-user text-primary"></i> Lihat Profil</a>
                  <a href="<?php echo site_url('Login/logoutUser');?>" class="dropdown-item"><i class="dropdown-item-icon icon-power text-primary"></i>Keluar</a>
                <?php } } ?>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="icon-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav" style="">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="profile-image">
                  <div class="square2 img-xs rounded-circle" style="display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->pictureProfile){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->pictureProfile;}?>');"></div>
                  <div class="dot-indicator bg-success"></div>
                </div>
                <div class="text-wrapper">
                  <p class="profile-name" style="width: 100px"><?php if($namaUserGiven){echo $namaUserGiven;}else { echo "Belum Ditentukan";};?></p>
                  <p class="designation"><?php if($levelUser=='2'){ echo "User";};?></p>
                </div>

              </a>
            </li>
            <li class="nav-item nav-category">
              <span class="nav-link">Dashboard</span>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/index');?>">
                <span class="menu-title">Dashboard</span>
                <i class="icon-screen-desktop menu-icon"></i>
              </a>
            </li>
            <li class="nav-item nav-category"><span class="nav-link">Tagihan Pembayaran</span></li>
            <li class="nav-item">

              <a class="nav-link" href="<?php echo site_url('User/lihatTagihanPembayaran');?>" data-toggle="tooltip" data-placement="right" title="Terdapat pembayaran yang perlu dibayar segera">
                <?php
            $no=0;
            if(!$dataPaymentBelumBayar->result()){ ?>
              <span class="menu-title">Pembayaran </span>
            <?php }else {
              
                ?>
                <div class="waves" style="position: absolute; z-index: 191; margin-left: 110px; " >
                  <span class="wave"></span>
                  <span class="wave"></span>
                  <span class="wave"></span>
                </div>
                <span class="menu-title">Pembayaran 
                  <div class="badge badge-danger p-2" style="z-index: 192" ><?php echo $dataPaymentBelumBayar->num_rows();?>
                  </div>



                </span>

              <?php }  ?>
                <i class="icon-wallet menu-icon"></i>
              </a>
            </li>
            
            <li class="nav-item nav-category"><span class="nav-link">Pengaturan Akun</span></li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/editPassword');?>">
                <span class="menu-title ">Ganti Password</span>
                <i class="icon-key menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/lihatDataJemaahByUser');?>">
                <span class="menu-title">Lihat Akun</span>
                <i class="icon-user menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo site_url('User/tambahJemaahByUser');?>">
                <span class="menu-title">Tambah Jemaah</span>
                <i class="icon-user-follow menu-icon"></i>
              </a>
            </li>
            
            
            
            
            
            <li class="nav-item pro-upgrade" style="position: fixed; bottom: 110px; width: 240px;border-top: none; margin-top: 20px;">
              <span class="">
                <a class="btn btn-block px-0 btn-rounded btn-outline-success" href="<?php echo site_url('Welcome');?>"> <i class=" icon-arrow-left mx-2"></i> Nidautama.com</a>
              </span>
            </li>
            
            <li class="nav-item pro-upgrade" style="position: fixed; bottom: 40px; width: 240px;border-top: none; margin-top: 20px;">
              <span class="">
                <a class="btn btn-block px-0 btn-rounded btn-outline-danger" href="<?php echo site_url('Login/logoutUser');?>"> <i class="icon-logout mx-2"></i> Logout</a>
              </span>
            </li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <div class="row quick-action-toolbar">
              <div class="col-md-8 grid-margin mt-2">
                <div class="card">
                  <div class="card-header d-block ">
                    <div class="float-left">
                      <h5 class="mb-0">Daftar Tagihan</h5>
                      <span class="mb-0 text-small">Tagihan tersebut perlu dibayar sebelum waktu yang telah ditentukan, apabila <b>lewat</b> dari batas waktu tersebut, tagihan akan otomatis dihapus.</span>
                    </div>
                    <div class="text-danger" style="position: absolute; right: 20px; font-size: 26px; font-weight: bold; float: right;">
                      <?php
                      $no=0;
                      if(!$dataPaymentBelumBayar->result()){ ?>
                        0
                      <?php }else {
                        echo $dataPaymentBelumBayar->num_rows();}
                        ?>

                      </div>
                      <div class="text-danger" style="position: absolute; right: 20px; font-size: 12px; top: 40px; font-weight: bold; float: right;">Tagihan perlu dibayar</div>
                    </div>

                    <div class="card-body d-block" style="background-color: #fafafa">

                      <div class="row">

                        <?php
                        $no=0;
                        if(!$dataPaymentBelumBayar->result()){ ?>

                          <p class="card-description"> Sorry, no data can be retrieve right now.</p>                                            

                        <?php }else {
                          foreach ($dataPaymentBelumBayar->result() as $row) {

                            ?>
                            <div class="col-md-3 col-lg-3 col-sm-12">
                              <div class="card">
                                <div class="card-body text-center">
                                  <div style="position: absolute;left: 10px; top: 10px;">

                                  </div>
                                  <div style="position: relative; margin: auto; ">


                                    <div class="badge badge-danger p-2" style="font-weight: normal; border-radius: 100px;">
                                      <?php echo $row->statusPembayaran;?>
                                    </div>


                                  </div>
                                  <div class="square  d-block mb-3" id="previewing2" style="margin-top: -15px; width: 100%; height: 200px; display:block;background-color: #fff; z-index: 554; background-image: url('<?php echo base_url(); ?><?php if(!$row->picturePaket){ echo "/assets_adminuser/images/faces/no-image.png";}else { echo $row->picturePaket;}?>');"></div>
                                  <a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" class="text-muted"><h4 class="d-block text-muted"><small style="font-size: 11px; text-transform: uppercase;">#<?php echo $row->kodePaketTour;?></small></h4></a>
                                  <h4 class="d-block"><?php echo $row->namaPaket;?></h4>
                                  <h6 class="d-block"><?php echo "Rp " . number_format($row->hargaTotalPaket,0,',','.');?>,-</h6>
                                  <hr/>
                                  <div class="badge badge-light p-2" style="font-weight: normal; border-radius: 100px;">
                                      <?php echo $row->hargaTotalPaket/$row->hargaSatuanPaket;?> calon jemaah
                                    </div>


                                  <div class="btn-group mt-2" role="group" aria-label="Basic example">
                                    <a href="#" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modaldelete"><i class="icon-cloud-upload"></i> Upload Bukti</a>
                                    <a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" class="btn btn-sm btn-outline-warning" data-toggle="tooltip" data-placement="right" title="Lihat detail lengkap tagihan"><i class="icon-eye"></i></a>

                                  </div>


                                </div>

                              </div>
                            </div>

                            <div class="modal fade" id="modaldelete" data-keyboard="false" data-backdrop="static">
                              <div class="modal-dialog modal-normal">
                                <form id="showForm" action="<?php echo site_url('User/prosesUploadBuktiPembayaran');?>" class="m-t-40" method="post" enctype="multipart/form-data">

                                  <div class="modal-content ">




                                    <div class="modal-body text-center">

                                      <h3>Upload Bukti</h3>
                                      <div class="tetew">
                                        <button class="btnxxx" style="margin: auto; position: relative; margin-bottom: 20px;">Pilih Gambar</button>
                                        <input type="hidden" class="" name="kodePaketTourGet" required="" value="<?php echo $row->kodePaketTour;?>">
                                        <input type="file" class="tripleh" name="uploadgambar" required="">
                                        <font id="successUpload" style="display: none; padding: 6px; color: #fff; padding-left: 13px; padding-right: 13px; border-radius: 100px;" class="badge badge-success mb-4">File berhasil dipilih</font>
                                        <font id="failedUpload" style="display: none; padding: 6px; color: #fff; line-height: 14px; padding-left: 13px; padding-right: 13px; border-radius: 100px;" class="badge badge-danger mb-4">File gagal dipilih karena bukan berupa<br/>gambar dengan format jpeg / jpg / png</font>
                                      </div>

                                      <small class="text-muted" style="font-size: 10px; line-height: 10px;"><b>Penting!</b> Mohon gambar yang dipilih adalah gambar bukti pembayaran yang dapat dengan jelas dilihat.</small>
                                    </div>

                                    <div class="modal-footer d-block" id="sideBtnSave">
                                      <button class="btn btn-outline-primary" data-dismiss="modal" aria-label="Close"  id="cancelDelete" style="float: left;"><i class="fas fa-times" style=""></i> Batal</button>
                                      <button type="submit" disabled="" id="submitBtnYes" class="btn btn-danger" style="float: right;display: block;"><i class="fas fa-check" style="margin-right: 10px;"></i> Ya, Upload Sekarang</button>
                                    </div>
                                  </div>
                                </form>
                                <!-- /.modal-content -->
                              </div>
                            </div>




                          <?php } } ?>

                          

                        </div>
                      </div>


                    </div>

                  </div>

                  <div class="col-md-4 grid-margin mt-2">
                    <div class="card">
                      <div class="card-header d-block ">
                        <div class="float-left">
                          <h5 class="mb-0">Riwayat Pembayaran</h5>
                        </div>
                      </div>

                      <div class="card-body d-block" style="background-color: #fafafa; padding: 0">
                        <table class="table table-hover" style="width: 100%;">
                          <thead>
                            <tr >
                              <th style="font-weight: bold;">No</th>
                              <th style="font-weight: bold;">Keterangan</th>
                              <th style="font-weight: bold;">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $no=0;
                            if(!$dataPaymentSudahBayar->result()){ ?>

                              <tr><td colspan="4"><p class="card-description text-center"> Sorry, no data can be retrieve right now.</p>                                            </td></tr>

                            <?php }else {
                              $no=0;
                              foreach ($dataPaymentSudahBayar->result() as $row) {
                                $no++;
                                ?>
                                <tr>
                                  <td width="1%" valign="top"><?php echo $no;?></td>
                                  <td width="40%">
                                    <a href="<?php echo site_url('Welcome/invoice/').$row->kodePaketTour;?>" class="mb-2 d-block text-dark text-muted">#<?php echo $row->kodePaketTour;?></a>
                                    <a href="<?php echo site_url('User/editProfile/').$row->idUser;?>" class="mb-2 d-block text-dark"><?php echo $row->namaLengkap;?></a>
                                    <i><?php echo $row->namaPaket;?></i><br/>
                                    <span class="text-muted" style="font-size: 12px;"><?php echo "Rp " . number_format($row->hargaTotalPaket,0,',','.');?>,-</small></span>
                                    <font class="mt-2 d-block"><strong><?php echo $row->tglDibayar;?></strong> <small>(<?php echo $row->jamDibayar;?> WIB)</small></font>
                                  </td>
                                  <td>
                                    <?php
                                      if ($row->statusPembayaran=='Menunggu Konfirmasi') {
                                    ?>
                                      <font style="font-size: 11px; color: #fff; border-radius: 10px; padding: 3px; padding-left: 10px; padding-right: 10px;" class="bg-danger"><?php echo $row->statusPembayaran;?></font>
                                    <?php }elseif ($row->statusPembayaran=='Lunas') {
                                    ?>
                                      <font style="font-size: 11px; color: #fff; border-radius: 10px; padding: 3px; padding-left: 10px; padding-right: 10px;" class="bg-success"><?php echo $row->statusPembayaran;?></font>
                                    <?php } ?>  
                                  </td>
                                </tr>
                              <?php } } ?>

                            </tbody>
                          </table>
                        </div>


                      </div>

                    </div>
                  </div>
                  <!-- Quick Action Toolbar Ends-->



                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                  <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright ©  <?php echo date('Y');?> <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap Dash</a>. All rights reserved.</span>
                    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="icon-heart text-danger"></i></span>
                  </div>
                </footer>




                <!-- partial -->
              </div>
              <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
          </div>
          <!-- container-scroller -->
          <!-- plugins:js -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/js/vendor.bundle.base.js"></script>
          <!-- endinject -->
          <!-- Plugin js for this page -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chart.js/Chart.min.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/moment/moment.min.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/daterangepicker/daterangepicker.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/vendors/chartist/chartist.min.js"></script>
          <!-- End plugin js for this page -->
          <!-- inject:js -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/off-canvas.js"></script>
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/misc.js"></script>
          <!-- endinject -->
          <!-- Custom js for this page -->
          <script src="<?php echo base_url(); ?>/assets_adminuser/js/dashboard.js"></script>
          <!-- End custom js for this page -->


          <script type="text/javascript">
            $(document).ready(function() {
              $(".tripleh").change(function() {
                var file = this.files[0];
                var imagefile = file.type;
                var match= ["image/jpeg","image/png","image/jpg"];
                if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
                {
                  document.getElementById("failedUpload").style.display = "inline-block"; 
                  document.getElementById("successUpload").style.display = "none";  
                  document.getElementById("submitBtnYes").disabled = true;  
                }
                else
                {
                  var reader = new FileReader();
                  reader.onload = imageIsLoaded;
                  reader.readAsDataURL(this.files[0]);
                }
              });

              function imageIsLoaded(e) {
                  document.getElementById("successUpload").style.display = "inline-block";  
                  document.getElementById("failedUpload").style.display = "none"; 
                  document.getElementById("submitBtnYes").disabled = false;  

              };

            });
          </script>


          <script type="text/javascript">
           $(window).on('load',function(){
            document.getElementById("secondSection").style.display = "none";
            document.getElementById("btnUploadGambar").style.display = "none";
          });
        </script>

        <script type="text/javascript">
          $(document).ready(function() {

            var pivot = 1;

            $('#btnEditNow').on('click', function(){
              if (pivot == 1) {
                document.getElementById("firstSection").style.display = "none";
                document.getElementById("secondSection").style.display = "block";
                document.getElementById("btnUploadGambar").style.display = "block";
                document.getElementById("btnEditNow").style.display = "none";
                pivot = 0;
              }else {
                document.getElementById("firstSection").style.display = "block";
                document.getElementById("secondSection").style.display = "none";
                document.getElementById("btnUploadGambar").style.display = "none";
                pivot = 1;
              }


            });      


          });
        </script>
        <script type="text/javascript">
          $(function () {
            $('[data-toggle="tooltip"]').tooltip()
          })
        </script>
      </body>
      </html>